<?php
define( '_JEXEC', 1 );
define('JPATH_BASE', substr(substr(dirname(__FILE__), 0, strpos(dirname(__FILE__), "componen")),0,-1));

//if (!isset($_SERVER["HTTP_REFERER"])) exit("Direct access not allowed.");
$mosConfig_absolute_path =substr(JPATH_BASE, 0, strpos(JPATH_BASE, "/componen")); 

define( 'DS', DIRECTORY_SEPARATOR );
$parts = explode(DS, JPATH_BASE);
require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );
require_once ( JPATH_BASE .DS.'libraries'.DS.'joomla'.DS.'methods.php');
require_once ( JPATH_BASE .DS.'configuration.php' );
require_once ( JPATH_BASE .DS.'libraries'.DS.'joomla'.DS.'base'.DS.'object.php');
require_once ( JPATH_BASE .DS.'libraries'.DS.'joomla'.DS.'database'.DS.'database.php');
require_once ( JPATH_BASE .DS.'libraries'.DS.'joomla'.DS.'database'.DS.'database'.DS.'mysql.php');
require_once ( JPATH_BASE .DS.'libraries'.DS.'joomla'.DS.'filesystem'.DS.'folder.php');

$config = new JConfig();
$options = array ("host" => $config->host, "user" => $config->user, "password" => $config->password, "database" => $config->db, "prefix" => $config->dbprefix);

class adprinDatabase extends JDatabaseMySQL{
	public function __construct($options){
		parent::__construct($options);
	}
}

$database = new adprinDatabase($options);

$task = JRequest::getVar("task", "");

switch($task){
	case "verifyGroupCode" : {		
		verifyGroupCode();
		break;
	}
	case "submitUserInfo" : {		
		submitUserInfo();
		break;
	}
	
	case "listGroupRating" : {		
		listGroupRating();
		break;
	}
	
	/*case "updatesql" : {		
		updatesql();
		break;
	}*/
}

function verifyGroupCode(){
	global $database;
	$group_code = JRequest::getVar("group_code", "");
	$group_code_new = JRequest::getVar("group_code_new", "");
	$sql = "select * from #__adprin_surveys_session where group_code='".$group_code."'"; 
	//echo $sql;
	$database->setQuery($sql);
	$database->query();
	$result = $database->loadAssocList();
	
	if(count($result)>0){
		$return = '<b style="color: red;">Your code is valid.</b>';
		echo $return;
	}
	else{
		echo '<b style="color: red;">Code is not exist.</b> please enter an valid code or use <a href="javascript://" onclick="document.getElementById(\'groupcode\').value=\''.$group_code_new.'\';">'.$group_code_new.'</a> to create a new group rating.';
	}		
	
}

function listGroupRating(){
	global $database;
	$group_name = JRequest::getVar("groupname", "");
	
	//$sql = "select * from #__adprin_surveys_session where rater_num=".$rater_num." and group_pos=1"; 
	$sql = "select * from #__adprin_surveys_session where group_name like '%".$group_name."%' and group_pos=1 and rater_num>1"; 
	$database->setQuery($sql);
	$database->query();
	$result = $database->loadAssocList();
	if(count($result)>0){
		$return = '<table border="0" cellpadding="0" cellspacing="0" width="100%">';
		$return .= '<tr class="InfoInputtr"><td>Name of Ad.</td><td>Created by</td><td>Date</td><td>Progress</td><td width="15%">Action</td></tr>';
		//if(count($result) != $value["rater_num"]){
			foreach($result as $key=>$value){
				$sql = "select count(*) from #__adprin_surveys_session where group_code='".$value["group_code"]."'"; 
				$database->setQuery($sql);
				$database->query();
				$count = $database->loadResult();;
				//print_r($count);
				if($count<$value["rater_num"]){
					$return .= '<tr class="InfoInputtr"><td>'.$value["group_name"].'</td><td>'.$value["rater"].'</td><td>'.date("Y-m-d", strtotime($value["played_time"])).'</td><td>'.$count.'/'.$value["rater_num"].'</td><td width="15%">';
					$return .= '<input name="joinbtn" type="button" onclick="joinGroup(\''.$value["group_name"].'\',\''.$value["ad_name"].'\',\''.$value["ad_name_b"].'\','.$value["ad_num"].','.$value["rater_num"].',\''.$value["group_code"].'\',this)" value="Join" class="SmallButton"></input></td></tr>';
				}
			}
		//}
		$return .= '</table>';
		$return .= '<div class="newgroup">Your group not in list? <input name="newgroupbtn" type="button" onclick="newgrouprating()" value="Start a new group rating" class="SmallButton" id="newgroupbtn"></input><span id="userinforesult"></span></div>';
	}
	else{
		$return = '<b style="color: red;">No active rating group exist.</b> You can create a new group rating by click below button';
		$return .= '<div class="newgroup"><input name="newgroupbtn" type="button" onclick="newgrouprating()" value="Start a new group rating" class="SmallButton" id="newgroupbtn"></input><span id="userinforesult"></span></div>';
	}

	echo $return;
}
/*
function submitUserInfo(){
	global $database;	
	$survey_id = JRequest::getVar("id", "", "");
	$session_id = JRequest::getVar("session_id", "", "");
	$next_page_id = JRequest::getVar("next_page_id", "", "");
	$rater_name = JRequest::getVar("ratername", "", "");
	$ad_name = JRequest::getVar("adname", "", "");
	$ad_name_b = JRequest::getVar("adname_b", "", "");
	$comment = JRequest::getVar("comment", "", "");
	$ad_num = JRequest::getVar("ad_num", "", "");
	$rater_num = JRequest::getVar("rater_num", "", "");
	$group_name = JRequest::getVar("groupname", "", "");
	$group_code = JRequest::getVar("groupcode", "", "");
	$new_group_code = JRequest::getVar("new_group_code", "", "");
	$email = JRequest::getVar("email", "", "");
	$timer = JRequest::getVar("duration", "");

	$user =& JFactory::getUser();
	$user_id = $user->id;		
	$jnow =& JFactory::getDate();
	$date =  $jnow->toMySQL();
	$group_pos = 1; 
	$json_arr = array();

	if($next_page_id == "last"){
		$next_page_id = "0";
	}
	$user =& JFactory::getUser();
	$user_id = $user->id;		
	$jnow =& JFactory::getDate();
	$date =  $jnow->toMySQL();
	
	$group_pos = 1;

	if($ad_num == 1) $ad_name_b = "";

	if($rater_num < 2) $group_name = "";

	if($group_code != ""){
		$s_and = '';
		if($session_id != "") $s_and = "and `id`<>".$session_id;
		$sql = "select count(*) from #__adprin_surveys_session where `group_code`='".$group_code."'  ".$s_and; 
		//JFactory::getApplication()->enqueueMessage($sql, 'error');
		$db->setQuery($sql);
		$db->query();
		$group_count = $db->loadResult();
	
		if(count($group_count)>0){
			$group_pos = $group_count+1;
		}

	}else{
		$group_code = $new_group_code;
	}

	if(!$session_id){
		//start new session
		$completed = "0";
		if($next_page_id == "0"){
			//if jump to survey end
			$completed = "1";
		}
		$sql = "insert into #__adprin_surveys_session (`user_id`, `survey_id`, `ip`, `played_time`, `completed`, `last_page_id`, `published`, `rater`, `ad_name`, `ad_name_b`, `note`, `ad_num`, `rater_num`, `group_name`, `group_code`, `email`, `group_pos`) values ".
			   "(".$user_id.", ".$survey_id.", '".$_SERVER['REMOTE_ADDR']."', '".$date."', ".$completed.", ".$next_page_id.", 1, '".$rater_name."', '".$ad_name."', '".$ad_name_b."', '".$comment."', ".$ad_num.", ".$rater_num.", '".$group_name."', '".$group_code."', '".$email."',".$group_pos.")";	
		//echo $sql;
		$db->setQuery($sql);
        $sqlz[] = $sql;
		if($db->query()){
			$sql = "select max(id) from #__adprin_surveys_session";
            $sqlz[] = $sql;
			$db->setQuery($sql);
			$db->query();
			$session_id = $db->loadResult();                
			$_SESSION["session_id"] = $session_id;	
			$json_arr["html"] = '<b style="color: red;">&nbsp;Information Saved.</b>';
			$json_arr["session_id"] = $session_id;
		}else{
			$json_arr["html"] = '<b style="color: red;">&nbsp;Failed.</b>';
		}		
	}		
	else{			
		if($next_page_id == "0"){
			$sql = "update #__adprin_surveys_session set `last_page_id`=0 , `completed`=1 where id=".$session_id;				   
			$db->setQuery($sql);
			$db->query();				
		}
		else{
			//updata existing session
			$sql = "update #__adprin_surveys_session set `last_page_id`=".$next_page_id.", `completed`=0 where id=".$session_id;				   
			$db->setQuery($sql);
			$db->query();
		}
		$_SESSION["session_id"] = $session_id;			
	
	
		$set_sql = '';
		if($rater_name != ""){
			$set_sql .= ",`rater`='".$rater_name."'";
		} 
		
		if($ad_name != ""){
			$set_sql .= ",`ad_name`='".$ad_name."'";
		} 

		if($ad_name_b != ""){
			$set_sql .= ",`ad_name_b`='".$ad_name_b."'";
		} 
		
		if($ad_num != ""){
			$set_sql .= ",`ad_num`=".$ad_num;
		} 
		
		if($rater_num != ""){
			$set_sql .= ",`rater_num`=".$rater_num;
		} 

		if($group_name != ""){
			$set_sql .= ",`group_name`='".$group_name."'";
		} 
		
		if($group_code != ""){
			$set_sql .= ",`group_code`='".$group_code."',`group_pos`=".$group_pos;
		}

		if($comment != ""){
			$set_sql .= ",`note`='".$comment."'";
		}
		
		if($email != ""){
			$set_sql .= ",`email`='".$email."'";
		}
		
		$sql = "update #__adprin_surveys_session set `duration`='".$timer."'".$set_sql.' where id='.$session_id;
		//echo $sql;
		$db->setQuery($sql);
		$db->query();	
		$json_arr["html"] = '<b style="color: red;">&nbsp;Information Saved.</b>';
		$json_arr["session_id"] = $session_id;

	}

	echo json_encode($json_arr);
}

function submitUserInfo(){
	include_once(JPATH_BASE.DS."com_surveys".DS."models".DS."editsurvey.php");
	$es = new adprin_SurveysModelEditSurvey();
	if($es -> save()){
		$json_arr["html"] = '<b style="color: red;">&nbsp;Information Saved.</b>';
		$json_arr["session_id"] = $session_id;
	}else{
		$json_arr["html"] = '<b style="color: red;">&nbsp;Failed.</b>';
	}
	
	//$json_arr["html"] = '<b style="color: red;">&nbsp;Information Saved.</b>';

	echo json_encode($json_arr);
}
*/

function submitUserInfo(){
	global $database;		
	$survey_id = JRequest::getVar("id", "");
	$session_id = JRequest::getVar("sid", "");
	//$session_id = $_SESSION["session_id"];
	$rater_name = JRequest::getVar("ratername", "");
	$ad_name = JRequest::getVar("adname", "");
	$ad_num = JRequest::getVar("ad_num", "");
	$rater_num = JRequest::getVar("rater_num", "");
	$group_code = JRequest::getVar("groupcode", "");
	$email = JRequest::getVar("email", "");
	$duration = JRequest::getVar("duration", "");
	$new_group_code = JRequest::getVar("new_group_code", "");
	$group_name = JRequest::getVar("groupname", "", "");
	$ad_name_b = JRequest::getVar("adname_b", "", "");

	$user =& JFactory::getUser();
	$user_id = $user->id;		
	$jnow =& JFactory::getDate();
	$date =  $jnow->toMySQL();
	$group_pos = 1; 
	$json_arr = array();
	
	if($group_code != ""){
		$s_and = '';
		if($session_id != "") $s_and = "and id<>".$session_id;
		$sql = "select count(*) from #__adprin_surveys_session where group_code='".$group_code."' ".$s_and; 
		//echo $sql;
		$database->setQuery($sql);
		$database->query();
		$group_count = $database->loadResult();
		
		if($group_count>0){
			$group_pos = $group_count+1;
		}	
	}else{
			$group_code = $new_group_code;
	}
	
	//echo $group_code.'#'.$sql.'#'.$session_id."@@@";
	//print_r($result);

	
	if(!$session_id || $session_id == "undefined"){
		//start new session
		$sql = "insert into #__adprin_surveys_session (`user_id`, `survey_id`, `ip`, `played_time`, `completed`, `published`, `rater`, `ad_name`, `ad_name_b`, `ad_num`, `rater_num`, `group_name`, `group_code`, `email`, `group_pos`, `last_page_id`) values ".
			   "(".$user_id.", ".$survey_id.", '".$_SERVER['REMOTE_ADDR']."', '".$date."', 0, 1, '".$rater_name."', '".$ad_name."', ".$ad_num.", '".$ad_name_b."', ".$rater_num.", '".$group_name."', '".$group_code."', '".$email."',".$group_pos.",1)";				 			   
		
		//$sql = "insert into #__adprin_surveys_session (`user_id`, `survey_id`, `ip`, `played_time`, `completed`, `last_page_id`, `published`, `rater`, `ad_name`, `ad_name_b`, `note`, `ad_num`, `rater_num`, `group_name`, `group_code`, `email`, `group_pos`) values ".
		//	   "(".$user_id.", ".$survey_id.", '".$_SERVER['REMOTE_ADDR']."', '".$date."', ".$completed.", ".$next_page_id.", 1, '".$rater_name."', '".$ad_name."', '".$ad_name_b."', '".$comment."', ".$ad_num.", ".$rater_num.", '".$group_name."', '".$group_code."', '".$email."',".$group_pos.")";	
		$database->setQuery($sql);

		if($database->query()){
			$sql = "select max(id) from #__adprin_surveys_session";
			$database->setQuery($sql);
			$database->query();
			$session_id = $database->loadResult();                
			$_SESSION["session_id"] = $session_id;
			$json_arr["html"] = '<b style="color: red;">&nbsp;Information Saved.</b>';
			$json_arr["session_id"] = $session_id;
		}else{
			$json_arr["html"] = '<b style="color: red;">&nbsp;Failed.</b>';
		}			
	}else{
		$set_sql = '';
		if($rater_name != ""){
			$set_sql .= ",`rater`='".$rater_name."'";
		} 
		
		if($ad_name != ""){
			$set_sql .= ",`ad_name`='".$ad_name."'";
		} 

		if($ad_name_b != ""){
			$set_sql .= ",`ad_name_b`='".$ad_name_b."'";
		} 
		
		if($ad_num != ""){
			$set_sql .= ",`ad_num`=".$ad_num;
		} 
		
		if($rater_num != ""){
			$set_sql .= ",`rater_num`=".$rater_num;
		} 
		
		if($group_code != ""){
			$set_sql .= ",`group_code`='".$group_code."',`group_pos`=".$group_pos;
		}

		if($comment != ""){
			$set_sql .= ",`note`='".$comment."'";
		}
		
		if($email != ""){
			$set_sql .= ",`email`='".$email."'";
		}

		if($group_name != ""){
			$set_sql .= ",`group_name`='".$group_name."'";
		} 
		
		$sql = "update #__adprin_surveys_session set `duration`='".$duration."'".$set_sql.' where id='.$session_id;;
		$database->setQuery($sql);
		$database->query();
		$_SESSION["session_id"] = $session_id;	
		$json_arr["html"] = '<b style="color: red;">&nbsp;Information Saved.</b>';
		$json_arr["session_id"] = $session_id;
	}		
	
	//print_r($json_arr);
	echo json_encode($json_arr);
}


/*function updatesql(){
	global $database;
	$sql = "INSERT INTO `dlucd_adprin_surveys_questions` (`id`, `survey_id`, `title`, `type`, `page_id`, `required`, `published`, `other_field`, `other_field_title`, `ordering`, `orientation`, `style`, `description`, `section_id`, `published_up`, `published_down`, `random_a`, `random_c`, `bounded`, `minvalue`, `maxvalue`, `created`, `constant`, `show_on_results`, `question_type`, `nums_menu_heading`, `evidence_num`, `effect_size`, `sequence_num`) VALUES(194, 1, 'Is the opening that directly related to the product, brand or message?', '0', 11, 1, 1, 0, '', 194, 'horizontal', '', '', 85, '2015-07-20 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '2015-07-09 00:00:00', -1, 1, 15, 0, 1, 1, '10.1.1'),(195, 1, 'Is the product or message emphasized?', '0', 11, 1, 1, 0, '', 195, 'horizontal', '', '<p>Violating example: &nbsp;<a href=\"http://advertisingprinciples.com/evaluate-proposals?id=56\" class=\"DescLink\" title=\"Infiniti \">Infiniti</a></p>', 85, '2015-07-20 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '2015-07-09 00:00:00', -1, 1, 15, 0, 1, 1, '10.1.2'),(196, 1, 'If believability is important, is the spokesperson shown on screen?', '0', 11, 1, 1, 0, '', 196, 'horizontal', '', '', 85, '2015-07-20 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '2015-07-09 00:00:00', -1, 1, 15, 0, 4, 1, '10.1.3'),(197, 1, 'Does it use short \"supers\" to reinforce key points?', '0', 11, 1, 1, 0, '', 197, 'horizontal', '', '<p>Violating example: &nbsp;<a href=\"http://advertisingprinciples.com/evaluate-proposals?id=57\" class=\"DescLink\" title=\"Subaru \" >Subaru </a></p>', 85, '2015-07-20 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '2015-07-09 00:00:00', -1, 1, 15, 0, 3, 1, '10.1.4'),(198, 1, 'Is the closing scene relevant to the key message?', '0', 11, 1, 1, 0, '', 198, 'horizontal', '', '<p>Violating example: &nbsp;<a href=\"https://www.youtube.com/watch?v=0E-6qZUWkbE\" class=\"DescLink\" title=\"Hummer\" >Hummer</a></p>', 85, '2015-07-20 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '2015-07-09 00:00:00', -1, 1, 15, 0, 5, 1, '10.1.5'),(199, 1, 'Is the voice appropriate?', '0', 11, 1, 1, 0, '', 199, 'horizontal', '', '', 86, '2015-07-20 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '2015-07-09 00:00:00', -1, 1, 15, 0, 2, 1, '10.2.1'),(200, 1, 'Does it avoid orally ambiguous words?', '0', 11, 1, 1, 0, '', 200, 'horizontal', '', '', 86, '2015-07-20 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '2015-07-09 00:00:00', -1, 1, 15, 0, 1, 1, '10.2.2'),(201, 1, 'If it is an ad for a low-involvement product, does it use music and/or sounds? If it is an ad for a high-involvement product with strong arguments, does it avoid the use of music and sounds?', '0', 11, 1, 1, 0, '', 201, 'horizontal', '', '', 87, '2015-07-20 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '2015-07-09 00:00:00', -1, 1, 15, 0, 4, 1, '10.3.1'),(202, 1, 'If music or sound effects are used, are they relevant to the product?', '0', 11, 1, 1, 0, '', 202, 'horizontal', '', '', 87, '2015-07-20 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '2015-07-09 00:00:00', -1, 1, 15, 0, 4, 1, '10.3.2'),(203, 1, 'If there are simple messages about low-involvement products, does it use rMSd speech?', '0', 11, 1, 1, 0, '', 203, 'horizontal', '', '', 88, '2015-07-20 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '2015-07-09 00:00:00', -1, 1, 15, 0, 3, 1, '10.4.1'),(204, 1, 'If arguments are strong, does it use slow speech?', '0', 11, 1, 1, 0, '', 204, 'horizontal', '', '', 88, '2015-07-20 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '2015-07-09 00:00:00', -1, 1, 15, 0, 3, 1, '10.4.2'),(205, 1, 'Does the ad employ short silences before and/or after strong arguments?', '0', 11, 1, 1, 0, '', 205, 'horizontal', '', '', 88, '2015-07-20 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '2015-07-09 00:00:00', -1, 1, 15, 0, 3, 2, '10.4.3'),(206, 1, 'If the ad is for a high-involvement product, does it hold scenes for strong arguments?', '0', 11, 1, 1, 0, '', 206, 'horizontal', '', '', 88, '2015-07-20 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '2015-07-09 00:00:00', -1, 1, 15, 0, 4, 1, '10.4.4')";	
	$database->setQuery($sql);
	$database->query();
	$sql = "select * from #__adprin_surveys_session";
	$database->setQuery($sql);
	$database->query();
	$result = $database->loadAssocList();
	
	print_r($result);
}
*/
?>