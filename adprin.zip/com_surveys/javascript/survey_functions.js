var AlertText = "Questions requiring a response are marked with an asterisk (*). \n\n";
var form=document.survey_content;

function hasClass(obj, cls) {  
    return obj.className.match(new RegExp('(\\s|^)' + cls + '(\\s|$)'));  
}  
  
function addClass(obj, cls) {  
    if (!this.hasClass(obj, cls)) obj.className += " " + cls;  
}  
  
function removeClass(obj, cls) {  
    if (hasClass(obj, cls)) {  
        var reg = new RegExp('(\\s|^)' + cls + '(\\s|$)');  
        obj.className = obj.className.replace(reg, ' ').trim();  
    }  
}

function replaceClass(obj, frcls, tocls) {  
    if (hasClass(obj, frcls)) {  
        //var reg = new RegExp('/' + frcls + '/g');  
        obj.className = obj.className.replace(frcls, tocls);  
    }  
}   
  
function toggleClass(obj,cls){  
    if(hasClass(obj,cls)){  
        removeClass(obj, cls);  
    }else{  
        addClass(obj, cls);  
    }  
} 

function setentertext(field, ftext){	
	if (ftext!="") {
	    field.value=1;
	}
	else{
		field.value=0;
	}
}

function setentered(field, fieldx, field_other){
	if(fieldx.checked == null || fieldx.checked == false){
		field.value=0;
	}
	else{
		field.value=1;
		if(field_other != "" && field_other != undefined){
			var other_field_input = document.getElementsByName(field_other);
			if (other_field_input.length>0){
				other_field_input[0].value="";
			}
		}
	}
}

function setsum(field,field1){
	if (field.value!=""){
		field1.value=parseFloat(field.value);
		if(field1.value!="NaN"){
			field.value=field1.value;
		}
	}
	else{
		field1.value="";
	}
}

function checkNumber(e, minLen, maxLen, minVal, maxVal, errorMsg){
	var v = parseFloat(e.value);
	if (isNaN(v) || e.value.length < minLen || e.value.length > maxLen || v < minVal || v > maxVal){
		alert(errorMsg);
		e.focus();  
		return false;
	}
	else{ 
		return true;
	}
}

function checkNumberYear(e, minLen, maxLen, minVal, maxVal, errorMsg){
	var v = parseFloat(e.value);
	if (isNaN(v)){
		alert(errorMsg);
		e.focus();  
		return false;
	}
	else{ 
		return true;
	}
}

function validate_required(field,alerttxt){
	with(field){
		if (value==null||value==""){
			alert(alerttxt); return false
		}
		else{
			return true
		}
	}
}

function setselected(field,fieldx,field_other){
	if (fieldx.value==null || fieldx.value==""){
		field.value=0;
	}
	else{
		field.value=1;
		if(field_other!=""&&field_other!=null){
			var other_field_input =document.getElementsByName(field_other);
			if (other_field_input.length>0){
				other_field_input[0].value="";
				var radio_field=document.getElementsByName(fieldx.name);
				if(radio_field.length>1){
					if (radio_field[1].checked!=false){
						radio_field[1].checked=false;
					}
				}
			}
		}
	}
}

function setselectedMatrix(field,fieldx){
	if(fieldx.value==null || fieldx.value==""){
		field.value=0;
	}
	else{
		field.value=1;
	}
}

function getfocus(id){
	document.getElementById("id"+id).focus();
}

function test_select(field,fieldx){
	var field_q=document.getElementsByName(fieldx);
	if(field_q.length>0){
		if (field_q[0].value==null || field_q[0].value==""){
			field.value=0;
		}
		else{
			field.value=1;
		}
		if(field_q[1].checked!=false){
			field_q[1].checked=false;
		}
	}
}

function test_radios(field,fieldx,number){
	var field_q=document.getElementsByName(fieldx);
	if (field_q.length>0){
		if(field_q[0].value==null || field_q[0].value==""){
			field.value=0;
		}
		else{
			field.value=1;
		}
		if(field_q[number].checked!=false){
			field_q[number].checked=false;
		}
	}
}

function change_selected(select_name){
	var selected_input=document.getElementsByName(select_name);
	if (selected_input.length>0){
		if (selected_input[0].selectedIndex!=0){
			selected_input[0].selectedIndex=0;
		}
		if (selected_input[1].checked!=true){
			selected_input[1].checked=true;
		}
	}
}

function change_checked(radio_name, number){
	var radios=document.getElementsByName(radio_name);
	radios[number].checked="true";
}

function OptDisplay(q_id,btn){
	var q  = "qbox" + q_id;
	var qa = "qapp" + q_id;
	var qr1, qr2;
	
	if (btn.value == "0"){
		document.getElementById(q).style.display="none";
		//document.getElementById(qa).value = "0";
		//btn.value="Applicable";
		//replaceClass(btn,"BtnX","BtnW");
		// clear selection
		var is_a = document.getElementsByName("isimp["+q_id+"]");
		var labelQ = document.getElementsByName("labelQ"+q_id);
		is_a[0].value = 0;
		is_a[0].checked = false;
		for(var i = 0; i < labelQ.length; i++){
			if(labelQ[i] != null) removeClass(labelQ[i],"active");
		}
		/*for(var i = 1; i < 5; i++){
			qr1 = "q" + q_id + "a1" + i;
			qr2 = "q" + q_id + "a2" + i;
			var bq_e1 = document.getElementById("b" + qr1);
			var bq_e2 = document.getElementById("b" + qr2);
			//var q_e1 = document.getElementById(qr1);
			//var q_e2 = document.getElementById(qr2);
			if(bq_e1 != null) removeClass(bq_e1,"active");
			
			if(bq_e1 != null) removeClass(bq_e2,"active");
		}*/
	}else{
		document.getElementById(q).style.display="block";
		//document.getElementById(qa).value = "1";
		
		//btn.value="Not Applicable";
		//replaceClass(btn,"BtnW","BtnX");

	}
	
}

function switchlabel(q, v, l){
	var e;
	var en;
	var radios=document.getElementsByName(q.name);

	for(var i=0; i<radios.length; i++){
		en = l+(i+1);
			
		e = document.getElementById(en);
		if(radios[i].value == v){
			addClass(e,"active");
			radios[i].checked = true;
		}else{
			removeClass(e,"active");
			radios[i].checked = false;
		} 

	}
}

function switchActive(e){
	var q = document.getElementById(e);
	
	if(hasClass(q, "active")){
		removeClass(q,"active");
	}else{
		addClass(q,"active");
	}
}

function showTimer(){
	var time_str = document.getElementById("survey_timer").value;
	//alert(time_str);
	var tr = time_str.split(":");
	var h = Number(tr[0]);
	var m = Number(tr[1]);
	var s = Number(tr[2]);
	s=s+1;
	if(s>=60){
		m=m+1;
		s=0;
	}
	if(m>=60){
		h=h+1;
		m=0;
	}
	
	var ss = s;
	var mm = s;
	var hh = h; 
	if(s<10) ss = '0'+s;
	if(m<10) mm = '0'+m;
	if(h<10) hh = '0'+h;
	var timer= hh+":"+mm+":"+ss;
	document.getElementById("survey_timer").value = timer;
	setTimeout('showTimer()',1000); 
}

function selectRaterNum(o){
	var g = document.getElementById("grouplistbox");
	var gn = document.getElementById("groupnamebox");
	var regu = /^[-]{0,1}[0-9]{1,}$/;
	
	if(!regu.test(o.value)){
		alert("Please enter a number");
		return false;
	}
	
	if(o.value < 1){
		alert("Must > 0");
		return false;
	}
	
	/*if(o.value > 1){
		g.style.display="block";
		var link = site + 'components/com_surveys/javascript/ajax.php?task=listGroupRating&rater_num='+o.value;
	
		var req = new Request.HTML({
			method: 'get',
			url: link,
			data: { 'do' : '1' },
			update: $('grouplist'),
			onComplete: function(response){		
			}
		}).send();
		
	}else{
		*/
	if(o.value <= 1){
		g.style.display="none";
		gn.style.display="none";
	}else{
		gn.style.display="block";
	}
}

function getGroupList(o){
	var g = document.getElementById("grouplistbox");
	var rater_num = document.getElementById("rater_num").value;
	
	if(rater_num > 1){
		g.style.display="block";
		var link = site + 'components/com_surveys/javascript/ajax.php?task=listGroupRating&groupname='+o.value;
	
		var req = new Request.HTML({
			method: 'get',
			url: link,
			data: { 'do' : '1' },
			update: $('grouplist'),
			onComplete: function(response){		
			}
		}).send();
	}else{
		g.style.display="none";
	}
}

function verifyGroupCode(gn){
	var g = document.getElementById("groupcode").value;
	if(g == ""){
		alert("Please enter Group Code");
		return false;
	}
	var link = site + 'components/com_surveys/javascript/ajax.php?task=verifyGroupCode&group_code='+g+'&group_code_new='+gn;
	
	var req = new Request.HTML({
		method: 'get',
		url: link,
		data: { 'do' : '1' },
		update: $('code_result'),
		onComplete: function(response){		
		}
	}).send();		
}


function submitUserInfo(){
	var r = document.getElementById("ratername").value;
	if(r == ""){
		alert("Please enter Name of Rater");
		return false;
	}
	
	var a = document.getElementById("adname").value;
	var ab = document.getElementById("adname_b").value;
	if(a == ""){
		alert("Please enter Name of Advertisement");
		return false;
	} 
	
	var an = document.getElementById("ad_num");
	var index  = an.selectedIndex;
	var adnum = an.options[index].value;
	if(adnum == ""){
		alert("Please enter Number of Advertisements");
		return false;
	}
	
	var rn = document.getElementById("rater_num").value;
	if(rn == "" || rn == 0){
		alert("Please enter Number of Raters");
		return false;
	}
	
	var regu = /^[-]{0,1}[0-9]{1,}$/;
	
	if(!regu.test(rn)){
		alert("Please enter a number");
		return false;
	}
	
	var gn = document.getElementById("groupname").value;
	var g = document.getElementById("groupcode").value;
	/*if(rn > 1 && g == ""){
		alert("Please enter Group Code");
		document.getElementById("GroupCode").style.display="block";
		return false;
	}
	*/
	var id = document.getElementById("survey_id").value;
	var sid = document.getElementById("session_id").value;
	var npid = document.getElementById("next_page_id").value;
	var duration = document.getElementById("survey_timer").value;
	var email = document.getElementById("email").value;

	//var new_group_code = document.getElementById("new_group_code").value;
	
	var l = site + 'components/com_surveys/javascript/ajax.php?task=submitUserInfo&groupcode='+g+'&groupname='+gn;
	link = l+'&ratername='+r+'&adname='+a+'&adname_b='+ab+'&ad_num='+adnum+'&rater_num='+rn+'&id='+id+'&sid='+sid+'&npid='+npid+'&duration='+duration+'&email='+email;
	//+'&new_group_code='+new_group_code;
	
	var req = new Request.JSON({
		method: 'get',
		url: link,
		data: { 'do' : '1' },
		//update: $('userinforesult'),
		onSuccess: function(response){	
			//alert(response.session_id);
			document.getElementById("session_id").value = response.session_id
			$('userinforesult').innerHTML=response.html;
			//var json_str = eval('(' + response + ')');  
			//alert(json_str.toJSONString());
		}
	}).send();	
	
}

function newgrouprating(){
	var new_group_code = document.getElementById("new_group_code").value;
	//alert(new_group_code);
	var joinbtn=document.getElementsByName('joinbtn');
	var newgroupbtn=document.getElementById('newgroupbtn');
	var a = document.getElementById("groupname").value;
	if(a == ""){
		alert("Please enter Group Name");
		return false;
	} 
	
	if(newgroupbtn.value == "Cancel"){
		for(var i=0; i<joinbtn.length; i++){
			joinbtn[i].disabled = false;
		}
		document.getElementById("userinforesult").innerHTML="";
		document.getElementById("groupcode").value = "";
		newgroupbtn.value = "Start a new group rating";
	}else{
		for(var i=0; i<joinbtn.length; i++){
			joinbtn[i].disabled = true;
		}
		newgroupbtn.value = "Cancel";
		//removeClass(joinbtn[i],"disabled");
		document.getElementById("groupcode").value = new_group_code;
		submitUserInfo();
	}
	//alert(document.getElementById("groupcode").value);
}

function joinGroup(group_name, aname, aname_b,adnum,rnum,code,o){
	//alert(o.value);
	var joinbtn=document.getElementsByName('joinbtn');
	var newgroupbtn=document.getElementById('newgroupbtn');
	
	if(o.value=="Join"){
		document.getElementById("groupname").value = group_name;
		document.getElementById("adname").value = aname;
		document.getElementById("adname_b").value = aname_b;
		document.getElementById("rater_num").value = rnum;
		document.getElementById("ad_num").selectedIndex = adnum;
		document.getElementById("ad_num").value = adnum;
		document.getElementById("groupcode").value = code;
		
		if(submitUserInfo() == false) return false;
		
		for(var i=0; i<joinbtn.length; i++){
			//addClass(joinbtn[i],"disabled");
			joinbtn[i].disabled = true;
		}
		
		removeClass(o,"disabled");
		o.value = "Cancel";
		o.disabled = false;
		newgroupbtn.disabled = true;
		
	}else{

		for(var i=0; i<joinbtn.length; i++){
			//removeClass(joinbtn[i],"disabled");
			joinbtn[i].disabled = false;
		}
		o.value = "Join";
		document.getElementById("groupcode").value = "";
		document.getElementById("userinforesult").innerHTML="";
		newgroupbtn.disabled = false;
	}
}

function updatesql(){
	var link = site + 'components/com_surveys/javascript/ajax.php?task=updatesql';
	
	var req = new Request.HTML({
		method: 'get',
		url: link,
		data: { 'do' : '1' },
		update: $('userinforesult'),
		onComplete: function(response){		
		}
	}).send();	
}

function noshowif2(obj){
	var p = document.getElementsByName("noshowif2");
	for(var i=0; i<p.length; i++){
		if(obj.value == 1) p[i].style.display= "none";
		else p[i].style.display= "block";
	}

	var AdA = document.getElementById('AdA');
	var AdNameB = document.getElementById('AdNameB');
	//var Ad_A = document.getElementById('adname');
	var Ad_B = document.getElementById('adname_b');
	
	if(obj.value == 1) {
		AdA.innerHTML= "Name of Advertisement";
		AdNameB.style.display = "none";
		//AdNameB.required = null;
		Ad_B.value = "";

	}else{
		AdA.innerHTML= "Name of Advertisement A";
		AdNameB.style.display = "block";
		//AdNameB.required = "required";
	}

}

/*function showgroupname(obj){
	var gn = document.getElementById("groupname");

	if(obj.value > 1){
		gn.style.display = "block";
	}else{
		gn.style.display = "none";
	}
}
*/