<?php

defined ('_JEXEC') or die ("Go away.");


function SurveysBuildRoute(&$query) {
	$user 		=& JFactory::getUser();
	$database	=& JFactory::getDBO();
	$segments 	= array();
		
	if(isset($query['id'])){
		$segments[] = $query['id'];
		unset($query['id']);
	}
	elseif(isset($query['controller'])){
		$segments[] = "0:0";
	}
	
	if (isset($query['page'])){		
		$segments[] = $query['page'];
		unset($query['page']);
	}
	
	if(isset($query['controller'])){		
		$segments[] = $query['controller'];
		unset($query['controller']);
	}
	
	if(isset($query['task'])){		
		$segments[] = $query['task'];
		unset($query['task']);
		
		if(isset($query['q_id'])){		
			$segments[] = $query['q_id'];
			unset($query['q_id']);
		}		
		
		if(isset($query['a_id'])){		
			$segments[] = $query['a_id'];
			unset($query['a_id']);
		}
			
	}			
	return $segments;
}

function SurveysParseRoute($segments){
	$vars = array();		
	if(isset($segments["0"])){
		$vars['id'] = $segments["0"];
	}
	
	if(isset($segments["1"]) && intval($segments["1"]) != 0){
		$vars['page'] = $segments["1"];
	}
	elseif($segments["1"] == "last"){
		$vars["page"] = $segments["1"];
	}
	else{
		$vars["controller"] = $segments["1"];
	}
	
	if(isset($segments["2"])){
		if($segments["2"] != "edit_details"){
			$vars["controller"] = $segments["2"];
		}
	}
	
	if(isset($vars["page"])){
		if(isset($segments["3"])){
			$vars["task"] = $segments["3"];
			if(isset($segments["4"])){
				$vars["q_id"] = $segments["4"];			
			}
			if(isset($segments["5"])){
				$vars["a_id"] = $segments["5"];			
			}
		}
	}
	else{
		if(isset($segments["2"])){
			$vars["task"] = $segments["2"];
			if(isset($segments["3"])){
				$vars["q_id"] = $segments["3"];			
			}
			if(isset($segments["4"])){
				$vars["a_id"] = $segments["4"];			
			}
		}
	}	
	return $vars;
}


?>