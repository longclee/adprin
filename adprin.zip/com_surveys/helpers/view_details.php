<?php

/**
* @author  Chenglong Li
*/

defined('_JEXEC') or die('Restricted access');

class ViewDetails{

	private $_objActiveSheet;

	private $_excelReader;

	private $_objExcel;

	private $_session_detail;

	private $_group_detail;

	private $_mode;

	function ViewDetails(){
	}
	
	function edit(){
		$return  = '<table width="100%">';
		$return .= 		'<tr>';
		$return .= 			'<td>';
		$return .= 				JText::_("COM_SURVEYS_RESPONS_TEXT");
		$return .= 			'</td>';
		$return .= 		'</tr>';
		$return .= '</table>';
		$return .= '<br />';
		$return .= '<table width="100%">';
		$return .= 		'<tr>';
		$return .= 			'<td width="5%">#</td>';
		$return .= 			'<td>';
		$return .= 				'<b>'.JText::_("COM_SURVEYS_VALUE").'</b>';
		$return .= 			'</td>';
		$return .= 		'</tr>';
		
		$question_type = $this->getQuestionType();				
		$responses = $this->getResponses();		
		if(isset($responses) && is_array($responses) && count($responses) > 0){
			$i = 1;
			foreach($responses as $key=>$value){
				$return .= 		'<tr>';
				$return .= 			'<td>'.$i++.'</td>';
				$return .= 			'<td>';
				if($question_type == "13"){
					$return .= date('Y-m-d H-i-s', $value["value"]);
				}
				else{
					$return .= $value["value"];
				}
				$return .= 			'</td>';
				$return .= 		'</tr>';
			}
		}		
		$return .= '</table>';
		
		$return .= '<table width="100%">';
		$return .= 		'<tr>';
		$return .= 			'<td align="center" width="100%">';
		$return .= 				'<input type="button" onclick="javascript:history.go(-1);" value="&lt;&lt; '.JText::_("COM_SURVEYS_BACK").'">';
		$return .= 			'</td>';
		$return .= 		'</tr>';
		$return .= '</table>';
		return $return;
	}
	
	function getResponses(){
		$a_id = JRequest::getVar("a_id", "0");
		$q_id = JRequest::getVar("q_id", "0");
		$r_id = JRequest::getVar("r_id", "0");
		$and = "";
		if($r_id != "0"){
			$and .= " and session_id=".$r_id;
		}
		
		if($a_id == "0"){
			$db =& JFactory::getDBO();
			$sql = "select value from #__adprin_surveys_result_text where question_id=".$q_id.$and;
			$db->setQuery($sql);
			$db->query();
			$result = $db->loadAssocList();
			return $result;
		}
		else{
			$db =& JFactory::getDBO();
			$sql = "select value from #__adprin_surveys_result where a_id=".$a_id.$and;
			$db->setQuery($sql);
			$db->query();
			$result = $db->loadAssocList();
			return $result;
		}
	}
	
	function getQuestionType(){
		$q_id = JRequest::getVar("q_id", "0");
		$db =& JFactory::getDBO();
		$sql = "select question_type from #__adprin_surveys_questions where id=".$q_id;
		$db->setQuery($sql);
		$db->query();
		$result = $db->loadResult();
		return $result;
	}

	function getCount($sessions, $appl, $section_id, $column, $val){
		if(count($sessions)==0) return 0;
		$and = "";
		if($appl != "") $and .= " and a.applicable=".intval($appl);
		if($section_id != "") $and .= " and a.section_id=".intval($section_id);
		if($column != "") $and .= " and a.column_value like '%".$column."%'";
		if($val != "") $and .= " and a.value like '%".$val."%'";
		
		$s_count = count($sessions);
		$key_count = $s_count - 1;
		$session_sql = 'session_id in(';
		foreach($sessions as $ss_key=>$ss_value){
			if($key_count == $ss_key){
				$session_sql .= intval($ss_value["id"]);
			}else{
				$session_sql .= intval($ss_value["id"]).',';
			}
		}
		$session_sql .= ')';
		
		if($column == "") $ad_num = $sessions["0"]["ad_num"];
		else $ad_num = 1;
		
		//JFactory::getApplication()->enqueueMessage($db->stderr(true), 'error');
		$db =& JFactory::getDBO();		
		//$sql = "select sum((a.important+1)*b.evidence_num*b.effect_size) as max_score from #__adprin_surveys_result a,#__adprin_surveys_questions b where session_id=".intval($session_id).' and a.q_id=b.id'.$and;		
		$sql = "select a.q_id as id,sum(a.important/".intval($ad_num).") as imp,sum(a.applicable/".intval($ad_num).") as app,b.evidence_num,b.effect_size from #__adprin_surveys_result a,#__adprin_surveys_questions b where ".$session_sql.' and a.q_id=b.id'.$and.' group by a.q_id';		
		$db->setQuery($sql);
		$db->query();
		$result = $db->loadAssocList();
		$return= array();
		$return["score"] = 0;
		$return["count"] = 0;

		foreach($result as $key=>$val){
			
			if(($val["app"]/$s_count)>=0.5){
				$s = 1;
			}else{
				$s = 0;
			}
			
			if(($val["imp"]/$s_count)>=0.5){
				$i = 1;
				//echo $sql;
			}else{
				$i = 0;
			}
			//print_r($val);
			$return["score"] += ($i+1)*$val["evidence_num"]*$val["effect_size"] * $s;
			//echo $val["id"].'#'.$s_count.'#'.$val["app"].'#'.$val["imp"].'#'.$val["evidence_num"].'#'.$val["effect_size"].'<br />';
			$return["count"] += $s;
			//echo "score:".$return["score"]."||count:".$return["count"]."<br />";
		}
		//print_r($result);
		//echo "---------score:".$return["score"]."||count:".$return["count"]."<br />";
		//echo $sql.'@'.print_r($return)."<br />";
		return $return;
	}
	
	function getMaxScore($session_id, $appl, $section_id, $column, $val){
		$and = "";
		if($appl != "") $and .= " and a.applicable=".intval($appl);
		if($section_id != "") $and .= " and a.section_id=".intval($section_id);
		if($column != "") $and .= " and a.column_value like '%".$column."%'";
		if($val != "") $and .= " and a.value like '%".$val."%'";
		
		//JFactory::getApplication()->enqueueMessage($db->stderr(true), 'error');
		$db =& JFactory::getDBO();		
		$sql = "select sum((a.important+1)*b.evidence_num*b.effect_size) as max_score from #__adprin_surveys_result a,#__adprin_surveys_questions b where session_id=".intval($session_id).' and a.q_id=b.id'.$and;		
		$db->setQuery($sql);
		$db->query();
		$result = $db->loadResult();
		//print_r($result);
		//echo $sql.'@'.$result."<br />";
		return $result;
	}
	
	function getDisSum(){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('distinct summary');
		$query->from('#__adprin_surveys_pages');
		$query->where("summary <>''");		
		$db->setQuery($query);		
		$db->query();		
		$result = $db->loadAssocList();
		//print_r($result);
		return $result;
	}
	
	function getPages($summary){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('*');
		$query->from('#__adprin_surveys_pages');
		$query->where("summary ='".$summary."'");		
		$db->setQuery($query);		
		$db->query();		
		$result = $db->loadAssocList();
		//print_r($result);
		return $result;
	}
	
	function getSessionDetail($session_id){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('*');
		$query->from('#__adprin_surveys_session');
		$query->where("id=".$session_id);
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadAssocList();		
		return $result;
	}
	
	function getGroupDetail($group_code){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('*');
		$query->from('#__adprin_surveys_session');
		$query->where("group_code='".$group_code."' and completed=1");
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadAssocList();		
		return $result;
	}
	
	
	function writeQuestiondata($objActSheet,$survey_id, $session_id){
 
		 
	}
	
	function writeConditiondata($objActSheet,$survey_id, $session_id){
		/*$objActSheet->setCellValue('C6', $this->getResultByQid(183,$session_id));  
		$objActSheet->setCellValue('C8', $this->getResultByQid(184,$session_id));  
		$objActSheet->setCellValue('C10', $this->getResultTextByQid(185,$session_id));  
		$objActSheet->setCellValue('C11', $this->getResultTextByQid(186,$session_id));  
		$objActSheet->setCellValue('C12', $this->getResultTextByQid(187,$session_id));  
		$objActSheet->setCellValue('C14', $this->getResultTextByQid(188,$session_id));  
		$objActSheet->setCellValue('C15', $this->getResultTextByQid(189,$session_id));  
		$objActSheet->setCellValue('C16', $this->getResultTextByQid(190,$session_id));  
		$objActSheet->setCellValue('C17', $this->getResultByQid(191,$session_id));  
		$objActSheet->setCellValue('C18', $this->getResultByQid(192,$session_id)); */
	}
	
	function getQuestionBySection($sql){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('id');
		$query->from('#__adprin_surveys_questions');
		$query->where("sequence_num='".$sequence_num."'");
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadResult();		
		return $result;
	}
	
	function getResultBySection($section, $session_id){
		if($section == "") return array();
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('a.*');
		$query->from('#__adprin_surveys_result a,#__adprin_surveys_questions b');
		$query->where("a.session_id =".intval($session_id)." and a.q_id=b.id and b.sequence_num='".$section."'");
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadAssocList();	
		//echo "a.session_id =".intval($session_id)." and a.q_id=b.id and b.sequence_num='".$section."'";	
		return $result;
	}
	
	function getResultByQid($qid, $session_id){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('b.value');
		$query->from('#__adprin_surveys_result a,#__adprin_surveys_answers b');
		$query->where("a.session_id =".intval($session_id)." and a.q_id=".intval($qid)." and a.a_id=b.id and a.q_id=b.question_id");
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadResult();	
		$result = str_replace("\r","",trim($result));				
		return $result;
	}
	
	function getResultTextByQid($qid, $session_id){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('value');
		$query->from('#__adprin_surveys_result_text');
		$query->where("session_id =".intval($session_id)." and question_id=".intval($qid));
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadResult();		
		//$result = str_replace('\n','',trim($result));		
		
		return trim($result);
	}

	function getSummary($survey_id, $session_id, $survey_details){
		//if (!$session_id) return ""; 
		//echo $survey_id."@".$session_id;
		if($session_id == "") return "Session expired.";
		require_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."classes".DS."PHPExcel.php");
		require_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."classes".DS."PHPExcel".DS."IOFactory.php");
		$template_file = JPATH_ROOT.DS."components".DS."com_surveys".DS."data".DS."template.xls"; 
		
		$session_detail = $this->getSessionDetail($session_id);
		$ad_num = $session_detail["0"]["ad_num"];
		$rater_num = $session_detail["0"]["rater_num"];
		$group_code = $session_detail["0"]["group_code"];
		$mode = JRequest::getVar("mode", "", "get");
		$controller = JRequest::getVar("controller", "", "get"); 

		$group_detail = $this->getGroupDetail($group_code);

		$this->_session_detail = $session_detail;
		$this->_group_detail = $group_detail;
		$this->_mode = $mode;
		
		if(!is_array($group_detail) || count($group_detail) ==0) $group_detail = $session_detail;
		//print_r($group_detail);

		if($rater_num>1 && $rater_num != count($group_detail)) return "<p>Ratings of your group will be sent to ".$session_detail["0"]["email"]." after all raters in ".$session_detail["0"]["group_name"]." finish their ratings.</p>";

		$this->_objExcel = new PHPExcel();   
		$objReader = PHPExcel_IOFactory::createReader('Excel5');
		$this->_excelReader = $objReader->load($template_file);
		$objCloned1= clone $this->_excelReader->getSheetByName('Comparison of Conditions');
		
		$this->_objExcel->getDefaultStyle()->getFont()->setName('Arial');
		$training_title = '';
		$trainee_title = '';

		// training module
		if($mode=="training"){
			
			//JURI::base()."components/com_surveys/data/Persuasion Principles Audit_template.xlsx";
			$training_title = '-TRAINING MODULE';
			$trainee_title = "Trainee's ";
			
			if (file_exists($template_file)) {
				
				//$this->_excelReader = PHPExcel_IOFactory::load($template_file);
				//echo $template_file.'#';
				//$objReader = PHPExcel_IOFactory::createReader('Excel5');
				//$objReader->setLoadSheetsOnly( array("Comparisons of Conditions", "Comparisons of Ratings", "Summary by Experts"));
				//$this->_excelReader = $objReader->load($template_file);
				//$objReader = new PHPExcel_Reader_Excel2007();
				//$objReader->setLoadSheetsOnly( array("Comparisons of Conditions", "Comparisons of Ratings", "Summary by Experts") );
				//$objPHPExcel = $objReader->load($template_file);
				
				$objCloned2= clone $this->_excelReader->getSheetByName('Comparison of Ratings');
				$objCloned3= clone $this->_excelReader->getSheetByName("Experts' Summary");
				$this->_objExcel->addExternalSheet($objCloned1,0);
				$this->_objExcel->addExternalSheet($objCloned2,1);
				$this->_objExcel->addExternalSheet($objCloned3,2);
				$this->_objExcel->setActiveSheetIndex(0); 

				$this->updateConditionSheet("Comparison of Conditions:".$survey_details["0"]["title"].$training_title, "Trainee", 2, $session_id);
				$this->_objExcel->setActiveSheetIndex(1); 
				$this->_objActiveSheet = $this->_objExcel->getActiveSheet();

				$this->updateDetailSheet($session_detail[0], 'Comparison of Ratings: '.$survey_details["0"]["title"].$training_title);
				
				$this->_objExcel->setActiveSheetIndex(3); 
				$objActSheet = $this->_objExcel->getActiveSheet(); 
				$objActSheet->setTitle("Trainee's Summary"); 
				
			}
		}else{
			$this->_objExcel->addExternalSheet($objCloned1,0);
			$this->_objExcel->setActiveSheetIndex(0);
			$objActSheet = $this->_objExcel->getActiveSheet();  
			$objActSheet->setTitle("Conditions");
			$cond_col = 1;
			foreach($group_detail as $g_key=>$g_val){
				$this->updateConditionSheet("Conditions: ".$survey_details["0"]["title"], $g_val['rater'], $cond_col++, $session_id);
			}
			if(count($group_detail) == 1){
				for($i=3; $i<=18; $i++){
					$objActSheet->setCellValueByColumnAndRow(2, $i, '');
					$objActSheet->getStyleByColumnAndRow(2, $i)->getFill()->getStartColor()->setARGB(PHPExcel_Style_Color::COLOR_WHITE);
				}
			}
			
			$objCloned4= clone $this->_excelReader->getSheetByName("Ratings");
			$this->_objExcel->addExternalSheet($objCloned4,1);
			$this->_objExcel->setActiveSheetIndex(1);
			$this->_objExcel->getActiveSheet()->setTitle($group_detail["0"]['rater']);
			$this->updateDetailSheet($group_detail["0"],'Ratings: '.$survey_details["0"]["title"], False);
			
			$sheet_idx = 2;
			foreach($group_detail as $g_key=>$g_val){
				//print_r($g_val);
				if($g_key != 0){
					$objCloned5= clone $this->_objExcel->getActiveSheet();
					$objCloned5->setTitle($g_val['rater']);
					$this->_objExcel->addSheet($objCloned5,$sheet_idx);
					$this->_objExcel->setActiveSheetIndex($sheet_idx);
					
					$this->updateDetailSheet($g_val,'Ratings: '.$survey_details["0"]["title"].' By '.$g_val["rater"], False);
					$sheet_idx++;
					unset($objCloned5);
				}
			}
			 
			$this->_objExcel->setActiveSheetIndex($sheet_idx); 
			//$this->_objExcel->setActiveSheetIndex(1);
			$objActSheet = $this->_objExcel->getActiveSheet(); 
			$objActSheet->setTitle("Summary");
		}

		$objActSheet->getColumnDimension('A')->setWidth(50);    
		$objActSheet->getColumnDimension('B')->setWidth(20);    
		$objActSheet->getColumnDimension('C')->setWidth(20);    
		$objActSheet->getColumnDimension('D')->setWidth(20);    
		$objActSheet->getColumnDimension('E')->setWidth(20);    
		$objActSheet->getColumnDimension('F')->setWidth(20);    
		$objActSheet->getColumnDimension('G')->setWidth(20);    
		$objActSheet->getColumnDimension('H')->setWidth(20);    
		$objActSheet->getColumnDimension('I')->setWidth(20);    
		$objActSheet->getColumnDimension('J')->setWidth(20); 
		$objActSheet->setCellValue('A1', $trainee_title.'Summary - '.$survey_details["0"]["title"].$training_title);   
		$objActSheet->getStyle('A1')->getFont()->setSize(14);	
		$objActSheet->getStyle('A1')->getFont()->setBold(true);	
		$objActSheet->mergeCells('A2:A3'); 
		
		$result =	'<div class="result_box">';
		//$result .=	'<table width="100%" border="0" cellspacing="0" cellpadding="0">';
		//$result .= 		'<tr class="result_header"><td rowspan="2">&nbsp;</td><td rowspan="2">Applicable</td><td colspan="'.($ad_num*2).'" align="center">ADVERTISEMENT A</td>';
		
		$objActSheet->mergeCells('B2:B3');
		$objActSheet->mergeCells('C2:F2');
		$objActSheet->setCellValue('B2', 'Applicable');   
		$objActSheet->setCellValue('C2', 'ADVERTISEMENT A');   
		$objActSheet->setCellValue('C3', 'Applied Well');  
		$objActSheet->setCellValue('D3', 'Needs Improvement');  
		$objActSheet->setCellValue('E3', 'Violated');  
		$objActSheet->setCellValue('F3', 'Not Used'); 
		$styleArray = array(
			'font'    => array(
				'bold'      => true,
				'size'      => 13
			),
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
			),
			'borders' => array(
				'top'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				),
				'bottom'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				),
				'left'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				),
				'right'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				)
			),
			'fill' => array(
	 			'type'       => PHPExcel_Style_Fill::FILL_SOLID,
	 			'startcolor' => array(
	 				'rgb' => '0099ff'
	 			)
	 		)
		);
		
		$objActSheet->getStyle('A2:F2')->applyFromArray($styleArray);
		$objActSheet->getStyle('B2:B3')->applyFromArray($styleArray);
		$objActSheet->getStyle('A3:F3')->applyFromArray($styleArray);
		$objActSheet->getStyle('A3:F3')->getFont()->setSize(12);

		$objActSheet->getStyle('B:J')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
		if($ad_num >1 ) {
			//$result .= '<td colspan="'.($ad_num*2).'" align="center">ADVERTISEMENT B</td>';
			$objActSheet->mergeCells('G2:J2');
			$objActSheet->setCellValue('G2', 'ADVERTISEMENT B');   
			$objActSheet->setCellValue('G3', 'Applied Well');  
			$objActSheet->setCellValue('H3', 'Needs Improvement');  
			$objActSheet->setCellValue('I3', 'Violated');  
			$objActSheet->setCellValue('J3', 'Not Used');  
			$objActSheet->getStyle('G2:J2')->applyFromArray($styleArray);
			$objActSheet->getStyle('G3:J3')->applyFromArray($styleArray);
			$objActSheet->getStyle('G3:J3')->getFont()->setSize(12);
		}
		/*$result .= 		'</tr>';
		$result .= 		'<tr class="result_header"><td>Applied Well</td><td>Needs Improvement</td><td>Violated</td><td>Not Used</td>';
		if($ad_num >1 ) {
			$result .= '<td>Applied Well</td><td>Needs Improvement</td><td>Violated</td><td>Not Used</td>';
		}
		$result .= 		'</tr>';
		*/
		$result2 =  '<table width="100%" border="0" cellspacing="1" cellpadding="0"  style="background-color:#fff;border-spacing: 1px;font-weight:bold;color: #ffffff;font-size:12px;>';
		if($mode=="training"){
			$ad_num++;
			$result2.= 		'<tr style="background-color:#fff;border-spacing: 1px;font-weight:bold;color: #ffffff;text-align:center;">';
			$result2.= 		'<td colspan="'.$ad_num.'" style="color: #ffffff;border-spacing: 1px;background-color: #036;text-align:center;font-weight:bold;">Persuasion Principles Index</td></tr>'; 
			$result2.= 		'<tr style="background-color:#fff;border-spacing: 1px;font-weight:bold;color: #ffffff;text-align:center;">';
			$result2.= 		'<td style="color: #ffffff;border-spacing: 1px;background-color: #036;text-align:center;"></td>';
			$result2.= 		'<td style="color: #ffffff;border-spacing: 1px;background-color: #036;text-align:center;">ADVERTISEMENT A</td>';
			if($ad_num >1 ) $result2.= 		'<td style="color: #ffffff;border-spacing: 1px;background-color: #036;text-align:center;">ADVERTISEMENT B</td>';
			$result2.= 		'</tr>';
		}else{
			$result2.= 		'<tr style="background-color:#fff;border-spacing: 1px;font-weight:bold;color: #ffffff;text-align:center;">';
			$result2.= 		'<td colspan="'.$ad_num.'" style="color: #ffffff;border-spacing: 1px;background-color: #036;text-align:center;font-weight:bold;">Persuasion Principles Index</td></tr>'; 
			$result2.= 		'<tr style="background-color:#fff;border-spacing: 1px;font-weight:bold;color: #ffffff;text-align:center;">';
			//$result2.= 		'<td style="color: #ffffff;border-spacing: 1px;background-color: #036;text-align:center;"></td>';
			$result2.= 		'<td style="color: #ffffff;border-spacing: 1px;background-color: #036;text-align:center;">ADVERTISEMENT A</td>';
			if($ad_num >1 ) $result2.= 		'<td style="color: #ffffff;border-spacing: 1px;background-color: #036;text-align:center;">ADVERTISEMENT B</td>';
			$result2.= 		'</tr>';
		}
			
		//JFactory::getApplication()->enqueueMessage($db->stderr(true), 'error');
		$sum_arr = $this->getDisSum();
		//print_r($sum_arr); 
		$s1 =0;$s2=0;
		$c=1;
		$n=0;
		$all_ms_w_a = 0;
		$all_ms_w_b = 0;
		$all_cs_a = 0;
		$all_cs_b = 0;
		$cell_col = 4;
		$msw_sum_a = array();
		$msw_sum_b = array();
		$cs_sum_a = array();
		$cs_sum_b = array();
		$t = 0;
		
		foreach($sum_arr as $val){
			
			//echo $val["summary"];
			//$result .= '<tr><td colspan="10" align="left" class="result_item">'.$val["summary"].'</td></tr>';
			$objActSheet->setCellValue('A'.$cell_col, $val["summary"]);
			$objActSheet->getStyle('A'.$cell_col++)->getFont()->setBold(true);	
			$sections = $this->getPages($val["summary"]);
			$i1 = 0;$i2= 0;$i3= 0;$i4= 0;$i5= 0;$i6= 0;$i7= 0;$i8= 0;$i9 = 0;
			$p1 =0; $p2=0; $m1=0; $m2=0;
			$ms1 = 0;$ms2 = 0;$ms3 = 0;$ms4 = 0;$ms5 = 0;$ms6 = 0;
			$weight_score_a = 0;
			$max_score_a = 0;
			$weight_score_b = 0;
			$max_score_b = 0;
			
			foreach($sections as $sec_val){
				//echo "A-------------A</br>";
				//$result .= '<tr><td class="text-left">'.$sec_val["title"].'</td>';
				$t++;
				if($mode=="training") $objActSheet->setCellValue('A'.$cell_col, $t.' '.$sec_val["title"]);
				else $objActSheet->setCellValue('A'.$cell_col, $sec_val["title"]);
				$count1 = $this->getCount($group_detail, "1", $sec_val["id"], "", "");
				$app_count1 = $count1["count"];
				$i1 += $app_count1;
				//$result .= '<td>'.$app_count1.'</td>';
				$objActSheet->setCellValue('B'.$cell_col, $app_count1);
				$count2 = $this->getCount($group_detail, "1", $sec_val["id"], "ADVERTISEMENT A", "Applied Well");
				//$ms1 += $this->getMaxScore($session_id, "1", $sec_val["id"], "ADVERTISEMENT A", "Applied Well");
				$ms1 += $count2["score"];
				$i2 += $count2["count"];
				$weight_score_a += 2 * $count2["score"];
				$max_score_a += 2 * $count2["score"];
				//$result .= '<td>'.$count2["count"].'</td>';
				$objActSheet->setCellValue('C'.$cell_col, $count2["count"]);
				$count3 = $this->getCount($group_detail, "1", $sec_val["id"], "ADVERTISEMENT A", "Needs Improvement");
				//$ms2 += $this->getMaxScore($session_id, "1", $sec_val["id"], "ADVERTISEMENT A", "Needs Improvement");
				$ms2 += $count3["score"];
				$i3 += $count3["count"];
				$weight_score_a += $count3["score"];
				$max_score_a += 2 * $count3["score"];
				//$result .= '<td>'.$count3["count"].'</td>';
				$objActSheet->setCellValue('D'.$cell_col, $count3["count"]);
				$count4 = $this->getCount($group_detail, "1", $sec_val["id"], "ADVERTISEMENT A", "Violated");
				//$ms3 += $this->getMaxScore($session_id, "1", $sec_val["id"], "ADVERTISEMENT A", "Violated");
				$ms3 += $count4["score"];
				$i4 += $count4["count"];
				$weight_score_a -= 2 * $count4["score"];
				$max_score_a += 2 * $count4["score"];
				//$result .= '<td>'.$count4["count"].'</td>';
				$objActSheet->setCellValue('E'.$cell_col, $count4["count"]);
				$count5 = $this->getCount($group_detail, "1", $sec_val["id"], "ADVERTISEMENT A", "Not Used");
				$i5 += $count5["count"];
				//$result .= '<td>'.$count5["count"].'</td>';
				$objActSheet->setCellValue('F'.$cell_col, $count5["count"]);
				//echo "B-------------B</br>";
				if($ad_num >1 ){
					$count6 = $this->getCount($group_detail, "1", $sec_val["id"], "ADVERTISEMENT B", "Applied Well");
					//$ms4 += $this->getMaxScore($session_id, "1", $sec_val["id"], "ADVERTISEMENT B", "Applied Well");
					$ms4 += $count6["score"];
					$i6 += $count6["count"];
					$weight_score_b += 2 * $count6["score"];
					$max_score_b += 2 * $count6["score"];
					//echo $sec_val["id"]."wsb-".$weight_score_b.'-----msb-'.$max_score_b."-------------</br>";
					//$result .= '<td>'.$count6["count"].'</td>';
					$objActSheet->setCellValue('G'.$cell_col, $count6["count"]);
					$count7 = $this->getCount($group_detail, "1", $sec_val["id"], "ADVERTISEMENT B", "Needs Improvement");
					//$ms5 += $this->getMaxScore($session_id, "1", $sec_val["id"], "ADVERTISEMENT B", "Needs Improvement");
					$ms5 += $count7["score"];
					$i7 += $count7["count"];
					$weight_score_b += $count7["score"];
					$max_score_b += 2 * $count7["score"];
					//echo $sec_val["id"]."wsb-".$weight_score_b.'-----msb-'.$max_score_b."-------------</br>";
					//$result .= '<td>'.$count7["count"].'</td>';
					$objActSheet->setCellValue('H'.$cell_col, $count7["count"]);
					$count8 = $this->getCount($group_detail, "1", $sec_val["id"], "ADVERTISEMENT B", "Violated");
					$ms6 += $this->getMaxScore($session_id, "1", $sec_val["id"], "ADVERTISEMENT B", "Violated");
					$ms6 += $count8["score"];
					$i8 += $count8["count"];
					$weight_score_b -= 2 * $count8["score"];
					$max_score_b += 2 * $count8["score"];
					//echo $sec_val["id"]."wsb-".$weight_score_b.'-----msb-'.$max_score_b."-------------</br>";
					//$result .= '<td>'.$count8["count"].'</td>';
					$objActSheet->setCellValue('I'.$cell_col, $count8["count"]);
					$count9 = $this->getCount($group_detail, "1", $sec_val["id"], "ADVERTISEMENT B", "Not Used");
					$i9 += $count9["count"];
					//$result .= '<td>'.$count9["count"].'</td>';
					$objActSheet->setCellValue('J'.$cell_col, $count9["count"]);
				}
				//$result .= '</tr>';
				$cell_col++;
			}
			
			/*
			$ms_a = ($ms1+$ms2+$ms3)*2;
			echo '($ms1+$ms2+$ms3)*2=>('.$ms1.'+'.$ms2.'+'.$ms3.')*2#<br/>';
			$ws_a = ($ms1*2+$ms2-$ms3*2);
			echo '($ms1*2+$ms2-$ms3*2)=>'.'('.$ms1.'*2+'.$ms2.'-'.$ms3.'*2)#<br/>';
			*/
			//$all_ms_w_a = ($weight_score_a/$max_score_a)*0.5;
			array_push($msw_sum_a, $weight_score_a/$max_score_a);
			//if($session_id==38) echo  'weight_score_a-'.$weight_score_a.'/max_score_a-'.$max_score_a.'<br/>';
			//$all_cs_a = ($i2/$i1)*0.5;
			array_push($cs_sum_a, $i2/$i1);
			//if($session_id==38) echo '$i2-'.$i2.'|$i1-'.$i1.'<br/>';
			
			if($ad_num >1 ) {
				/*$ms_b = ($ms4+$ms5+$ms6)*2;
				$ws_b = ($ms4*2+$ms5-$ms6*2);*/
				//$all_ms_w_b = ($weight_score_b/$max_score_b)*0.5;
				array_push($msw_sum_b, $weight_score_b/$max_score_b);
				//echo 'weight_score_b-'.$weight_score_b.'/max_score_b-'.$max_score_b.'|<br/>';
				//$all_cs_b = ($i6/$i1)*0.5;
				array_push($cs_sum_b, $i6/$i1);
				//echo '$i6-'.$i6.'|$i1-'.$i1.'<br/>';
				//echo 'all_ms_w_b:'.$all_ms_w_b.'#all_cs_b:'.$all_cs_b.'#ms_b:'.$ms_b.'#ws_b:'.$ws_b;
			}
			
			
			//$result .= '<tr><td align="left">Number of Potentially Relevant Principles</td><td>'.$i1.'</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>';
			$objActSheet->setCellValue('A'.$cell_col, "Number of Potentially Relevant Principles");
			//if($ad_num >1 ) $result .= '<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>';
			$objActSheet->setCellValue('B'.$cell_col, $i1);
			$cell_col++;
			//$result .= '</tr>';
			//$result .= '<tr><td align="left">Number of Principles Applied Well (*2)</td><td>&nbsp;</td><td>'.$i2.'</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>';
			$objActSheet->setCellValue('A'.$cell_col, "Number of Principles Applied Well");
			$objActSheet->setCellValue('C'.$cell_col, $i2);
			if($ad_num >1 ) {
				//$result .= '<td>'.$i6.'</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>';
				$objActSheet->setCellValue('G'.$cell_col, $i6);
			}
			$cell_col++;
			//$result .= '</tr>';
			//$result .= '<tr><td align="left">Number of Relevant Principles for Improvement</td><td>&nbsp;</td><td>&nbsp;</td><td>'.$i3.'</td><td>&nbsp;</td><td>&nbsp;</td>';
			$objActSheet->setCellValue('A'.$cell_col, "Number of Relevant Principles for Improvement");
			$objActSheet->setCellValue('D'.$cell_col, $i3);
			if($ad_num >1 ) {
				///$result .= '<td>&nbsp;</td><td>'.$i7.'</td><td>&nbsp;</td><td>&nbsp;</td>';
				$objActSheet->setCellValue('H'.$cell_col, $i7);
			}
			$cell_col++;
			//$result .= '</tr>';
			//$result .= '<tr><td align="left">Number of Principles  Violated (*-2)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>'.$i4.'</td><td>&nbsp;</td>';
			$objActSheet->setCellValue('A'.$cell_col, "Number of Principles  Violated");
			$objActSheet->setCellValue('E'.$cell_col, $i4);
			if($ad_num >1 ) {
				//$result .= '<td>&nbsp;</td><td>&nbsp;</td><td>'.$i8.'</td><td>&nbsp;</td>';
				$objActSheet->setCellValue('I'.$cell_col, $i8);
			}
			$cell_col++;
			//$result .= '</tr>';
			//$result .= '<tr><td align="left">Number of Relevant Principles not used</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>'.$i5.'</td>';
			$objActSheet->setCellValue('A'.$cell_col, "Number of Relevant Principles not used");
			$objActSheet->setCellValue('F'.$cell_col, $i5);
			if($ad_num >1 ) {
				//$result .= '<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>'.$i9.'</td>';
				$objActSheet->setCellValue('J'.$cell_col, $i9);
			}
			$cell_col++;
			//$result .= '</tr>';
			
			
			/*$p1 = $i2+$i3+$i4;
			$m1 = (2*$i2+$i3-2*$i4)/(2*$p1);
			$p2 = $i6+$i7+$i8;
			$m2 = (2*$i6+$i7-2*$i8)/(2*$p2);
			$s1 += $m1*0.5;
			$s2 += $m2*0.5;
			$result2.= 		'<tr><td rowspan="2">'.$val["summary"].'</td><td>Principles Used</td><td>'.$p1.'</td><td>'.$p2.'</td></tr>';
			$result2.= 		'<tr><td class="text-center">MS for strategy</td><td>'.round($m1*100,2).'%'.'</td><td>'.round($m2*100,2).'%'.'</td></tr>';*/
			
/* 			switch($val["value"]){
				case "Applied Well" : {
					$ans_r["1"] += $val["sum"];
					break;
				}
				case "Needs Improvement" : {
					$ans_r["2"] = $val["sum"];
					break;
				}
				case "Violated" : {
					$ans_r["3"] = $val["sum"];
					break;
				}
				case "Not Used" : {
					$ans_r["4"] = $val["sum"];
					break;
				}
			} */
			
		}

		/*
		if($session_id==38){
			print_r($msw_sum_a);
		    print_r($msw_sum_b);
		    print_r($cs_sum_a);
			print_r($cs_sum_b);
		}
		*/
		$all_ms_w_a = array_sum($msw_sum_a)/count($msw_sum_a);
		$all_cs_a = array_sum($cs_sum_a)/count($cs_sum_a);
		$all_ms_w_b = array_sum($msw_sum_b)/count($msw_sum_b);
		$all_cs_b = array_sum($cs_sum_b)/count($cs_sum_b);
		
		$ppi_a = ($all_ms_w_a+$all_cs_a)/2;
		if($ad_num >1 ) $ppi_b = ($all_ms_w_b+$all_cs_b)/2;
		
		if($mode=="training"){
			$result2.= 		'<tr style="background-color:#fff;border-spacing: 1px;font-weight:bold;color: #ffffff;text-align:center;">';
			$result2.= 		'<td style="color: #ffffff;border-spacing: 1px;background-color: #036;text-align:center;font-weight:bold;">Experts</td>';
			$result2.= 		'<td style="color: #ffffff;border-spacing: 1px;background-color: #036;text-align:center;font-weight:normal;">35%</td>';
			if($ad_num >1 ) $result2.= 	'<td style="color: #ffffff;border-spacing: 1px;background-color: #036;text-align:center;font-weight:normal;">50%</td>';
			$result2.=   '</tr>';
			$result2.= 		'<tr style="background-color:#fff;border-spacing: 1px;font-weight:bold;color: #ffffff;text-align:center;">';
			$result2.= 		'<td style="color: #ffffff;border-spacing: 1px;background-color: #036;text-align:center;font-weight:bold;">Trainee</td>';
			$result2.= 		'<td style="color: #ffffff;border-spacing: 1px;background-color: #036;text-align:center;font-weight:normal;">'.round($ppi_a*100,0).'%'.'</td>';
			if($ad_num >1 ) $result2.= 	'<td style="color: #ffffff;border-spacing: 1px;background-color: #036;text-align:center;font-weight:normal;">'.round($ppi_b*100,0).'%'.'</td>';
			$result2.=   '</tr>';
		}else{
			//$result2.= 		'<tr style="background-color:#fff;border-spacing: 1px;font-weight:bold;color: #ffffff;text-align:center;">';
			//$result2.= 		'<td style="color: #ffffff;border-spacing: 1px;background-color: #036;text-align:center;">Experts</td>';
			//$result2.= 		'<td style="color: #ffffff;border-spacing: 1px;background-color: #036;text-align:center;font-weight:normal;">35%</td>';
			//if($ad_num >1 ) $result2.= 	'<td style="color: #ffffff;border-spacing: 1px;background-color: #036;text-align:center;font-weight:normal;">50%</td>';
			//$result2.=   '</tr>';
			$result2.= 		'<tr style="background-color:#fff;border-spacing: 1px;font-weight:bold;color: #ffffff;text-align:center;">';
			//$result2.= 		'<td style="color: #ffffff;border-spacing: 1px;background-color: #036;text-align:center;">Trainee</td>';
			$result2.= 		'<td style="color: #ffffff;border-spacing: 1px;background-color: #036;text-align:center;font-weight:normal;">'.round($ppi_a*100,0).'%'.'</td>';
			if($ad_num >1 ) $result2.= 	'<td style="color: #ffffff;border-spacing: 1px;background-color: #036;text-align:center;font-weight:normal;">'.round($ppi_b*100,0).'%'.'</td>';
			$result2.=   '</tr>';
		}
		$result2.=   '</table>';

		//$result .= 	'</table><br /><br />'.$result2.'</div>';
		$result .=  $result2.'</div>';
		//echo $return;
		
		$cell_col= $cell_col+3;
		
		$objActSheet->setCellValue('C'.$cell_col, 'Persuasion Principles Index');  

		$styleArray2 = array(
			'font'    => array(
				'bold'      => true,
				'size'      => 14
			),
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
			),
			'borders' => array(
				'top'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				),
				'bottom'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				),
				'left'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				),
				'right'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				)
			),
			'fill' => array(
	 			'type'       => PHPExcel_Style_Fill::FILL_SOLID,
	 			'startcolor' => array(
	 				'rgb' => 'ffcc33'
	 			)
	 		)
		);
		
		$styleArray3 = array(
			'font'    => array(
				'bold'      => true,
				'size'      => 13
			),
			'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
			),
			'borders' => array(
				'top'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				),
				'bottom'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				),
				'left'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				),
				'right'     => array(
 					'style' => PHPExcel_Style_Border::BORDER_THIN
 				)
			),
			'fill' => array(
	 			'type'       => PHPExcel_Style_Fill::FILL_SOLID,
	 			'startcolor' => array(
	 				'rgb' => 'ffffff'
	 			)
	 		)
		);
		
			
		if($ad_num >1 ) {
			$objActSheet->mergeCells('C'.$cell_col.':F'.$cell_col);
			$objActSheet->getStyle('C'.$cell_col.':'.'F'.$cell_col)->applyFromArray($styleArray2);
		}else{
			$objActSheet->mergeCells('C'.$cell_col.':D'.$cell_col);
			$objActSheet->getStyle('C'.$cell_col.':'.'D'.$cell_col)->applyFromArray($styleArray2);
		}
		
		$cell_col++;
		$objActSheet->setCellValue('C'.$cell_col, 'ADVERTISEMENT A'); 
		$objActSheet->mergeCells('C'.$cell_col.':D'.$cell_col);
		$objActSheet->getStyle('C'.$cell_col.':'.'D'.$cell_col)->applyFromArray($styleArray3);
		if($ad_num >1 ) {
			$objActSheet->setCellValue('E'.$cell_col, 'ADVERTISEMENT B'); 
			$objActSheet->mergeCells('E'.$cell_col.':F'.$cell_col);
			$objActSheet->getStyle('E'.$cell_col.':'.'F'.$cell_col)->applyFromArray($styleArray3);
		}
		$cell_col++;		
		$objActSheet->setCellValue('C'.$cell_col, round($ppi_a*100,0).'%');  
		$objActSheet->mergeCells('C'.$cell_col.':D'.$cell_col);
		$objActSheet->getStyle('C'.$cell_col.':'.'D'.$cell_col)->applyFromArray($styleArray3);
		if($ad_num >1 ) {
			$objActSheet->setCellValue('E'.$cell_col,round($ppi_b*100,0).'%');
			$objActSheet->mergeCells('E'.$cell_col.':F'.$cell_col);
			$objActSheet->getStyle('E'.$cell_col.':'.'F'.$cell_col)->applyFromArray($styleArray3);
		}

		$filename = $survey_details["0"]["title"]."_".$session_id.$training_title.".xls";

		$outputFileName = JPATH_ROOT.DS."components".DS."com_surveys".DS."data".DS.$filename;  
		$linksrc = JURI::base()."components/com_surveys/data/".$filename;  

		$excellink = '<p class="exceldownload"><b><a href="'.$linksrc.'" target="_blank" alt="Summary Excel">Download the result as Excel</a></b></p>';
		
		$result = $excellink.$result;

		/*if ($controller == "statistics"){
			$outputFileName = str_replace('.xlsx', '.html', basename($inputFileName));
			$objWriter = PHPExcel_IOFactory::createWriter($this->_objExcel, 'HTML');  
			$objWriter->save($outputFileName);
		}{*/
			$objWriter = PHPExcel_IOFactory::createWriter($this->_objExcel, 'Excel5');  
			$objWriter->save($outputFileName);
			//$htmlFileName = str_replace('.xls', '.html', basename($outputFileName));
			//$htmlobjWriter = PHPExcel_IOFactory::createWriter($this->_objExcel, 'HTML');  
			//$htmlobjWriter->save($htmlFileName);
		//}

		$this->updateLink($group_code, $outputFileName);
		

		//echo '#'.$mail_result.'#'.JFactory::getApplication()->getCfg('mailfrom').'#'.JFactory::getApplication()->getCfg('fromname').'#'.$session_detail["0"]["email"].'#'.$linksrc;

		$body = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';

		$body .= '<html xmlns="http://www.w3.org/1999/xhtml">';
		$body .= '　<head>';
		$body .= '　　<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />';
		$body .= '　　<title>SUMMARY - '.$survey_details["0"]["title"].'</title>';
		$body .= '　　<meta name="viewport" content="width=device-width, initial-scale=1.0"/>';
		$body .= '　</head>';	
		$body .= '	<body>';	
		$body .= 	$result;	
		$body .= '	</body>';
		$body .= '</html>';
		
		//$mail_result = JUtility::sendMail(JFactory::getApplication()->getCfg('mailfrom'), JFactory::getApplication()->getCfg('fromname'), 'allen_gw@163.com', 'SUMMARY - '.$survey_details["0"]["title"], $body, true);//, '', '', $linksrc);	
		
			// Get the Mailer
		$mailer = JFactory::getMailer();
		$app = JFactory::getApplication();
		//$params = JComponentHelper::getParams('com_users');

		// Build email message format.
		$mailer->setSender(array($app->getCfg('mailfrom'), $app->getCfg('fromname')));
		$mailer->setSubject('SUMMARY - '.$survey_details["0"]["title"]);
		$mailer->setBody($body);
		$mailer->IsHTML(true);
		//$mailer->IsSMTP();
		//$mailer->SMTPDebug=true;
		//echo $mailer->Host.$mailer->Port.$mailer->Username;

		// Add recipients
		if($rater_num>1){
			$maillist = array();
			foreach($group_detail as $g_key=>$g_val){
				if($g_val["email"] != "" && !in_array(trim($g_val["email"]), $maillist)){
					array_push($maillist,trim($g_val["email"]));
					//$mailer->addBCC($g_val["email"]);
					//echo $g_val["email"];
					//$mailer->addRecipient($g_val["email"]);
				}
			}
			$mailer->addRecipient($maillist);
		}else{
			$mailer->addRecipient($session_detail["0"]["email"]);
		}
		
		$mailer->AddAttachment($outputFileName);

		//ini_set('display_errors', '1');

		// Send the Mail
		$rs	= $mailer->Send();

		// Check for an error
		if ($rs instanceof Exception) {
			$result =  '<p>Error!Failed to sent the summary result to '.$session_detail["0"]["email"].'</p>'.$result;
		} elseif (empty($rs)) {
			$result =  '<p>Error!Failed to sent the summary result to '.$session_detail["0"]["email"].'</p>'.$result;
		} else {
			// Fill the data (specially for the 'mode', 'group' and 'bcc': they could not exist in the array
			// when the box is not checked and in this case, the default value would be used instead of the '0'
			// one)
			$result =  '<p>Successfully sent the summary result to '.$session_detail["0"]["email"].'</p>'.$result;
		}

		$this->_excelReader->disconnectWorksheets();
		unset($this->_excelReader);
		$this->_objExcel->disconnectWorksheets();
		unset($this->_objExcel);

		return $result;
	}

	function updateLink($group_code, $link){	
		$db =& JFactory::getDBO();
		$sql = 'update #__adprin_surveys_session set excel = "'.$link.'" where group_code="'.$group_code.'"';
		$db->setQuery($sql);
		$db->query();
		return $sql;
	}

	function updateDetailSheet($group_detail, $title, $is_bg = TRUE){

		$objActSheet = $this->_objExcel->getActiveSheet();

		$session_id = $group_detail['id'];
		$objActSheet->setCellValue('A1', $title);
		if(!$is_bg){
			$objActSheet->setCellValue('B2', $group_detail['rater']);
			$objActSheet->setCellValue('B3', $group_detail['played_time']);
			$objActSheet->setCellValue('B4', $group_detail['duration']);
		}//print_r($group_detail);
		//echo "#";

		for($row=5; $row<=296;$row++){
			$section = $objActSheet->getCell('A'.$row)->getValue();
			//echo $section.'<br />'.$row.'#'.$session_id."<br />";
			$rs = $this->getResultBySection(trim($section), $session_id);
			$orig_val_i= $objActSheet->getCell('C'.$row)->getValue();
			//print_r($rs);

			foreach($rs as $rkey=>$rval){
				if($rval["applicable"]==1){					
					$objActSheet->setCellValue('C'.$row, "1");  //setCellValueByColumnAndRow(1, 8, 'Some value');
					$objActSheet->getStyle('C'.$row)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLACK);
					
					if($is_bg){
						if($orig_val_i == 1) {
							$objActSheet->getStyle('C'.$row)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
							$objActSheet->getStyle('C'.$row)->getFill()->getStartColor()->setARGB(PHPExcel_Style_Color::COLOR_GREEN);
						}else{
							$objActSheet->getStyle('C'.$row)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
							$objActSheet->getStyle('C'.$row)->getFill()->getStartColor()->setARGB(PHPExcel_Style_Color::COLOR_YELLOW);
						}
					}

					if($rval["important"] == 1){
						$objActSheet->setCellValue('L'.$row, "1");  //setCellValueByColumnAndRow(1, 8, 'Some value');
						$objActSheet->getStyle('L'.$row)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLACK);
					}
					$ab_col = 0;

					switch(trim($rval["column_value"])){
						case "ADVERTISEMENT A":
							$ab_col = 2;
							break;
						case "ADVERTISEMENT B":
							$ab_col = 6;
							break;
					}

					
					
					if($ab_col != 0){
						$opt_col = 0;
						//echo trim($rval["value"]);
						switch(trim($rval["value"])){
							case "Applied Well":
								$opt_col = 1;
								break;
							case "Needs Improvement":
								$opt_col = 2;
								break;
							case "Violated":
								$opt_col = 3;
								break;
							case "Not Used":
								$opt_col = 4;
								break;
						}
						if($opt_col !=0){
							$col = $ab_col + $opt_col;
							
							$orig_val = $objActSheet->getCellByColumnAndRow($col, $row)->getValue();
							/*for($i=$ab_col+1; $i<$ab_col+5; $i++){
								$objActSheet->setCellValueByColumnAndRow($i, $row, '');
							}*/
							$objActSheet->setCellValueByColumnAndRow($col, $row, '1');
							/*if($opt_col == 4){
								echo "<br />".$col.'#'.$row."<br />";
								echo $objActSheet->getCellByColumnAndRow($col, $row)->getValue();
							}*/
							$objActSheet->getStyleByColumnAndRow($col, $row)->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_BLACK);
							
							if($is_bg){
								$objActSheet->getStyleByColumnAndRow($col, $row)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
							
								if($orig_val == 1){
									$objActSheet->getStyleByColumnAndRow($col, $row)->getFill()->getStartColor()->setARGB(PHPExcel_Style_Color::COLOR_GREEN);
								}else{
									$objActSheet->getStyleByColumnAndRow($col, $row)->getFill()->getStartColor()->setARGB(PHPExcel_Style_Color::COLOR_YELLOW);

								}
							}
						}
					}
				}
			}
			
			
		}
	}

	function updateConditionSheet($title, $name, $col, $session_id){

		$objActSheet = $this->_objExcel->getActiveSheet();

		$objActSheet->duplicateStyle($objActSheet->getStyle('B6'), 'E6');

		$objActSheet->setCellValue('A1', $title); 
		$col_str = PHPExcel_Cell::stringFromColumnIndex($col);
		$objActSheet->getColumnDimension($col_str)->setWidth(25);
		//echo $col_str;

		$objActSheet->setCellValueByColumnAndRow($col,'3', "Conditions by ".$name);  
		$objActSheet->setCellValueByColumnAndRow($col,'6', $this->getResultByQid(183,$session_id));  
		$objActSheet->setCellValueByColumnAndRow($col,'7', $this->getResultByQid(207,$session_id)); 
		$objActSheet->setCellValueByColumnAndRow($col,'9', $this->getResultByQid(184,$session_id));  
		$objActSheet->setCellValueByColumnAndRow($col,'10', $this->getResultByQid(185,$session_id));  
		$objActSheet->setCellValueByColumnAndRow($col,'11', $this->getResultByQid(186,$session_id));  
		$objActSheet->setCellValueByColumnAndRow($col,'12', $this->getResultByQid(187,$session_id));  
		$objActSheet->setCellValueByColumnAndRow($col,'14', $this->getResultTextByQid(188,$session_id));  
		$objActSheet->setCellValueByColumnAndRow($col,'15', $this->getResultTextByQid(189,$session_id));  
		$objActSheet->setCellValueByColumnAndRow($col,'16', $this->getResultTextByQid(190,$session_id));  
		$objActSheet->setCellValueByColumnAndRow($col,'17', $this->getResultByQid(191,$session_id));  
		$objActSheet->setCellValueByColumnAndRow($col,'18', $this->getResultByQid(192,$session_id)); 

		for($i=3; $i<=19; $i++){
			$objActSheet->duplicateStyle($objActSheet->getStyle('B'.$i), $col_str.$i);
		}
		

	}


};
?>