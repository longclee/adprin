<?php

/**
* @author  Chenglong Li
*/

defined('_JEXEC') or die('Restricted access');

class QuestionsList{
	
	function getQuestionsList($survey_id, $current_page_id, $params, $completed, $session_id,$next_page){
		$all_questions = $this->getAllQuestions($survey_id, $current_page_id);
		$preview = JRequest::getVar("previews_page_id", "");		
		$return = '<div class="PagePanel">';
		$validation_form = 'function validate_form(thisform) {'."\n";
		
		if(count($all_questions)>0){
			foreach($all_questions as $key=>$question){
				$question_details = $this->getQuestionDetails($question["id"]);
				$id = $question_details["0"]["id"];
				$orientation = $question_details["0"]["orientation"];
				$question_type = $question_details["0"]["question_type"];
				$section_id = $question_details["0"]["section_id"];
							
				$question = new Question($id, $survey_id, $orientation, $question_type, $params, $question_details, $completed, $session_id);				
				$result = $question->display();
				$validation_form .= $result["validation"]."\n";
				
				//$return .= '<tr>';
				//Get section
				
				$section_pos =$this->getSectionPos($section_id,$id);
				
				//echo "@@".$question_details["0"]["section_id"]."||".$section_pos;
				if ($section_pos == "first" || $section_pos == "one"){
					$return .= 	'<div class="SectionPanel">';
					$section_detail = $this->getSectionDetails($section_id);
					$return .= 		'<div class="SectionName">'.$section_detail["0"]["section_num"].'&nbsp;'.$section_detail["0"]["title"].'</div>';
				}
				
				$return .= 	   		'<div class="QuestionPanel">';
				$return .= 	   	$result["content"];	
				$return .= 	   		'</div>';
				if ($section_pos == "last" || $section_pos == "one"){
					$return .= 	'</div>';
				}
				//$return .= '</tr>';
			}
		}
		
		//$return .= 		"<tr width=\"100%\">";
		$return .=	'</div>';
		$return .=	'<div class="PageBox">';
		$return .= 		 		"<table width=\"100%\">";
		$return .= 					"<tr width=\"100%\">";		
		
		$pages = $this->getAllPages($survey_id);	
		
		if(isset($pages) && isset($pages["0"]) && is_array($pages) && $current_page_id != $pages["0"]["id"] && $params->general_value != "ORpRFO"){	
			$return .= 			"<td align=\"right\" width=\"45%\">";
			$return .= 			 '<input type="submit" onclick="document.survey_content.task.value=\'back\'" class="'.$params->button.'" value="&lt;&lt; '.JText::_("COM_SURVEYS_BACK").'" name="Back">';
			$return .= 			"</td>";
		}
		else{
			$return .= 			"<td align=\"right\" width=\"45%\">";			
			$return .= 			"</td>";
		}
		$return .= 			'<td align="center" valign="center" width="10%">('.$current_page_id.'/'.count($pages).')</td>';
		$return .= 			"<td align=\"left\" width=\"45%\">";
		
		// next botton for preview in admin
		$controller = JRequest::getVar("controller", "", "get");
		if(isset($pages) && isset($pages["0"])){
			if($next_page == "last"){
				$return .= '<input type="submit" onclick="return validate_form(form);" class="'.$params->button.'" value="'.JText::_("COM_SURVEYS_SUBMIT").' &gt;&gt;" name="submit">';
			}
			else{			
				$return .= '<input type="submit" onclick="return validate_form(form)" class="'.$params->button.'" value="'.JText::_("COM_SURVEYS_NEXT").' &gt;&gt;" name="submit">';
			}
		}	
		$return .= 			"</td>";
		$return .= 					"</tr>";
		$return .= 		 		"</table>";
		//$return .= 		 	"</td>";
		//$return .= 		 "</tr>";		
		$return .= '</div>';	
		
		if($controller != "" && $controller == "prevsurvey"){
			$validation_form .= '	document.survey_content.task.value="next";'."\n";
		}
		else{	
			$validation_form .= '	document.survey_content.task.value="save_survey";'."\n";
		}	
		$validation_form .= "}";
		$document =& JFactory::getDocument();
		$document->addScriptDeclaration($validation_form);	
		return $return;
	}
	
	function getAllPages($survey_id){
		$skip_pages = "";
		if(isset($_SESSION["skip_pages"]) && isset($_SESSION["skip_pages"]) !=""){
			$skip_pages = ' and id not in('.$_SESSION["skip_pages"].')';
		}
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('id');
		$query->from('#__adprin_surveys_pages');
		$query->where("survey_id=".$survey_id." and published=1");
		$query->order("ordering asc");
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadAssocList();	
		//echo $query.'%%%';
		return $result;
	}
	
	function getAllQuestions($survey_id, $current_page_id){
		$data = new JDate();
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();
		$query->select('id, question_type');
		$query->from('#__adprin_surveys_questions');
		$query->where("survey_id=".$survey_id." and page_id=".intval($current_page_id)." and published=1 and published_up <= '".$data."' and ((published_down >= '".$data."') or published_down='0000-00-00 00:00:00')");
		$query->order("ordering asc");
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadAssocList();
		return $result;
	}
	
	function getQuestionDetails($id){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();
		$query->select('*');
		$query->from('#__adprin_surveys_questions');
		$query->where("id=".$id);
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadAssocList();		
		return $result;	
	}

	function getSectionPos($section_id, $question_id){
		if ($section_id==0 && $section_id=="") return "";
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('a.id,a.section_id');
		$query->from('#__adprin_surveys_questions a');
		$query->where("a.section_id=".intval($section_id));		
		$query->order("ordering asc");
		$db->setQuery($query);		
		$db->query();
		$rlist = $db->loadAssocList();	
		//return $rlist;
		$result = "";
		$rcount = count($rlist)-1;
		//return $rcount;
		
		if ($rcount < 0) $result = "";
		
		if($rcount == 0) $result = "one";
		
		if ($rcount > 0 && $rlist["0"]["id"] == $question_id) $result = "first";
		
		if($rcount > 0 && $rlist[$rcount]["id"] == $question_id) $result = "last";
			
		return $result;
	}
	
	function getSectionDetails($id){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();
		$query->select('*');
		$query->from('#__adprin_surveys_sections');
		$query->where("id=".$id);
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadAssocList();		
		return $result;	
	}
	
};

class Question{
	var $_orientation = "";
	var $_question_id = "";
	var $_survey_id = "";
	var $_class = "";
	var $_params = "";
	var $_question_details = "";
	var $_completed = "";
	var $_session_id = "";
	
	function Question($quest_id="0", $survey_id="0", $orien="", $type="", $params="", $question_details="", $completed="", $session_id="0"){
		$this->_orientation = $orien;
		$this->_question_id = $quest_id;
		$this->_survey_id = $survey_id;
		$this->_class = $this->getClass($type);	
		$this->_params = $params;
		$this->_question_details = $question_details;
		$this->_completed = $completed;
		$this->_session_id = intval($session_id);
	}
	
	function display(){
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionEssay.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionMultiplePerRow.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionOneAnswer.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionOneAnswerMenu.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionMultipleAnswer.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionOnePerRow.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionEndedOneLine.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionEndedMoreLines.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionConstant.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionDateTime.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionRating.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionMultiplePerRowMenus.php");
		
		$total_class = "Question".$this->_class;
		$question = new $total_class();		
		$result = $question->display($this->_orientation, $this->_question_id, $this->_survey_id, $this->_params, $this->_question_details, $this->_completed, $this->_session_id);
		return $result;
	}
	
	function getClass($type){
		$class = "";
		switch($type){
			case "1" : {
				$class = "OneAnswer";
				break;
			}
			case "2" : {
				$class = "OneAnswer";
				break;
			}
			case "3" : {
				$class = "OneAnswerMenu";
				break;
			}
			case "4" : {
				$class = "MultipleAnswer";
				break;
			}
			case "5" : {
				$class = "MultipleAnswer";
				break;
			}
			case "6" : {
				$class = "OnePerRow";
				break;
			}
			case "7" : {
				$class = "MultiplePerRow";
				break;
			}
			case "8" : {
				$class = "MultiplePerRowMenus";				
				break;
			}
			case "9" : {
				$class = "EndedOneLine";
				break;
			}
			case "10" : {
				$class = "EndedMoreLines";
				break;
			}
			case "11" : {
				$class = "Essay";
				break;
			}
			case "12" : {
				$class = "Constant";
				break;
			}
			case "13" : {
				$class = "DateTime";
				break;
			}
			
			case "15" : {
				$class = "Rating";
				break;
			}
		}
		return $class;
	}
	
};

?>