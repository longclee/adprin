<?php

/**
* @author  Chenglong Li
*/

defined('_JEXEC') or die('Restricted access');
	
class QuestionRating{
	
	function QuestionRating(){
		//public $section_id = 0;
	}
	
	function display($orientation = "", $question_id, $survey_id, $params, $question_details, $completed, $session_id){	
		$return_content_array = array();
		$return = "";
		$answer = "";
		$question_class = isset($params->question)? $params->question : "";
		$question_description = isset($params->question_description)? $params->question_description : "";		
		$javascript = "";
		$entered = "";
		$row_class = $params->table_row2;
		$row_class_ok = "true";
		$columns = $this->getColumns($question_id);
		$answers = $this->getAnswers($question_id);
		$validation = "";
		$star_active = "";
		$star_check = "";
		$qapp_val = "0";
		$app_val = "Not Applicable";
		$nondis  = "nondisplay ";
		$session_detail = $this->getSessionValue($session_id);
		$col_num = isset($session_detail["0"]["ad_num"])?$session_detail["0"]["ad_num"]:999;
		
		$return .= '<div class="Questionbox">';
		$return .= 	  	 '<div class="'.$question_class.'">';
		//$return .= 			'<table width="100%" cellspacing="0" cellpadding="0" border="0">';
		//$return .= 				'<tr>';
		//$return .= 					'<td class="QuestionText">';
		$return .= 					'<div class="QuestionText">';
		$sequence_num  ="";
		if($question_details["0"]["sequence_num"] !="") $sequence_num = $question_details["0"]["sequence_num"]."   ";
		$return .=           		$sequence_num.$question_details["0"]["title"];
		
		if($question_details["0"]["required"] == "1"){
			//$return .= '<span class="question_required"> *</span>';
			$javascript = ' onchange="setentertext(form.q'.$question_id.', this)" ';
			$validation = $this->createValidation($answers, $question_id, $sequence_num.$question_details["0"]["title"], $columns,$col_num);						
		}
		if($question_details["0"]["description"] != ""){
			$return .= 	 '<a  class="DescImg" onclick="switchActive(\'qdbox'.$question_id.'\')" href="javascript://" alt="Description">';
			$return .=       '<img src="'.JURI::base().'components/com_surveys/images/qs.png"  alt="Description" />';
			$return .= 	 '</a>';
		}
		
		if(isset($answers) && count($answers)>0 && isset($columns) && count($columns)>0){
			$edit_values = $this->getValue($question_id, $session_id);
			//print_r($edit_values);
			if($edit_values == NULL || count($edit_values) == 0){
				$entered = "";
				$btn_style = " BtnX";
				//$nondis  = "blkdisplay ";
				$nondis  = "nondisplay ";
				$qapp_val = "0";
				$app_check =  '';
				$star_check =  '';
			}
			else{
				$entered = $edit_values["0"];
				//print_r($entered);
				$qapp_val = $edit_values["0"]["applicable"];
				$app_check =  ' checked="checked"';

				if($qapp_val == 1)  {
					$btn_style = " BtnX";
					$app_val = "Not Applicable";
					$nondis  = "blkdisplay ";
				}
				else{
					$btn_style = " BtnW";
					$app_val = "Applicable";
					$nondis  = "nondisplay ";
				}
				if($edit_values["0"]["important"] == 1){
					$star_active = " active";
					$star_check =  ' checked="checked"';
				}
			}
		}
		
		//$return .=          		'</td>';
		//$return .= 	  	 			'<td width="150px" valign="middle"><input type="button" name="BtnApp'.$question_id.'" class="BtnApplicable '.$btn_style.'" onclick="OptDisplay('.$question_id.',this)" value="'.$app_val.'"></input></td>';
		//$return .= 	  	 		'</tr>';
		//$return .= 	  		'</table>';
		$return .= 			'</div>';
		$return .= 	  	 '</div>';
		
		$return .=		 '<div class="'.$question_description.'" id="qdbox'.$question_id.'">';
		if($question_details["0"]["description"] != ""){
			$return .=       $question_details["0"]["description"];	
		}
		$return .= 	 	 '</div>';

		$return .=  '<div class="applbox">';
		$return .= 		'<span class="surveyfont">Is this principle applicable to your ad?&nbsp;&nbsp;</span>';
		if ($qapp_val == 1){
			//$return .=      '<label class="QuestionBtn_A active" id="bqA'.$question_id.'0" name="labelA'.$question_id.'">';
			$return .= 	    '<input type="radio" class="'.$params->radiobutton.'" onclick="OptDisplay('.$question_id.',this)" value="1" id="q'.$question_id.'A1" name="qappl['.$question_id.']" '.$app_check.'>Yes</input>&nbsp;&nbsp;&nbsp;';
			//$return .=      '</label>';
			//$return .=      '<label class="QuestionBtn_A" id="bqA'.$question_id.'2" name="labelA'.$question_id.'">';
			$return .= 	    '<input type="radio" class="'.$params->radiobutton.'" onclick="OptDisplay('.$question_id.',this)" value="0" id="q'.$question_id.'A2" name="qappl['.$question_id.']">No</input>';
			//$return .=      '</label>';
		}else{
			//$return .=      '<label class="QuestionBtn_A" id="bqA'.$question_id.'0" name="labelA'.$question_id.'">';
			$return .= 	    '<input type="radio" class="'.$params->radiobutton.'" onclick="OptDisplay('.$question_id.',this)" value="1" id="q'.$question_id.'A1" name="qappl['.$question_id.']">Yes</input>&nbsp;&nbsp;&nbsp;';
			//$return .=      '</label>';
			//$return .=      '<label class="QuestionBtn_A active" id="bqA'.$question_id.'2" name="labelA'.$question_id.'">';
			$return .= 	    '<input type="radio" class="'.$params->radiobutton.'" onclick="OptDisplay('.$question_id.',this)" value="0" id="q'.$question_id.'A2" name="qappl['.$question_id.']" '.$app_check.'>No</input>';
			//$return .=      '</label>';			
		}

		$return .=  '</div>';
		
		$return .= 	  	 '<div class="'.$nondis.'OptionBox" id="qbox'.$question_id.'">';
		$return .= 	         			'<input type="hidden" value="checkbox" name="question['.$question_id.'][type]">';
    	$return .= 	         			'<input type="hidden" value="matrix" name="question['.$question_id.'][orientation]">';
		//$return .= 	     			'</td>';
		//create table header
/* 		if(isset($columns) && count($columns)>0){
			foreach($columns as $key=>$value){
				$return .= 	 		'<td align="center" class="'.$params->column_heading.'">'.$value["value"].'</td>';
			}
		}		
		$return .= 	  			'</tr>'; */
		//create table content

		$col_count = 1;
		if(isset($answers) && count($answers)>0 && isset($columns) && count($columns)>0){
			$all_result = array();
			if(isset($edit_values)){
				foreach($edit_values as $key=>$val_edit){
					$all_result[$val_edit["q_id"]."_".$val_edit["a_id"]] = $val_edit["ac_id"];
				}
			}
			$return .= 		'<div class="ColumnBox">';
			$return .= 	    	'<table width="100%" cellspacing="0" cellpadding="0" border="0">';	
			$return .= 	    		'<tr>';	
			//$return .= 	    			'<td valign="top"><input type="checkbox" class="starBtn'.$star_active.'" name="isimp['.$question_id.']"'.$star_check.' value="1"></input><span class="surveyfont">&nbsp&nbsp&nbsp'."Important?".'</span><span class="greyfont">&nbsp;&nbsp;Click if the principle seems especially important in this situation</span></td><td>&nbsp</td>';
			$return .= 					'<td style="padding:5px;">';
			$return .= 						'<span class="surveyfont">If it is applicable, do you think this principle is especially important?&nbsp;&nbsp;</span>';
			if ($edit_values["0"]["important"]  == 1){
				$return .= 	    			'<input type="radio" class="'.$params->radiobutton.'" value="1" id="q'.$question_id.'A1" name="isimp['.$question_id.']" '.$star_check.'>Yes</input>&nbsp;&nbsp;&nbsp;';
				$return .= 	    			'<input type="radio" class="'.$params->radiobutton.'" value="0" id="q'.$question_id.'A2" name="isimp['.$question_id.']">No</input>';
			}else{
				$return .= 	    			'<input type="radio" class="'.$params->radiobutton.'" value="1" id="q'.$question_id.'A1" name="isimp['.$question_id.']">Yes</input>&nbsp;&nbsp;&nbsp;';
				$return .= 	   				'<input type="radio" class="'.$params->radiobutton.'" value="0" id="q'.$question_id.'A2" name="isimp['.$question_id.']" '.$star_check.'>No</input>';			
			}
			$return .=					'</td>';
			$return .=					'<td>&nbsp;</td>';
			$return .= 	    		'</tr>';	
			$return .= 	    		'<tr>';	
			$return .=					'<td style="padding:5px;"><span class="surveyfont">How would you rate your ad against this principle?</span></td>';
			$return .=					'<td>&nbsp;</td>';
			$return .= 	    		'</tr>';
			//print_r($all_result);
			foreach($answers as $key=>$value){				
				$count = 1;
				if($col_count <= $col_num){
				 	$return .=    	'<tr>';
				 	$return .=    		'<td class="ColumnText">'.$value["value"].'</td>';
				 	$return .=    		'<td class="ColumnOption"><div class="btn-group" data-toggle="buttons">';
								
/* 				if($row_class_ok == "true"){
					$row_class = $params->table_row2;
					$row_class_ok = "false";
					$class_active = "active";
				}
				else{
					$row_class = $params->table_row1;
					$row_class_ok = "true";
				} */
				//$return .= 	    '<tr class="'.$row_class.'">';
					//$return .= 	    '<td align="left"><span class="'.$params->row_heading.'">'.trim($value["value"]).'</span></td>';
				
					foreach($columns as $key_col=>$val_col){
						$checked = "";
						$class_active = "";
						if(isset($all_result[$question_id."_".$value["id"]]) && $all_result[$question_id."_".$value["id"]]==$val_col["id"]){
							if(isset($completed["view_response"]) && $completed["view_response"]=="true"){
								$checked = ' checked="checked" ';
								$class_active = " active";
							}
						}
						$return .=      '<label class="QuestionBtn'.$class_active.'" id="bq'.$question_id.'a'.$value["id"].$count.'" name="labelQ'.$question_id.'">';
						$return .= 	    '<input '.$checked.' type="radio" class="'.$params->radiobutton.'" onclick="switchlabel(this,'.$val_col["id"].',\'bq'.$question_id.'a'.$value["id"].'\');setentered(form.q'.$question_id.',this,&quot;question[q'.$val_col["id"].'a'.$value["id"].$count.'][answer]['.$value["id"].'][]&quot;)" value="'.$val_col["id"].'" id="q'.$question_id.'a'.$value["id"].$count.'" name="question['.$question_id.'][answer]['.$value["id"].'][]">'.$val_col["value"].'</input>';
						$return .=      '</label>';
						//$return .= 	'</td>';
						$count = $count + 1;
					}
					$col_count++;
				}
				$return .=				'</div></td>';	
				$return .=			'</tr>';	    
			}
		}
		$return .=				'</table>';
		$return .=			'</div>';	
		$return .=		'</div>';
		$return .=	'</div>';
				
		$return .= '<input type="hidden" id="q'.$question_id.'" name="q'.$question_id.'" value="'.$entered.'">';
		$return .= '<input type="hidden" id="qtext'.$question_id.'" name="qtext'.$question_id.'" value="'.$value.'">';
		//$return .= '<input type="hidden" id="qapp'.$question_id.'" name="qappl['.$question_id.']" value="'.$qapp_val.'">';
		$return .= '<input type="hidden" name="classes['.$question_id.']" value="QuestionRating">';		
		
		$return_content_array["content"] = $return;
		$return_content_array["validation"] = $validation;
		
		return $return_content_array;
	}
	
	function getColumns($question_id){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('id, value');
		$query->from('#__adprin_surveys_answer_columns');
		$query->where("question_id=".intval($question_id));
		$query->order("id asc");		
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadAssocList();	
		return $result;
	}
	
	function getAnswers($question_id){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('id, value');
		$query->from('#__adprin_surveys_answers');
		$query->where("question_id=".intval($question_id));	
		$query->order("id asc");	
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadAssocList();	
		return $result;
	}	
	
	function getColumnVal($c_id){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('id, value');
		$query->from('#__adprin_surveys_answer_columns');
		$query->where("id=".intval($c_id));		
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadAssocList();	
		return $result;
	}
	
	function getAnswerVal($a_id){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('id, value');
		$query->from('#__adprin_surveys_answers');
		$query->where("id=".intval($a_id));		
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadAssocList();	
		return $result;
	}	
	
	function getSections($q_id){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('s.id, s.title, s.summary, s.section_num');
		$query->from('#__adprin_surveys_questions q,#__adprin_surveys_pages s');
		$query->where("q.id=".intval($q_id)." and q.page_id=s.id");		
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadAssocList();	
		//JFactory::getApplication()->enqueueMessage($db->stderr(true), 'error');
		return $result;
	}
	
	function getValue($question_id, $session_id){
        if (!$session_id) { return NULL; }    
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('*');
		$query->from('#__adprin_surveys_result');
		$query->where("q_id=".intval($question_id)." and session_id=".intval($session_id));		
		$db->setQuery($query);		
		$db->query();		
		$result = $db->loadAssocList();
		return $result;
	}
	
	function getSessionValue($session_id){
        if (!$session_id) { return NULL; }    
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('*');
		$query->from('#__adprin_surveys_session');
		$query->where("id=".intval($session_id));		
		$db->setQuery($query);			
		$db->query();		
		$result = $db->loadAssocList();
		return $result;
	}
	
	function createValidation($answers, $question_id, $title, $columns,$col_num){
		$result = "";
		$if_array = array();	
		$result .= '	aq1'.$question_id.' = document.getElementById("q'.$question_id.'A1").checked;'."\n";
		$result .= '	aq2'.$question_id.' = document.getElementById("q'.$question_id.'A2").checked;'."\n";	
		//$result .= '    alert(aq'.$question_id.');'."\n";	
		$col_count = 1;
		
		foreach($answers as $key=>$value){
			$count = 1;
			if($col_count <= $col_num){
				foreach($columns as $key2=>$value2){
					$result .= '	i'.$count.' = document.getElementById("q'.$question_id.'a'.$value["id"].$count.'").checked ;'."\n";
					$if_array[] = '!i'.$count;
					$count++;
				}
				$result .= '	if((!aq1'.$question_id.' && !aq2'.$question_id.') || (aq1'.$question_id.' && '.implode(" && ", $if_array).')){'."\n".
						   '		alert(AlertText +"'.addslashes(trim($title))." | ".addslashes(trim($value["value"])).'");'."\n".
						   '		return false;'."\n".
						   '	}'."\n";
				$if_array = array();
				$col_count++;
			}			
		}		
		return $result;
	}
	
	function save($id, $type, $session_id){
		$db =& JFactory::getDBO();		
		$all_answers = JRequest::getVar("question");
		$answers = $all_answers[$id]["answer"];
		$qappl = JRequest::getVar("qappl");
		$isimp_arr = JRequest::getVar("isimp");
		$isimp = 0;
		$isappl = 0;
		if(isset($isimp_arr[$id]) && $isimp_arr[$id] == '1') $isimp = 1;
		if(isset($qappl[$id]) && $qappl[$id] == '1') $isappl = 1;
		$section_val = $this->getSections($id);

		//$qaps  = implode("|",$qappl);
		
		if($this->answerExist($id, $session_id)){
			$sql = "delete from  #__adprin_surveys_result where q_id=".$id." and session_id=".$session_id;												
			$db->setQuery($sql);
			$db->query();
		}
		
		if(($answers == NULL || count($answers) == 0) && $isappl == 0){
			$sql = "insert into #__adprin_surveys_result(`q_id`, `a_id`, `m_id`, `ac_id`, `session_id`, `section_id`, `section_name`, `summary`, `value`, `column_value`, `applicable`, `important`) values (";
			$sql .= $id.", 0, 0, 0, ".$session_id.", 0, '', '', '', '',".$isappl.",0";
			$sql .= ")";
			$db->setQuery($sql);
			$db->query();
		}
		
		foreach($answers as $key=>$value){
			$sql = "insert into #__adprin_surveys_result(`q_id`, `a_id`, `m_id`, `ac_id`, `session_id`, `section_id`, `section_name`, `summary`, `value`, `column_value`, `applicable`, `important`) values (";		
			$answer_val = $this->getAnswerVal($key);
			$column_val = $this->getColumnVal($value["0"]);
			
			$sql .= $id.", ".$key.", 0, ".$value["0"].", ".$session_id.", ".$section_val["0"]["id"].", '".$section_val["0"]["title"]."', '".$section_val["0"]["summary"]."', '".$column_val["0"]["value"]."', '".$answer_val["0"]["value"]."',".$isappl.",".$isimp;
			$sql .= ")";
			$db->setQuery($sql);
			$db->query();
			//JFactory::getApplication()->enqueueMessage($sql, 'error');	
		}	
	}
			
	function answerExist($question_id, $session_id){
		$db =& JFactory::getDBO();
		$sql = "select count(*) from #__adprin_surveys_result where q_id=".$question_id." and session_id=".$session_id;
		$db->setQuery($sql);
		$db->query();
		$result = $db->loadResult();
		if($result != "0"){
			return true;
		}
		return false;
	}
	
	function editResult($id, $survey_id, $params, $i, $title, $all_responses_count){
		$answers = $this->getAnswers($id);
		$columns = $this->getColumns($id);		
		
		$return  = '<table width="100%" style="border:1px solid #CCCCCC; border-collapse:collapse;">';
		$return .= 		'<tr>';
		$return .= 			'<td class="'.$params->question.'" colspan="'.(count($columns)+2).'" style="padding-left:5px;">';
		$return .= 				'<b>'.$i.". ".$title.'</b>';
		$return .= 			'</td>';
		$return .= 		'</tr>';
		$return .= 		'<tr>';
		$return .= 			'<td>';
		$return .= 			'</td>';
		
		foreach($columns as $c_key=>$c_value){
			$return .= '<td align="center">';
			$return .= 		$c_value["value"];
			$return .= '</td>';
		}
		$return .= 			'<td align="center">';
		$return .= 				JText::_("COM_SURVEYS_TOTAL_RESPONSE");
		$return .= 			'</td>';	
		$return .= 		'</tr>';
		$k = 0;
		foreach($answers as $a_key=>$a_value){
			$class = $params->table_row1;
			if($k%2 != 0){
				$class = $params->table_row2;
			}
			$k++;
			$return .= '<tr class="'.$class.'">';
			$return .= 		'<td align="right">';
			$return .= 			$a_value["value"];
			$return .= 		'</td>';
			$for_total = 0;	
			foreach($columns as $c_key=>$c_value){
				$return .= '<td align="center">';
				$count 	 = $this->countTotal($a_value["id"], $c_value["id"]);
				if(intval($all_responses_count) != "0"){
					$return .= 		@number_format( (($count * 100) / $all_responses_count), 2, '.', '') . " % (".$count.")";
				}
				$return .= '</td>';
				$for_total += $count;
			}
			$return .= 		'<td align="center">';
			$return .= 			$for_total;		
			$return .= 		'</td>';				
			$return .= '</tr>';	
		}
		$return .= 		'<tr>';
		$return .= 			'<td colspan="'.(count($columns)+1).'" style="padding-left:5px;">';
		$return .= 				'<b>'.JTExt::_("COM_SURVEYS_TOTAL_RESPONDENTS").':</b>';
		$return .= 			'</td>';
		$return .= 			'<td class="'.$params->total_background.'" align="center">';
		$return .= 				'<b>'.$this->countPerQuestion($id).'</b>';
		$return .= 			'</td>';
		$return .= 		'</tr>';
		$return .= '</table>';

		return $return;		
	}
	
	function countTotal($a_id, $ac_id){
		$r_id = JRequest::getVar("r_id", "");
		$and = "";
		if($r_id != ""){
			$and = " and session_id=".$r_id;
		}
		$db =& JFactory::getDBO();		
		$sql = "select count(*) from #__adprin_surveys_result where a_id=".$a_id." and ac_id=".$ac_id.$and;		
		$db->setQuery($sql);
		$db->query();
		$result = $db->loadResult();
		return $result;
	}
	
	function countPerQuestion($id){
		$r_id = JRequest::getVar("r_id", "");
		$and = "";
		if($r_id != ""){
			$and = " and session_id=".$r_id;
		}
		$db =& JFactory::getDBO();		
		$sql = "select count(*) from #__adprin_surveys_result where q_id=".$id.$and." group by session_id";
		$db->setQuery($sql);
		$db->query();
		$result = $db->loadResult();
		return $result;
	}
	
	function getValueFromDatabase($question_id, $session_id, $a_id){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('ac.value');
		$query->from('#__adprin_surveys_result sr, #__adprin_surveys_answer_columns ac');
		$query->where("sr.q_id=".intval($question_id)." and sr.session_id=".intval($session_id)." and sr.ac_id=ac.id and sr.a_id=".$a_id);		
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadAssocList();		
		return $result;
	}
	
	function getForHeader($id, $title){
		$return_array = array();
		$answers = $this->getAnswers($id);
		foreach($answers as $key=>$value){
			$return_array[] = $title." : ".trim($value["value"]);
		}
		$return = implode(",", $return_array);
		return $return;
	}
	
	function getForRow($q_id, $sess_id){
		$answers = $this->getAnswers($q_id);		
		$result_array = array();		
		foreach($answers as $key=>$value){
			$response = $this->getValueFromDatabase($q_id, $sess_id, $value["id"]);			
			if($response == NULL || count($response) == 0){
				$result_array[] = "NO ANSWER";
			}
			else{
				if(trim($response["0"]["value"]) != ""){
					$result_array[] = trim($response["0"]["value"]);
				}
				else{
					$result_array[] = "NO ANSWER";
				}	
			}
		}
		return implode(",", $result_array);
	}
	
	function getQuestionResultForEmail($q_id, $session_id, $title){		
		$answers = $this->getAnswers($q_id);
		$return = $title.":"."\n";
		
		foreach($answers as $a_key=>$a_value){			
			$result = $this->getValueFromDatabase($q_id, $session_id, $a_value["id"]);
			if(isset($result["0"]["value"]) && trim($result["0"]["value"]) != ""){
				$return .= "\t".trim($a_value["value"]).": ".trim($result["0"]["value"]);
			}
			else{
				$return .= "\t".trim($a_value["value"]).": ";
			}
			$return .= "\n";
		}		
		return $return;		
	}
	
	function checkCompleted($logic, $compare, $answer, $skip_answer){
		$return = false;
		
		if($logic == "OR"){
			if($compare == "equal"){
				foreach($skip_answer as $key=>$value){
					if(in_array($value, $answer)){
						$return = true;
						return $return;
					}
				}
			}
			elseif($compare == "different"){
				foreach($skip_answer as $key=>$value){
					if(in_array($value, $answer)){
						$return = false;
						return $return;
					}
				}
				$return = true;
				return $return;
			}
		}
		elseif($logic == "AND"){
			if($compare == "equal"){
				foreach($skip_answer as $key=>$value){
					if(!in_array($value, $answer)){
						$return = false;
						return $return;
					}
				}
				$return = true;
				return $return;
			}
			elseif($compare == "different"){
				foreach($answer as $key=>$value){
					if(in_array($value, $skip_answer)){
						$return = false;
						return $return;						
					}
				}
				$return = true;
				return $return;
			}
		}			
	}
				
};

?>
