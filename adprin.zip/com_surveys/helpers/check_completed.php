<?php

/**
* @author  Chenglong Li
*/

defined('_JEXEC') or die('Restricted access');

class CheckCompleted{
	
	function CheckCompleted(){		
	}
	
	function check_completed($survey_id, $user_id, $general_value){
		$return = array();	
		switch($general_value){
			case "ORpR" : {
				if(!$this->ipExist($_SERVER['REMOTE_ADDR'], $survey_id, $user_id)){
					$page_to_view = $this->check_left_off($survey_id, $user_id);
					$return['page_to_view'] = $page_to_view;
					if($page_to_view != -1 && $page_to_view != 0){
						if(isset($_SESSION["session_id"]) && trim($_SESSION["session_id"]) != ""){
							$return['session_id'] = $_SESSION["session_id"];
						}
						else{
							$sess_id_completed = intval($this->check_incompleted($survey_id, $user_id));
							$return['session_id'] = $sess_id_completed;
						}
						$return['view_response'] = "true";						
					}
					else{
						$return['view_response'] = "true";
					}
				}				
				else{					
					$return["already_completed"] = JText::_("COM_SURVEYS_ALREADY_COMPLETED");
				}
				break;
			}//case
			
			case "ORpRFO" : {
				$page_to_view = $this->check_left_off($survey_id, $user_id);
				$return['page_to_view'] = $page_to_view;
				if($page_to_view != -1 && $page_to_view != 0){
					if(isset($_SESSION["session_id"]) && trim($_SESSION["session_id"]) != ""){
						$return['session_id'] = $_SESSION["session_id"];
					}
					else{
						$sess_id_completed = intval($this->check_incompleted($survey_id, $user_id));
						$return['session_id'] = $sess_id_completed;
					}
					$return['view_response'] = "true";						
				}
				else{
					$sess_id_completed = intval($this->check_completed_session($survey_id, $user_id));
					$return['session_id'] = $sess_id_completed;
					$return['view_response'] = "true";
				}
				break;
			}
			
			case "MRpR" : {
				$page_to_view = $this->check_left_off($survey_id, $user_id);
				$return['page_to_view'] = $page_to_view;
				if($page_to_view != -1){
					if(isset($_SESSION["session_id"]) && trim($_SESSION["session_id"]) != ""){
						$return['session_id'] = $_SESSION["session_id"];
					}
					else{
						$sess_id_completed = intval($this->check_incompleted($survey_id, $user_id));
						$return['session_id'] = $sess_id_completed;
					}
					$return['view_response'] = "true";
				}				
				break;
			}
			
			case "MRpRSC" : {
				$page = JRequest::getVar("page", "");
				$page_to_view = $this->check_left_off($survey_id, $user_id);
				if($page == ""){
					 $sess_id_completed = intval($this->check_incompleted($survey_id, $user_id));
					 $this->terminateSurvey($sess_id_completed);
					 //$_SESSION["skip_pages"] = "";
					 $return['page_to_view'] = "-1";
				}
				else{
					$return['page_to_view'] = $page_to_view;
				}				
				if($page_to_view != -1){
					$sess_id_completed = intval($this->check_incompleted($survey_id, $user_id));					
					$return['session_id'] = $sess_id_completed;
					$return['view_response'] = "true";
				}				
				break;
			}
		}//switch
		if(isset($_SESSION["view_result"]) && $_SESSION["view_result"]=="true"){
			$return['view_response'] = "true";
		}		
		return $return;	
	}
	
	function ipExist($ip, $survey_id, $user_id){
		$and = "";
		if($user_id != "0"){
			$and = " and user_id=".$user_id;
		}		
		$db =& JFactory::getDBO();
		$sql = "select count(*) from #__adprin_surveys_session where ip='".$ip."' and completed=1 and survey_id=".$survey_id.$and;					
		$db->setQuery($sql);
		$db->query();
		$result = $db->loadResult();		
		if($result != 0){
			return TRUE;
		}
		return FALSE;
	}
	
	function check_left_off($s_id,$user_id){
		$db =& JFactory::getDBO();
		$sql = "SELECT last_page_id FROM #__adprin_surveys_session WHERE survey_id=".$s_id." AND user_id=".$user_id." AND completed<>1 AND ip='".$_SERVER['REMOTE_ADDR']."' ORDER BY id DESC LIMIT 1";
		$db->setQuery($sql);
		if (!$db->query()){
			die("Error !Code 25: The process could not be finished due to internal error. Please contact the administrators");
		}
		if($db->getNumRows()>0){	
			$last_page_id=$db->loadResult();
			return $last_page_id; 
		}
		else{
		  return -1;
		}
	}
	
	function check_incompleted($survey_id, $user_id){
		$db = &JFactory::getDBO();
		$sql = "SELECT id FROM #__adprin_surveys_session WHERE survey_id = ".$survey_id." AND user_id = ".$user_id." AND completed = 0 AND ip='".$_SERVER['REMOTE_ADDR']."' ORDER BY id DESC LIMIT 1";
		$db->setQuery($sql);
		if (!$db->query()){
		  die("Error !Code 26: The process could not be finished due to internal error. Please contact the administrators");
		}
		$completed_session_id = $db->loadResult();
		if ($completed_session_id > 0){
			return $completed_session_id;
		}
		else{
			return 0;
		}
	}
	
	function check_completed_session($s_id, $user_id){
		$db = &JFactory::getDBO();
		$sql = "SELECT id FROM #__adprin_surveys_session WHERE survey_id = ".$s_id." AND user_id = ".$user_id." AND completed = 1 AND ip='".$_SERVER['REMOTE_ADDR']."' ORDER BY id DESC LIMIT 1";
		$db->setQuery($sql);
		if (!$db->query()){
		  die("Error !Code 26: The process could not be finished due to internal error. Please contact the administrators");
		}
		$completed_session_id = $db->loadResult();
		if($completed_session_id > 0){
			return $completed_session_id;
		}
		else{
			return 0;
		}
	}
	
	function terminateSurvey($sess_id_completed){
		$db = &JFactory::getDBO();
		$sql = "update #__adprin_surveys_session set completed=1, last_page_id=0 where id=".$sess_id_completed;
		$db->setQuery($sql);
		$db->query();
	}
		
};

?>