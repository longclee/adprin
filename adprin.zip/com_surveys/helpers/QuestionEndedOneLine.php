<?php

/**
* @author  Chenglong Li
*/

defined('_JEXEC') or die('Restricted access');
	
class QuestionEndedOneLine{
	
	function QuestionEndedOneLine(){
	}
	
	function display($orientation = "", $question_id, $survey_id, $params, $question_details, $completed, $session_id){						
		$return_content_array = array();
		$return = "";
		$answer = "";
		$question_class = isset($params->question)? $params->question : "";
		$question_description = isset($params->question_description)? $params->question_description : "";		
		$javascript = "";
		$value = "";
		$entered = "";
		$validation = "";
		$edit_value = $this->getValue($question_id, $session_id);
		
		$return .= '<table class="table_question">';
		$return .= 	  '<tr>';
		$return .= 	  	 '<td class="'.$question_class.'">';
		$return .=           $question_details["0"]["title"];
		if($question_details["0"]["required"] == "1"){
			$return .= '<span class="question_required"> *</span>';
			$javascript = ' onchange="setentertext(form.q'.$question_id.', this)" ';
			$validation = $this->createValidation($question_id, $question_details["0"]["title"]);					
		}
		$return .= 	  	 '</td>';
		$return .= 	  '</tr>';
		if($question_details["0"]["description"] != ""){
			$return .='<tr>';
			$return .= 	 '<td class="'.$question_description.'">';
			$return .=       $question_details["0"]["description"];
			$return .= 	 '</td>';
			$return .='</tr>';
		}
		$return .= 	  '<tr>';
		$return .= 	  	 '<td class="'.$question_class.'">';
		$return .= 	  	    '<input type="hidden" value="text" name="question['.$question_id.'][type]">';
		$return .= 	  	    '<input type="hidden" value="dropdown" name="question['.$question_id.'][orientation]">';
		$return .= 	  	    '<input type="text" onchange="setentertext(form.q'.$question_id.', this.value)" maxlength="250" value="'.$edit_value.'" size="35" id="question['.$question_id.'][answer_text]" name="question['.$question_id.'][answer_text]">';
		$return .= 	  	 '</td>';
		$return .= 	  '</tr>';
		$return .= '</table>';
		
		$return .= '<input type="hidden" id="q'.$question_id.'" name="q'.$question_id.'" value="'.$entered.'">';
		$return .= '<input type="hidden" id="qtext'.$question_id.'" name="qtext'.$question_id.'" value="'.$value.'">';
		$return .= '<input type="hidden" name="classes['.$question_id.']" value="QuestionEndedOneLine">';		
		
		$return_content_array["content"] = $return;
		$return_content_array["validation"] = $validation;
		
		return $return_content_array;
	}
	
	function getValue($question_id, $session_id){
        if (!$session_id) { return NULL; }
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('value');
		$query->from('#__adprin_surveys_result_text');
		$query->where("question_id=".intval($question_id)." and session_id=".intval($session_id));		
		$db->setQuery($query);		
		$db->query();
        //echo "SELECT value FROM #__adprin_surveys_result_text WHERE question_id=";
        //echo intval($question_id)." and session_id=".intval($session_id);
        //die();
		$result = $db->loadResult();	
		return $result;
	}
	
	function createValidation($question_id, $title){
		$result = "";
		$if_array = array();	
		
		$result .= '	var field_answer_text = document.getElementById("question['.$question_id.'][answer_text]");'."\n";
		$result .= '	setentertext(document.survey_content.q'.$question_id.', field_answer_text.value);'."\n";
		$result .= '	var field = document.getElementById("q'.$question_id.'");'."\n";
		$result .= '	var field_qtext = document.getElementById("qtext'.$question_id.'");'."\n";
		$result .= '	if (field.value==0 && field_qtext.value==0){'."\n".
					'		alert(AlertText +"'.addslashes(trim($title)).'");'."\n".
					'		return false;'."\n".
					'	}';				
		return $result;
	}
	
	function save($id, $type, $session_id){
		$db =& JFactory::getDBO();
		
		$all_answers = JRequest::getVar("question");
		$answer = $all_answers[$id]["answer_text"];
		if(trim($answer) != ""){										
			if($this->answerExist($id, $session_id)){
				$sql = "update #__adprin_surveys_result_text set `value`='".addslashes($answer)."' where `question_id`=".$id." and `session_id`=".$session_id;												
				$db->setQuery($sql);
				$db->query();
			}
			else{						
				$sql = "insert into #__adprin_surveys_result_text(`question_id`, `value`, `session_id`) values (";					
				$sql .= $id.", '".addslashes($answer)."', ".$session_id;
				$sql .= ")";
				$db->setQuery($sql);
				$db->query();
			}
		}
		else{
			$sql = "delete from #__adprin_surveys_result_text where `question_id`=".$id." and `session_id`=".$session_id;												
			$db->setQuery($sql);
			$db->query();
		}
	}	
	
	function answerExist($question_id, $session_id){
		$db =& JFactory::getDBO();
		$sql = "select count(*) from #__adprin_surveys_result_text where question_id=".$question_id." and session_id=".$session_id;
		$db->setQuery($sql);
		$db->query();
		$result = $db->loadResult();
		if($result != "0"){
			return true;
		}
		return false;
	}
	
	function editResult($id, $survey_id, $params, $i, $title, $all_responses_count){		
		$controller = JRequest::getVar("controller", "", "get");
		
		$return  = '<table width="100%" style="border:1px solid #CCCCCC; border-collapse:collapse;">';
		$return .= 		'<tr>';
		$return .= 			'<td class="'.$params->question.'" colspan="2" style="padding-left:5px;">';
		$return .= 				'<b>'.$i.". ".$title.'</b>';
		$return .= 			'</td>';
		$return .= 		'</tr>';
		$return .= 		'<tr>';
		$return .= 			'<td style="padding-left:5px;">';
		$return .= 				'<b>'.JTExt::_("COM_SURVEYS_TOTAL_RESPONDENTS").':</b>';
		$return .= 			'</td>';
		$return .= 			'<td class="'.$params->total_background.'" align="center">';
		$app =& JFactory::getApplication();
		$count = $this->countPerQuestion($id);
		if($count > 0){
			if($app->isAdmin()){
				if($controller != "" && $controller == "statistics"){
					$r_id = JRequest::getVar("r_id", "0");
					$link = JURI::root().'administrator/index.php?option=com_surveys&controller=editdetails&task=edit_details&q_id='.$id."&r_id=".$r_id;
					$return .= '<a style="text-decoration:none;" href="'.$link.'">'.$count." ".JText::_("COM_SURVEYS_VIEW_DETAIL").'</a>';
				}			
			}
			else{
				$link = JRoute::_('index.php?option=com_surveys&controller=editsurvey&Itemid='.JRequest::getVar("Itemid").'&task=edit_details&q_id='.$id);
				$return .= '<a style="text-decoration:none;" href="'.$link.'">'.$count." ".JText::_("COM_SURVEYS_VIEW_DETAIL").'</a>';
			}
		}
		else{
			$return .= "0";
		}	
		$return .= 			'</td>';
		$return .= 		'</tr>';
		$return .= '</table>';
		return $return;		
	}
	
	function countPerQuestion($id){
		$r_id = JRequest::getVar("r_id", "");
		$and = "";
		if($r_id != ""){
			$and = " and session_id=".$r_id;
		}
		$db =& JFactory::getDBO();		
		$sql = "select count(*) from #__adprin_surveys_result_text where question_id=".$id.$and;		
		$db->setQuery($sql);
		$db->query();
		$result = $db->loadResult();
		return $result;
	}
	
	function getForHeader($id, $title){		
		return $title;
	}
	
	function getForRow($q_id, $sess_id){
		$db =& JFactory::getDBO();		
		$sql = "select value from #__adprin_surveys_result_text where question_id=".$q_id." and session_id=".$sess_id;		
		$db->setQuery($sql);
		$db->query();
		$result = $db->loadResult();
		if(trim($result) != ""){
			return trim($result);
		}	
		else{
			return "NO ANSWER";
		}
	}
		
	function getQuestionResultForEmail($q_id, $session_id, $title){
		$return = $title.":"."\n";
		$db =& JFactory::getDBO();		
		$sql = "select value from #__adprin_surveys_result_text where question_id=".$q_id." and session_id=".$session_id;		
		$db->setQuery($sql);
		$db->query();
		$result = $db->loadResult();
		
		if(trim($result) != ""){
			$return .= "\t".trim($result);
		}
		return $return;
	}		
};

?>