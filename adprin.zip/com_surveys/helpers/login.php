<?php

/**
* @author  Chenglong Li
*/


defined('_JEXEC') or die('Restricted access');

class Login{
	function getLogin($link){
		$validate = JUtility::getToken(1);
		$begin_uri = strpos($_SERVER['REQUEST_URI'],"index.php");
		$link = substr($_SERVER['REQUEST_URI'],$begin_uri);
		
		$return  = "";
		$return .= '<form name="login" method="post" align="center" id="form-login">';
		$return .=     '<span class="login_description">'.JText::_("COM_SURVEYS_LOGIN_DESCRIPTION").'</span>';
		$return .=     '<table>';
		$return .=        '<tr>';
		$return .=        	'<td>';
		$return .=        	  JText::_("COM_SURVEYS_USERNAME");
		$return .=        	'</td>';
		$return .=        	'<td>';
		$return .=        	  '<input type="text" name="username" id="modlgn_username" value="" size="18" />';
		$return .=        	'</td>';
		$return .=        '</tr>';
		$return .=        '<tr>';
		$return .=        	'<td>';
		$return .=        	  JText::_("COM_SURVEYS_PASSWORD");
		$return .=        	'</td>';
		$return .=        	'<td>';
		$return .=        	  '<input type="password" name="password" id="modlgn_passwd" value="" size="18" />';
		$return .=        	'</td>';
		$return .=        '</tr>';
		$return .=        '<tr>';
		$return .=        	'<td align="right">';
		$return .=        	  '<input type="checkbox" name="remember" id="modlgn_remember"  value="yes" alt="Remember Me" />';
		$return .=        	'</td>';
		$return .=        	'<td>';
		$return .=        	  JText::_("COM_SURVEYS_REMEMBER");
		$return .=        	'</td>';
		$return .=        '</tr>';
		$return .=        '<tr>';
		$return .=        	'<td colspan="2" align="center">';
		$return .=        	  '<input type="submit" name="submit" class="button" value="Login" />';
		$return .=        	'</td>';
		$return .=        '</tr>';
		$return .=        '<tr>';
		$return .=        	'<td colspan="2">';
		$return .=        		'<a href="'.JRoute::_("index.php?option=com_registration&amp;task=lostPassword").'">'.JText::_("COM_SURVEYS_LOST_PASSWORD").'</a>&nbsp;&nbsp;'.JText::_("COM_SURVEYS_NO_ACCOUNT").'&nbsp;&nbsp;';		
		$return .=        		'<a href="'.JRoute::_("index.php?option=com_registration&amp;task=register").'">'.JText::_("COM_SURVEYS_REGISTER");
		$return .=        	'</td>';
		$return .=        '</tr>';
		$return .=     '</table>';				
		$return .= 	   '<input type="hidden" name="option" value="com_users" />';
		$return .= 	   '<input type="hidden" name="task" value="user.login" />';
		$return .=     '<input type="hidden" name="controller" value="editsurvey" />';					  
        $return .=     '<input type="hidden" name="return" value="'.base64_encode(substr(JURI::base(),0,-1)."/".$link).'" />';
        $return .=     '<input type="hidden" name="'.$validate.'" value="1" />';		
		$return .= '<form>';
		
		return $return;
	}
};
?>