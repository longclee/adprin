<?php

/**
* @author  Chenglong Li
*/

defined( '_JEXEC' ) or die( 'Restricted access' );

class adprin_SurveysControllerListsurveyresult extends adprin_SurveysController{
	
	function __construct() {	  
		parent::__construct();
			
		$this->registerTask('', 'listsurveyresult');
		$this->registerTask('viewresult', 'viewresult');
	}			
	
	function listsurveyresult(){		
		JRequest::setVar('view', 'Listsurveyresult');	
		parent::display();
	}
	
	function viewresult(){
		$model = $this->getModel('listsurveyresult');
		$model->editResult();
	}	
}

?>