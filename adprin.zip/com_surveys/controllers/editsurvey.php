<?php

/**
* @author  Chenglong Li
*/

defined( '_JEXEC' ) or die( 'Restricted access' );

class adprin_SurveysControllerEditsurvey extends adprin_SurveysController{
	
	function __construct() {	  
		parent::__construct();
			
		$this->registerTask('', 'editsurvey');
		$this->registerTask('save_survey', 'saveSurvey');		
		$this->registerTask('back', 'back');
		$this->registerTask('viewresult', 'viewResult');
		$this->registerTask('edit_details', 'editDetails');
	}			
	
	function editsurvey(){		
		JRequest::setVar('view', 'Editsurvey');	
		parent::display();
	}
	
	function editDetails(){
		$model = $this->getModel('editsurvey');
		$model->editDetails();
	}
	
	function viewResult(){
		$survey_id = JRequest::getVar("id", "0");
		$model = $this->getModel('editsurvey');
		$show_result = $model->showResult($survey_id);
		if($show_result == "0"){// NO
			$this->setRedirect(JURI::root());
		}
		else{// YES
			$model->editResult();
		}	
	}
	
	function saveSurvey(){
		$model = $this->getModel('editsurvey');						
				
		$survey_id = JRequest::getVar("id", "", "post");
		$mode = JRequest::getVar("mode", "", "get");
		$mode_url = "";
		if($mode != "") $mode_url = '&mode='.$mode;
		$current_page_id = JRequest::getVar("current_page_id", "", "post");
		$page_details = $model->getPageDetails($current_page_id);
		$page_order = $page_details["0"]["ordering"];
		$model->save();
		
		$pages = $model->getPrevNextPage($survey_id, $current_page_id, $page_order);
		$survey_id_alias = JRequest::getVar("survey_id_alias", "", "post");		
		$prev_page = $pages["prev"];
		$next_page = $pages["next"];
		JRequest::setVar("next_page_id", $next_page);
		JRequest::setVar("previews_page_id", $prev_page);		
		$action = JRoute::_('index.php?option=com_surveys&controller=editsurvey&Itemid='.JRequest::getVar("Itemid").'&id='.$survey_id_alias.'&page='.$next_page.$mode_url);
		
		$_SESSION["prev_page"] = $current_page_id;		
		$_SESSION["terminate"] = JRequest::getVar("previews_page_id", "");
		unset($_SESSION["view_result"]);
		$this->setRedirect($action);
	}
	
	function back(){
		$model = $this->getModel('editsurvey');						
				
		$survey_id = JRequest::getVar("id", "", "post");
		$current_page_id = JRequest::getVar("current_page_id", "", "post");	
		$page_details = $model->getPageDetails($current_page_id);
		$page_order = $page_details["0"]["ordering"];
		$pages = $model->getPrevNextPage($survey_id, $current_page_id, $page_order);		
		$survey_id_alias = JRequest::getVar("survey_id_alias", "", "post");
		$prev_page = $pages["prev"];
		$next_page = $pages["next"];
		$mode = JRequest::getVar("mode", "", "get");
		$mode_url = "";
		if($mode != "") $mode_url = '&mode='.$mode;
		
		/*if(isset($_SESSION["prev_page_array"]) && count($_SESSION["prev_page_array"]) > 0){
			$array = $_SESSION["prev_page_array"];
			$prev_page = end($array);
			unset($array[end($array)]);
			$_SESSION["prev_page_array"] = $array;
		}
		*/
		
		$action = JRoute::_('index.php?option=com_surveys&controller=editsurvey&Itemid='.JRequest::getVar("Itemid").'&id='.$survey_id_alias.'&page='.$prev_page.$mode_url);
		$_SESSION["view_result"] = "true";
		$this->setRedirect($action);
	}
}

?>