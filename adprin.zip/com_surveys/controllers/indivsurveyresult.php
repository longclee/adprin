<?php

/**
* @author  Chenglong Li
*/

defined( '_JEXEC' ) or die( 'Restricted access' );

class adprin_SurveysControllerIndivsurveyresult extends adprin_SurveysController{
	
	function __construct() {	  
		parent::__construct();
			
		$this->registerTask('', 'viewresult');
	}	
	
	function viewresult(){
		$model = $this->getModel('editsurvey');
		$model->editResult("from menu");
	}	
}

?>