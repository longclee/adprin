<?php

/**
* @author  Chenglong Li
*/

	defined('_JEXEC') or die('Restricted access');
	
	$document =& JFactory::getDocument();
	$document->addStyleSheet("components/com_surveys/css/survey.css");	
?>