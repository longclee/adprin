<?php

/**
* @author  Chenglong Li
*/

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');

class adprin_SurveysViewIndivsurveyresult extends JView {
	
	function display($tpl = null){
		parent::display($tpl);				
	}	
}

?>