<?php

/**
* @author  Chenglong Li
*/

	defined('_JEXEC') or die('Restricted access');
	
	$document =& JFactory::getDocument();
	$document->addStyleSheet("components/com_surveys/css/survey.css");	
?>

<table width="100%">
	<tr>
		<span class="<?php echo $this->params->survey_name; ?>"><?php echo JText::_("COM_SURVEYS"); ?></span>		
		<td>
			<?php echo $this->surveysList($this->params); ?>
		</td>
	</tr>
</table>