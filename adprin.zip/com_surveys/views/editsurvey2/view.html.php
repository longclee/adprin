<?php

/**
* @author  Chenglong Li
*/

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');

class adprin_SurveysViewEditsurvey extends JView {
	
	function display($tpl = null){
		parent::display($tpl);				
	}
	
	function SurveyDetails($survey_id){
		$model = $this->getModel('editsurvey');
		$result = $model->getSurveyDetails($survey_id);
		return $result;
	}
	
	function Params(){
		$model = $this->getModel('editsurvey');
		$result = $model->getParams();
		return $result;
	}	
	
	function allPages($survey_id){
		$model = $this->getModel('editsurvey');
		$result = $model->getAllPages($survey_id);
		return $result;
	}
	
	function pageDetails($page_id){
		$model = $this->getModel('editsurvey');
		$result = $model->getPageDetails($page_id);
		return $result;
	}
	
	function surveyContent($survey_id, $current_page_id, $params, $completed, $session_id){
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."questions.php");
		$question_list = new QuestionsList();		
		$result = $question_list->getQuestionsList($survey_id, $current_page_id, $params, $completed, $session_id);
		return $result;
	}
	
	function getPrevNextPage($survey_id, $current_page_id, $page_order){
		$model = $this->getModel('editsurvey');
		$pages = $model->getPrevNextPage($survey_id, $current_page_id, $page_order);
		return $pages; 
	}
	
	function getSession($session_id){
		//if($session_id == NULL) return false;
		$model = $this->getModel('editsurvey');
		$details = $model->getSessionDetail($session_id);
		//print_r($details);
		$session = array();
		
		$session["ratername"] = '<input type="text" class="FormStyle" name="ratername" placeholder="Your name" value="'.$details["0"]["rater"].'"></input>';
		
		$session["adrname"] = '<input type="text" class="FormStyle" name="adname" placeholder="Advertisement" value="'.$details["0"]["ad_name"].'"></input>';
		
		$session["comment"] = '<textarea  rows="4" cols="40" class="FormStyle" name="comment" placeholder="add any kind of remark or comment">'.$details["0"]["note"].'</textarea>';
		
		$session["duration"] = '<input type="text" id="survey_timer" name="survey_timer" value="00:00:00" readonly="readonly"></input>';
		if(isset($details["0"]["duration"]) && $details["0"]["duration"] !="") $session["duration"] =  '<input type="text" id="survey_timer" name="survey_timer" value="'.$details["0"]["duration"].'" readonly="readonly"></input>';
		
		return $session;
	}
	
	function lastPage($survey_id, $params, $survey_id_alias){
		$model = $this->getModel('editsurvey');
		$details = $model->getDetails($survey_id);
		$return = "";
				
		if($details["0"]["form_target"]=="0"){		
			$return .= '<table cellspacing="0" cellpadding="0" border="0" width="100%">';
			$return .= 		'<tr>';
			$return .= 			'<td class="'.$params->survey_name.'">'.$details["0"]["title"].'</td>';
			$return .= 		'</tr>';
			$return .= '</table>';
			
			$return .= '<table cellspacing="0" cellpadding="0" align="center" width="100%" class="maintable">';
			$return .= 		'<tr>';
			$return .= 			'<td class="">'.$details["0"]["end_page_title"].'</td>';
			$return .= 		'</tr>';
			$return .= 		'<tr>';
			$return .= 			'<td align="left" width="100%">';
			$return .= 				$details["0"]["end_page_description"];
			$return .= 			'</td>';
			$return .= 		'</tr>';		
			
			if($details["0"]["show_result"] == 1){
				$return .= 		'<tr>';
				$return .= 			'<td align="center" width="100%">';
				
				$return .= '<input type="submit" onclick="document.survey_content.task.value=\'viewresult\'" class="'.$params->button.'" value="'.JText::_("COM_SURVEYS_VIEW_RESULTS_BUTTON").'" name="view_result"/>';				
				$return .= 			'</td>';
				$return .= 		'</tr>';	
			}		
			
			$return .= '</table>';
		}
		else{
			$return = "<script language='javascript1.2' >alert('".$details["0"]["redirection_msg"]."'); window.location='".JRoute::_($details["0"]["redirection_url"])."'</script>";
		}
		
		$this->sendEmail($survey_id);		
		return $return;
	}
	
	function saveFields(){
		$model = $this->getModel('editsurvey');
		$model->save();
	}
	
	function sendEmail($survey_id){
		$model = $this->getModel('editsurvey');
		$model->sendEmail($survey_id);
	}
	
	function getSurveyId(){
		return $this->get("SurveyId");
	}
	
}

?>