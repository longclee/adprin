<?php

/**
* @author  Chenglong Li
*/

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');

class adprin_SurveysViewListsurveyresult extends JView {
	
	function display($tpl = null){		
		$this->params = $this->get("Params");
		
		parent::display($tpl);				
	}
	
	function surveysList($params){
		$model = $this->getModel("listsurveyresult");
		return $model->getSurveysList($params);
	}
}

?>