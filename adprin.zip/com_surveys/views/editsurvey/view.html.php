<?php

/**
* @author  Chenglong Li
*/

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');

class adprin_SurveysViewEditsurvey extends JView {
	
	function display($tpl = null){
		parent::display($tpl);				
	}
	
	function SurveyDetails($survey_id){
		$model = $this->getModel('editsurvey');
		$result = $model->getSurveyDetails($survey_id);
		return $result;
	}
	
	function Params(){
		$model = $this->getModel('editsurvey');
		$result = $model->getParams();
		return $result;
	}	
	
	function allPages($survey_id){
		$model = $this->getModel('editsurvey');
		$result = $model->getAllPages($survey_id);
		return $result;
	}
	
	function pageDetails($page_id){
		$model = $this->getModel('editsurvey');
		$result = $model->getPageDetails($page_id);
		return $result;
	}
	
	function surveyContent($survey_id, $current_page_id, $params, $completed, $session_id,$next_page){
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."questions.php");
		$question_list = new QuestionsList();		
		$result = $question_list->getQuestionsList($survey_id, $current_page_id, $params, $completed, $session_id,$next_page);
		return $result;
	}
	
	function getPrevNextPage($survey_id, $current_page_id, $page_order){
		$model = $this->getModel('editsurvey');
		$pages = $model->getPrevNextPage($survey_id, $current_page_id, $page_order);
		return $pages; 
	}
	
	function getSession($session_id, $current_page_id, $alias){
		//if($session_id == NULL) return false;
		$model = $this->getModel('editsurvey');
		$details = $model->getSessionDetail($session_id);
		//print_r($details);
		$session = array();
		
		
		if($current_page_id == 1 || $details["0"]["rater"] == ""){
			$details["0"]["rater"] = '<input type="text" class="FormStyle" maxlength="100" name="ratername" id="ratername" placeholder="Your name" value="'.$details["0"]["rater"].'" required="required"></input>';
		}
		if($current_page_id == 1 || $details["0"]["ad_name"] == ""){
			$details["0"]["ad_name"] = '<input type="text" class="FormStyle" maxlength="200" name="adname" id="adname" placeholder="Name of Advertisement A" value="'.$details["0"]["ad_name"].'" required="required"></input>';
		}

		if($current_page_id == 1 || $details["0"]["ad_name_b"] == ""){
			$details["0"]["ad_name_b"] = '<input type="text" class="FormStyle" maxlength="200" name="adname_b" id="adname_b" placeholder="Name of Advertisement B" value="'.$details["0"]["ad_name_b"].'"></input>';
		}

		if($current_page_id == 1 || $details["0"]["group_name"] == ""){
			$details["0"]["group_name"] = '<input type="text" class="FormStyle" maxlength="200" name="group_name" id="groupname" placeholder="Name of Your Group" value="'.$details["0"]["group_name"].'" onkeyup="getGroupList(this)"></input>';
		}
		
		if($current_page_id == 1 || $details["0"]["note"] == ""){
			$details["0"]["note"] = '<textarea  rows="4" cols="40" class="FormStyle" name="comment" id="comment" placeholder="add any kind of remark or comment" required="required">'.$details["0"]["note"].'</textarea>';
		}
		
		if($current_page_id == 1 || $details["0"]["email"] == ""){
			$details["0"]["email"] = '<input type="email" class="FormStyle" name="email" id="email" placeholder="Your Email Address for receiving the rating result" value="'.$details["0"]["email"].'" required="required"></input>';
		}
		
		if(isset($details["0"]["duration"]) && $details["0"]["duration"] !=""){
			$details["0"]["duration"] =  '<input type="text" id="survey_timer" name="survey_timer" value="'.$details["0"]["duration"].'" readonly="readonly"></input>';
		}else{
			$details["0"]["duration"] = '<input type="text" id="survey_timer" name="survey_timer" value="00:00:00" readonly="readonly"></input>';
		}
		$gdis = "";

		if(!isset($details["0"]["rater_num"]) || $details["0"]["rater_num"] =="" || $details["0"]["rater_num"] <=1) $gdis = "display: none;";
		else $gdis = "display: block;";
		
		if($current_page_id == 1 || $details["0"]["rater_num"] == 0){
			$details["0"]["rater_num"] = '<input id="rater_num" name="rater_num" type="number"  min="1" max="100" size="3" maxlength="3" class="FormStyle" placeholder="Number of rater involved in the rating of this advertisement" alt="Number of rater involved in the rating of this advertisement" value="'.$details["0"]["rater_num"].'" onchange="selectRaterNum(this);"  required="required"></input>';
			//onchange="selectRaterNum(this);" 
		}
		
		if($current_page_id == 1 || $details["0"]["ad_num"] == 0){
			$select1='';
			$select2='';
			if($details["0"]["ad_num"] == 1){
				$select1='selected="selected"';
			}
			else{
				$select2='selected="selected"';
			}
			
			$details["0"]["ad_num"] = '<select name="ad_num" id="ad_num" required="required" onchange="noshowif2(this)"><option value="1"'.$select1.'>Single</option><option value="2"'.$select2.'>Pair</option></select>';
		}
		
		//$groupcode = $details["0"]["group_code"];
		$group_code = $this->getGroupcode(substr($alias,0,3));
		$details["0"]["new_group_code"] = $group_code;
		$details["0"]["gc_disp"] = $gdis;
		/*if($groupcode ==""){
			$group_code_str = str_replace("#GROUPCODE#",'<b>'.$group_code.'</b>',JText::_("COM_SURVEYS_GROUP_CODE_TXT"));
			$details["0"]["group_code"] = '<div class="UserInfo" id="GroupCode" style="'.$gdis.'">';
			$details["0"]["group_code"] .=		'<label class="InfoText">'.JText::_("COM_SURVEYS_GROUP_CODE").'</label>';
			$details["0"]["group_code"] .=		'<div class="InfoInput">'.$group_code_str.'</br >';
			$details["0"]["group_code"] .=		'<input type="text" class="FormStyle2" name="groupcode" placeholder="The verification code of your group" value="" id="groupcode"></input>';
			$details["0"]["group_code"] .=		'<input onclick="verifyGroupCode(\''.$group_code.'\')" class="Button" value="Verify" name="Codesubmit" type="button"><div id="code_result" class="code_result"></div>';
			$details["0"]["group_code"] .=	'</div>';
		}else{
			$details["0"]["group_code"] = '<div class="UserInfo '.$gdis.'" id="GroupCode">';
			$details["0"]["group_code"] .=		'<label class="InfoText">'.JText::_("COM_SURVEYS_GROUP_CODE").'</label>';
			$details["0"]["group_code"] .=		'<div class="InfoInput">';
			
			//if($current_page_id == 1) {
				//$details["0"]["group_code"] .= '<input type="text" class="FormStyle2" name="groupcode" value="'.$groupcode.'" id="groupcode"></input>';
			//}else{
				$details["0"]["group_code"] .= $groupcode;	
			//}
			
			$details["0"]["group_code"] .='</div></div>';
		}*/

		return $details;
	}
	
	function lastPage($survey_id, $params, $survey_id_alias){
		if(isset($_SESSION["session_id"])){
			$session_id = $_SESSION["session_id"];
		}
		$s_id = JRequest::getVar("s_id", "", "get");
		if($s_id != '') $session_id = $s_id;
		$model = $this->getModel('editsurvey');
		$details = $model->getDetails($survey_id);
		$return = "";
				
		if($details["0"]["form_target"]=="0"){		
			//$return .= '<table cellspacing="0" cellpadding="0" border="0" width="100%">';
			//$return .= 		'<tr>';
			$return .= 			'<div class="'.$params->survey_name.'">'.$details["0"]["title"].'</div>';
			//$return .= 		'</tr>';
			//$return .= '</table>';
			
			//$return .= '<table cellspacing="0" cellpadding="0" align="center" width="100%" class="maintable">';
			//$return .= 		'<tr>';

			//$return .= 		'</tr>';		
			
			if($details["0"]["show_result"] == 1){
				/*$return .= 		'<tr>';
				$return .= 			'<td align="center" width="100%">';
				
				$return .= '<input type="submit" onclick="document.survey_content.task.value=\'viewresult\'" class="'.$params->button.'" value="'.JText::_("COM_SURVEYS_VIEW_RESULTS_BUTTON").'" name="view_result"/>';				
				$return .= 			'</td>';
				$return .= 		'</tr>';
				*/
				include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."view_details.php");
				$vd = new ViewDetails();	
				$result = $vd->getSummary($survey_id, $session_id, $details);	
				$return .= $result;	
				//$vd->sendResultEmail($result, $session_id, $details);	
						
			}		
			$return .= 			'<div class="SurveyEndTitle">'.$details["0"]["end_page_title"].'</div>';
			//$return .= 		'</tr>';
			//$return .= 		'<tr>';
			$return .= 			'<div class="SurveyEndDesc">';
			$return .= 				$details["0"]["end_page_description"];
			$return .= 			'</div>';			
			//$return .= '</table>';
		}
		else{
			$return = "<script language='javascript1.2' >alert('".$details["0"]["redirection_msg"]."'); window.location='".JRoute::_($details["0"]["redirection_url"])."'</script>";
		}
		
		$this->sendEmail($survey_id);		
		return $return;
	}
	
	function saveFields(){
		$model = $this->getModel('editsurvey');
		$model->save();
	}
	
	function sendEmail($survey_id){
		$model = $this->getModel('editsurvey');
		$model->sendEmail($survey_id);
	}
	
	function sendIndivEmail($survey_id){
		$model = $this->getModel('editsurvey');
		$model->sendEmail($survey_id);
	}
	
	function getSurveyId(){
		return $this->get("SurveyId");
	}
	
	function getGroupcode($alias){
		$group_code = $alias.substr(microtime(),-7,7);
		$found = false;
		
		while(!$found){
			$db =& JFactory::getDBO();		
			$sql = "select count(*) from #__adprin_surveys_session where group_code='".$group_code."'";		
			$db->setQuery($sql);
			$db->query();
			$result = $db->loadResult();
			if($result == 0) {
				$found = true;
				//$string = substr(microtime(), 14, 5);
				//$group_code = $alias.substr(microtime(),-10,10);
			}else{
				$found = false;
				//$string = substr(microtime(), 14, 5);
				$group_code = $alias.substr(microtime(),-7,7);
			}
		}
		return strtoupper($group_code);
	}
	
	function genRandomString($length){
		$characters = '0123456789abcdefghijklmnopqrstuvwxyz';
		$string = '';
		
		for ($p = 0; $p <= $length; $p++) {
			$string .= $characters[mt_rand(0, strlen($characters))];
		}
		
		return $string;
	}

}

?>