<?php

/**
* @author  Chenglong Li
*/

	defined('_JEXEC') or die('Restricted access');		
	include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."login.php");	
	include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."check_completed.php");
	
	$document =& JFactory::getDocument();
	$document->addStyleSheet("components/com_surveys/css/survey.css");
	$site_js = '	var site="'.JURI::base().'";'."\n";
	$document->addScriptDeclaration($site_js);
	$document->addScript(JURI::base()."components/com_surveys/javascript/survey_functions.js");

	$user =& JFactory::getUser();
	$user_id = $user->id;
	$user_type = $user->groups;
		
	$survey_id_alias = JRequest::getVar("id", "0");
	if($survey_id_alias == "0"){// if we come from a menu, not from a link from list of surveys		
		$survey_id_alias = $this->getSurveyId();
	}
	$survey_id_array = explode(":", $survey_id_alias);
	$survey_id = $survey_id_array["0"];
	$current_page_id = JRequest::getVar("page", "0");
	$session_id = "";
	$show_survey = true;
	$params = "";

	$survey_details = $this->SurveyDetails($survey_id);
	$all_pages = $this->allPages($survey_id);
	
	$item_id = JRequest::getVar("Itemid", "0");
?>
	<form name="survey_content" id="survey_content" method="post">	
<?php
	if($user_id == "0" && isset($survey_details["0"]) && $survey_details["0"]["access"] != "1"){
		$login = new Login();
		echo $login->getLogin($_SERVER['QUERY_STRING']);
	}
	elseif($user_id != "0" && isset($survey_details["0"]) && $survey_details["0"]["access"] == "3" && !isset($user_type["Super Users"])){
		$login = new Login();
		echo $login->getLogin($_SERVER['QUERY_STRING']);
	}
	else{
		$params = $this->Params();		
		$cc = new CheckCompleted();
		$completed = $cc->check_completed($survey_id, $user_id, $params->general_value);		
		
		if(isset($completed["already_completed"])){
			if($current_page_id != "last"){
				echo '<b>'.$completed["already_completed"].'</b>';
			}
			$show_survey = false;
			
		}
		else{			
			if($current_page_id == "0"){
				$_SESSION["prev_page_array"] = NULL;
				$_SESSION["skip_pages"] = NULL;
				$current_page_id = isset($completed["page_to_view"]) ? intval($completed["page_to_view"]) : "0";				
			}
			if($current_page_id == "last"){
				$show_survey = false;
			}
			$session_id = isset($completed["session_id"]) ? intval($completed["session_id"]) : "";
			$s_id = JRequest::getVar("s_id", "", "get");
			if($s_id != '') $session_id = $s_id;
?>
		<div class="SurveyContent">
	<?php
		if($show_survey != false && isset($survey_details["0"])){
			$session_detail = $this->getSession($session_id,$current_page_id,$survey_details["0"]["alias"]);
			

	?>
			<!-- survey header, image and description -->
		<div id="userinfobox" class="userinfobox">
			<div class="SurveyName"><?php echo $survey_details["0"]["title"]; ?>
				<div class="timer"><?php echo $session_detail["0"]["duration"];?></div>
			</div>
	<?php
		$mode = JRequest::getVar("mode", "", "get");
		if($mode == "training"){
	?>
	<input type="hidden" id="rater_num" name="rater_num" value="1" />
	<input type="hidden" name="ad_num" id="ad_num" value="2" />
	<?php
		}else{
	?>
			<div class="UserInfo">
				<label class="InfoText4">Audit a single advertisement, or a pair for the same product:</label>
				<div class="InfoInput4"><?php echo $session_detail["0"]["ad_num"]; ?></div>
			</div>		
	<?php
		}
	?>	

			<div class="UserInfo" id="AdNameA">
				<label class="InfoText" id="AdA"><?php echo JText::_("COM_SURVEYS_AD_NAME"); ?>
			<?php 
			if($mode != "training"){
					if(($current_page_id == "1" || $current_page_id == "-1") 
			|| (isset($session_detail["0"]["rater_num"]) && $session_detail["0"]["rater_num"] > 1)) echo ' A';
			};?></label>
				<div class="InfoInput"><?php echo $session_detail["0"]["ad_name"];?></div>
			</div>
	<?php
		if($mode != "training"){
			if(($current_page_id == "1" || $current_page_id == "-1") 
			|| (isset($session_detail["0"]["rater_num"]) && $session_detail["0"]["rater_num"] > 1)){
	?>
			<div class="UserInfo" id="AdNameB">
				<label class="InfoText"><?php echo JText::_("COM_SURVEYS_AD_NAME"); ?> B</label>
				<div class="InfoInput"><?php echo $session_detail["0"]["ad_name_b"];?></div>
			</div>
	<?php
			}
	?>
			<div class="UserInfo">
				<label class="InfoText"><?php echo JText::_("COM_SURVEYS_RATER_NUMBER"); ?></label>
				<div class="InfoInput"><?php echo $session_detail["0"]["rater_num"]; ?></div>
			</div>
	<?php
		}
	?>
			<div class="UserInfo">
				<label class="InfoText"><?php echo JText::_("COM_SURVEYS_RATER_NAME"); ?></label>
				<div class="InfoInput"><?php echo $session_detail["0"]["rater"];?></input></div>
			</div>

			<div class="UserInfo">
				<label class="InfoText"><?php echo JText::_("COM_SURVEYS_EMAIL"); ?></label>
				<div class="InfoInput"><?php echo $session_detail["0"]["email"]; ?></div>
			</div>

			<div class="UserInfo" id="groupnamebox" <?php if (!isset($session_detail["0"]["rater_num"]) || $session_detail["0"]["rater_num"] < 2) echo 'style="display: none;"';?>>
				<label class="InfoText">Group Name</label>
				<div class="InfoInput"><?php echo $session_detail["0"]["group_name"];?></div>
			</div>

			<div class="UserInfo" id="grouplistbox" style="display: none;">
				<label class="InfoText"></label>
				<div class="InfoInput" id="grouplist"></div>
			</div>
			
			<input type="hidden" value="<?php echo $session_detail["0"]["group_code"];?>" name="groupcode" id="groupcode">
			<input type="hidden" value="<?php echo $session_detail["0"]["new_group_code"];?>" name="new_group_code" id="new_group_code">

	<?php	
		
		if($current_page_id == "last"){
	?>
			<div class="UserInfo">
				<label class="InfoText"><?php echo JText::_("COM_SURVEYS_COMMENT"); ?></label>
				<div class="InfoInput"><?php echo $session_detail["0"]["note"]; ?></div>
			</div>	
			
	<?php
		}
		
		if($current_page_id == "1" || $current_page_id == "-1"){
	?>
	<!--
			<div class="UserInfo">
				<label class="InfoText"></label>
				<div class="InfoInput"><input class="Button" type="button" onclick="submitUserInfo()" value="Submit"><span id="userinforesult"></span></div>
				
			</div>
-->
	<?php
		}
	?>
		</div>
			<div class="survey_image">
						<?php
							if(trim($survey_details["0"]["imagelist"]) != ""){
						?>
								<img border="0" alt="" src="images/<?php echo $survey_details["0"]["imagelist"]; ?>" />
						<?php
							}
						?>
			</div>
			<?php
			if($mode != "training"){
				if(isset($survey_details["0"]) && $survey_details["0"]["description"] != ""){?>						
				<div class="SurveyDesciption"><?php echo $survey_details["0"]["description"]; ?></div>
				<?php 
					}
			}else{
				if(isset($survey_details["0"]) && $survey_details["0"]["training_desc"] != ""){ ?>

				<div class="SurveyDesciption"><?php echo $survey_details["0"]["training_desc"]; ?></div>						

				<?php 
				}
			}//if
			?>	

			<!-- page title, image, description -->
			<?php
				if(count($all_pages)>0){			
					if($current_page_id == "0" || $current_page_id == "-1"){
						$current_page_id = $all_pages["0"]["id"];

					}										
					$page_details = $this->pageDetails($current_page_id);		
			?>
			<div class="PageContainer">
					<?php 
						//if is set to display page title or no
						if($page_details["0"]["show_title"] == "1"){ 
					?>

				<div class="PageName"><span><?php echo $page_details["0"]["section_num"]; ?>&nbsp;&nbsp;<?php echo $page_details["0"]["title"]; ?></span></div>

					<?php 
						}
					?>
					<hr />
						<?php
							if(trim($page_details["0"]["imagelist"]) != ""){
						?>
				<div class="PageImg">
					<img alt="" src="images/<?php echo $page_details["0"]["imagelist"]; ?>" />
				</div>	
						<?php
							}
						?>
				<div class="PageDesc">
					<span><?php echo $page_details["0"]["description"]; ?></span>
				</div>
			</div>
			<?php
				}
			?>	
	<?php
		}//else - already completed
	}//else login
		
	?>
	
	<?php
		$page_order = @$page_details["0"]["ordering"];		
		$pages = $this->getPrevNextPage($survey_id, $current_page_id, $page_order);		
		$prev_page = $pages["prev"];	
		$next_page = $pages["next"];
	?>
		
	<!-- survey conten: pages and question -->	
			
		<?php 			
			if($show_survey === true){				
				echo $this->surveyContent($survey_id, $current_page_id, $params, $completed, $session_id, $next_page); 
			}
			
			if($current_page_id == "last"){
				//$session_id = JRequest::getVar("s_id", "", "get");
				echo $this->lastPage($survey_id, $params, $survey_id_alias);
			}
		?>		
		<input type="hidden" name="previews_page_id" value="<?php echo $prev_page; ?>" />
		<input type="hidden" name="current_page_id" value="<?php echo $current_page_id; ?>" />
		<input type="hidden" id="next_page_id" name="next_page_id" value="<?php echo $next_page; ?>" />
		<input type="hidden" name="task" value=""/>
		<input type="hidden" id="session_id" name="session_id" value="<?php echo $session_id; ?>" />
		<?php
			if($session_id != ""){
				$_SESSION["session_id"] = $session_id;
			}
		?>
		<input type="hidden" id="survey_id" name="id" value="<?php echo $survey_id; ?>" />
		<input type="hidden" name="survey_id_alias" value="<?php echo $survey_id_alias; ?>" />
		<input type="hidden" name="option" value="com_surveys"/>
		<input type="hidden" name="controller" value="editsurvey"/>
		<input type="hidden" name="Itemid" value="<?php echo intval($item_id); ?>"/>
	</form>
	
<?php 
	}//else 
?>
		</div>
   <script type="text/javascript">
   <?php
   if($current_page_id != "last"){
   	?>
	   showTimer();
	   
	   <?php 
	}
	   if($mode != "training"){
	   	if($current_page_id == "1" || $current_page_id == "-1"){
	   ?>
	   	noshowif2(document.getElementById('ad_num'));
	   	if(document.getElementById('rater_num').value > 1){
	   		document.getElementById('groupnamebox').style.display = "block";
	   	}else{
	   		document.getElementById('groupnamebox').style.display = "none";
	   	}
	<?php
		}
	}else{
		?>
	var p = document.getElementsByName("noshowif2");
	for(var i=0; i<p.length; i++){
		if(obj.value == 1) p[i].style.display= "none";
		else p[i].style.display= "block";
	}
	<?php
	};
	?>
    </script>