<?php

/**
* @author  Chenglong Li
*/

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.modellist');
jimport('joomla.utilities.date');

class adprin_SurveysModelEditSurvey extends JModel{
	
	function showResult($survey_id){
		$db =& JFactory::getDBO();
		$sql = "select show_result from #__adprin_surveys_surveys where id=".intval($survey_id);
		$db->setQuery($sql);
		$db->query();
		$result = $db->loaDresult();
		return $result;
	}
	
	function getSurveyDetails($survey_id){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('*');
		$query->from('#__adprin_surveys_surveys');
		$query->where("id=".$survey_id);
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadAssocList();		
		return $result;
	}
	
	function getParams(){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('params');
		$query->from('#__extensions');
		$query->where("element='com_surveys'");
		$db->setQuery($query);		
		$db->query();
		$result_string = $db->loadAssocList();
		$result = json_decode($result_string["0"]["params"]);		
		return $result;
	}
	
	function getAllPages($survey_id){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('id');
		$query->from('#__adprin_surveys_pages');
		$query->where("survey_id=".$survey_id." and published=1");
		$query->order("ordering asc");
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadAssocList();		
		return $result;
	}
	
	function getPageDetails($page_id){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('*');
		$query->from('#__adprin_surveys_pages');
		$query->where("id=".$page_id);
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadAssocList();		
		return $result;
	}
	
	function getPrevNextPage($survey_id, $current_page_id, $page_order){
		if(isset($_SESSION["session_id"])){
			$session_id = $_SESSION["session_id"];
		}
		$pages = array();
		$skip_pages = "";
		$jump_pages = array();
		$db =& JFactory::getDBO();
		$query = $db->getQuery(true);
		$all_question = @$_SESSION["questions"];
		//print_r($all_question);
		
		//check skip pages
		$skip_action = $this->getAllSkipAction();
		//print_r($skip_action);
		
		if(is_array($skip_action) && count($skip_action)>0){
			foreach($skip_action as $skip_key=>$skip_val){
				
				$answer = $this->getSkipAnswer($session_id, $skip_val["question_id"]);
				$skip_answer = explode(",", $skip_val["answer_value"]);					
				$action = $skip_val["action"];	
				//echo $action.'$$';
				//print_r($skip_answer);
					
				if(is_array($skip_answer) && count($skip_answer)>0){
					$query->clear();
					$query->select('question_type');
					$query->from('#__adprin_surveys_questions');
					$query->where("id=".$skip_val["question_id"]);
					$db->setQuery($query);
					$db->query();
					$question_type = $db->loadResult();
					//echo $question_type."@@@@";
						
					if($this->checkCorrectCompleted($skip_val, $answer, $skip_answer, $question_type)){							
						if($action == "jump to"){
							//if($skip_val["page_target"] == -1){
							//	$jump_pages[$skip_val["id"]] = "last";
							//}
							//else{
							$jump_pages[$skip_val["id"]] = $skip_val;
							//}
							
							/*if(isset($jump_pages["next"] ) && $jump_pages["next"] !=""){
								$pages["next"] = $jump_pages["next"];
								$pages["prev"] = $current_page_id;	
							}*/
						}
						elseif($action == "skip"){
							$skip_pages .= ','.$skip_val["page_target"];
						}
						$pages["prev"] = $current_page_id;							
					}
				}
			}
			
			/*$page_array = array();
			if(isset($_SESSION["prev_page_array"])){								
				$page_array = $_SESSION["prev_page_array"];								
			}
			$page_array[$current_page_id] = $current_page_id;			
			$_SESSION["prev_page_array"] = $page_array;
			// skip--------------------------------------------
			*/
		}
		
		//check for next page
		$query->clear();		
		$query->select('id');
		$query->from('#__adprin_surveys_pages');
		$query->where("survey_id=".$survey_id." and id not in (".$current_page_id.$skip_pages.") and ordering >=".$page_order." and published=1");
		$query->order("ordering asc");
		$db->setQuery($query, 0, 1);
		$db->query();
		$result = $db->loadResult();
		//echo $query;
		
		if(isset($result) && $result != NULL){			
			$pages["next"] = $result;
		}
		else{
			$pages["next"] = "last";
		}
		
		//check for preview page
		$query->clear();		
		$query->select('id');
		$query->from('#__adprin_surveys_pages');
		$query->where("survey_id=".$survey_id." and id not in (".$current_page_id.$skip_pages.") and ordering <=".$page_order." and published=1");
		$query->order("ordering desc");
		$db->setQuery($query, 0, 1);		
		$db->query();
		$result = $db->loadResult();		
		if(isset($result) && $result != NULL){			
			$pages["prev"] = $result;
		}
		else{
			$pages["prev"] = "first";
		}	
		//echo $query;
		//print_r($jump_pages);
		
		if(count($jump_pages)>0){
			foreach($jump_pages as $j_key=>$j_val){
				if($j_val["page_target"] == $current_page_id){
					$pages["prev"] = $j_val["page_id"];
				}
				
				if($j_val["page_id"] == $current_page_id){
					if($j_val["page_target"] == -1){
						$pages["next"] = 'last';
					}else{
						$pages["next"] = $j_val["page_target"];
					}
				}
			}
		}
		
		return $pages;
	}
	
	function getSkipAnswer($session_id, $question_id){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('*');
		$query->from('#__adprin_surveys_result a');
		$query->where("a.q_id=".$question_id." and a.session_id=".$session_id);
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadAssocList();	
		//echo $query;
		
		$answer = array();
		if(count($result)<=0){
			$query->clear();		
			$query->select('*');
			$query->from('#__adprin_surveys_result_text a');
			$query->where("a.q_id=".$question_id." and a.session_id=".$session_id);
			$db->setQuery($query);		
			$db->query();
			$result = $db->loadAssocList();	
			foreach($result as $key=>$val){
				array_push($answer,$val["value"]);
			}
		}else{
			foreach($result as $key=>$val){
				$ans = $val["a_id"] ? $val["a_id"] : $val["m_id"];
				array_push($answer,$ans);
			}	
		}
		//echo $query;
		return $answer;
	}
/*	
	function getPrevNextPage($survey_id, $current_page_id, $page_order){
		$pages = array();
		$db =& JFactory::getDBO();
		$query = $db->getQuery(true);
		
		// skip---------------------------
		$skip_pages = "0";
		if(isset($_SESSION["skip_pages"])){
			$skip_pages = $_SESSION["skip_pages"];
		}
		//--------------------------------
		
		//check for next page
		$query->clear();		
		$query->select('id');
		$query->from('#__adprin_surveys_pages');
		$query->where("survey_id=".$survey_id." and id not in (".$current_page_id.",".$skip_pages.") and ordering >=".$page_order." and published=1");
		$query->order("ordering asc");
		$db->setQuery($query, 0, 1);
		$db->query();
		$result = $db->loadResult();
		//echo $query;
		
		if(isset($result) && $result != NULL){			
			$pages["next"] = $result;
		}
		else{
			$pages["next"] = "last";
		}
		
		//check for preview page
		$query->clear();		
		$query->select('id');
		$query->from('#__adprin_surveys_pages');
		$query->where("survey_id=".$survey_id." and id not in (".$current_page_id.",".$skip_pages.") and ordering <=".$page_order." and published=1");
		$query->order("ordering desc");
		$db->setQuery($query, 0, 1);		
		$db->query();
		$result = $db->loadResult();		
		if(isset($result) && $result != NULL){			
			$pages["prev"] = $result;
		}
		else{
			$pages["prev"] = "first";
		}	
		echo $query;
		
		//check for skip action------------------------------
		$all_question = @$_SESSION["questions"]; //JRequest::getVar("question"); // all questions from the current page		
		//unset($_SESSION["questions"]);
		//unset($_SESSION["skip_pages"]);
		//$all_question = $this->getAllQuestions($survey_id);
		//print_r($all_question);		
		$skip_action = $this->getAllSkipAction();				

		if(isset($all_question) && is_array($all_question) && count($all_question)>0 && is_array($skip_action) && count($skip_action)>0){
			foreach($all_question as $key=>$value){
				$answer = $value["answer"] ? $value["answer"] : $value["answer_text"];
				if($answer == NULL){
					$answer = $value["menu"];
				}
				$position = $this->existSkipAction($key, $skip_action);
				//echo $position.'$$';
				if($position != "-1"){
					$skip_answer = explode(",", $skip_action[$position]["answer_value"]);					
					$action = $skip_action[$position]["action"];	
					//echo $position.'$$';
					
					if(is_array($skip_answer) && count($skip_answer)>0){
						$query->clear();
						$query->select('question_type');
						$query->from('#__adprin_surveys_questions');
						$query->where("id=".$key);
						$db->setQuery($query);
						$db->query();
						$question_type = $db->loadResult();
						
						if($this->checkCorrectCompleted($skip_action[$position], $answer, $skip_answer, $question_type)){							
							if($action == "jump to"){
								if($skip_action[$position]["page_target"] == -1){
									$pages["next"] = "last";
								}
								else{
									$pages["next"] = $skip_action[$position]["page_target"];
								}
								
							}
							elseif($action == "skip"){
								$skip_pages = "";
								if(isset($_SESSION["skip_pages"])){
									$skip_pages = $_SESSION["skip_pages"].",".$skip_action[$position]["page_target"];
									$_SESSION["skip_pages"] = $skip_pages;
								}
								else{
									$_SESSION["skip_pages"] = $skip_action[$position]["page_target"];
									$skip_pages = $skip_action[$position]["page_target"];
								}
								$query->clear();		
								$query->select('id');
								$query->from('#__adprin_surveys_pages');
								$query->where("survey_id=".$survey_id." and id not in (".intval($current_page_id).",".$skip_pages.") and ordering >=".intval($page_order)." and published=1");
								$query->order("ordering asc");
								$db->setQuery($query, 0, 1);
								$db->query();
								$result = $db->loadResult();
								if(isset($result) && $result != NULL){
									$pages["next"] = $result;
								}
								else{
									$pages["next"] = "last";
								}
							}
							$pages["prev"] = $current_page_id;							
						}
					}
					break;
				}
			}
			// skip
			$page_array = array();
			if(isset($_SESSION["prev_page_array"])){								
				$page_array = $_SESSION["prev_page_array"];								
			}
			$page_array[$current_page_id] = $current_page_id;			
			$_SESSION["prev_page_array"] = $page_array;
			// skip--------------------------------------------
		}
		$_SESSION["questions"] = array();
		return $pages;
	}
*/	
	function existSkipAction($id, $skip_action){
		$return = "-1";
		if(isset($skip_action)){
			foreach($skip_action as $key=>$value){
				if($value["question_id"] == $id){
					return $key;
				}
			}
		}
		return $return;
	}
	
	function getAllSkipAction(){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('*');
		$query->from('#__adprin_surveys_skip_logics');
		$query->where("published=1");
		$db->setQuery($query);		
		$db->query();
		$result_array = $db->loadAssocList();
		$result = array();
		/*if(isset($result_array) && is_array($result_array) && count($result_array)>0){
			foreach($result_array as $key=>$value){
				$result[$value["question_id"]] = $value;
			}
		}*/
		return $result_array;
	} 
	
	function checkCorrectCompleted($skip_action, $answer, $skip_answer, $question_type){
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionEssay.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionMultiplePerRow.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionOneAnswer.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionOneAnswerMenu.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionMultipleAnswer.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionOnePerRow.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionEndedOneLine.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionEndedMoreLines.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionConstant.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionDateTime.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionRating.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionMultiplePerRowMenus.php");
		require_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."questions.php");
		
		$logic = $skip_action["logic"];
		$compare = $skip_action["compare"];
		
		$class_object = new Question();
		$class = "Question".$class_object->getClass($question_type);
		$object = new $class();		
		$result = $object->checkCompleted($logic, $compare, $answer, $skip_answer);		

		return $result;
	}
	
	function getDetails($survey_id){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('title, show_result, form_target, redirection_url, redirection_msg, end_page_title, end_page_description');
		$query->from('#__adprin_surveys_surveys');
		$query->where("id=".$survey_id);
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadAssocList();		
		return $result;
	}
	
	function getSessionDetail($session_id){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('*');
		$query->from('#__adprin_surveys_session');
		$query->where("id=".$session_id);
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadAssocList();		
		return $result;
	}
	
	function save(){
		$db =& JFactory::getDBO();		
		$survey_id = JRequest::getVar("id", "", "post");
		$session_id = JRequest::getVar("session_id", "", "post");
		$next_page_id = JRequest::getVar("next_page_id", "", "post");
		$rater_name = JRequest::getVar("ratername", "", "post");
		$ad_name = JRequest::getVar("adname", "", "post");
		$ad_name_b = JRequest::getVar("adname_b", "", "post");
		$comment = JRequest::getVar("comment", "", "post");
		$ad_num = JRequest::getVar("ad_num", "", "post");
		$rater_num = JRequest::getVar("rater_num", "", "post");
		$group_name = JRequest::getVar("groupname", "", "post");
		$group_code = JRequest::getVar("groupcode", "", "post");
		$new_group_code = JRequest::getVar("new_group_code", "", "post");
		$email = JRequest::getVar("email", "", "post");
		$timer = JRequest::getVar("survey_timer", "", "post");
		$mode = JRequest::getVar("mode", "", "");
		//$task = JRequest::getVar("task", "", "");

		if($next_page_id == "last"){
			$next_page_id = "0";
		}
		$user =& JFactory::getUser();
		$user_id = $user->id;		
		$jnow =& JFactory::getDate();
		$date =  $jnow->toMySQL();
		
		$group_pos = 1;

		if($ad_num == 1) $ad_name_b = "";

		if($rater_num < 2) $group_name = "";

		if($group_code != ""){
			$s_and = '';
			if($session_id != "") $s_and = "and `id`<>".$session_id;
			$sql = "select count(*) from #__adprin_surveys_session where `group_code`='".$group_code."'  ".$s_and; 
			//JFactory::getApplication()->enqueueMessage($sql, 'error');
			$db->setQuery($sql);
			$db->query();
			$group_count = $db->loadResult();
		
			if(count($group_count)>0){
				$group_pos = $group_count+1;
			}
	
		}else{
			$group_code = $new_group_code;
		}

		if(!$session_id){
			//start new session
			$completed = "0";
			if($next_page_id == "0"){
				//if jump to survey end
				$completed = "1";
			}
			$sql = "insert into #__adprin_surveys_session (`user_id`, `survey_id`, `ip`, `played_time`, `completed`, `last_page_id`, `published`, `rater`, `ad_name`, `ad_name_b`, `note`, `ad_num`, `rater_num`, `group_name`, `group_code`, `email`, `group_pos`, `mode`) values ".
				   "(".$user_id.", ".$survey_id.", '".$_SERVER['REMOTE_ADDR']."', '".$date."', ".$completed.", ".$next_page_id.", 1, '".$rater_name."', '".$ad_name."', '".$ad_name_b."', '".$comment."', ".$ad_num.", ".$rater_num.", '".$group_name."', '".$group_code."', '".$email."',".$group_pos.", '".$mode."')";	
			//echo $sql;
			$db->setQuery($sql);
            $sqlz[] = $sql;
			if($db->query()){
				$sql = "select max(id) from #__adprin_surveys_session";
                $sqlz[] = $sql;
				$db->setQuery($sql);
				$db->query();
				$session_id = $db->loadResult();                
				$_SESSION["session_id"] = $session_id;
			}
				
		}		
		else{			
			if($next_page_id == "0"){
				$sql = "update #__adprin_surveys_session set `last_page_id`=0 , `completed`=1 where id=".$session_id;				   
				$db->setQuery($sql);
				$db->query();				
			}
			else{
				//updata existing session
				$sql = "update #__adprin_surveys_session set `last_page_id`=".$next_page_id.", `completed`=0 where id=".$session_id;				   
				$db->setQuery($sql);
				$db->query();
			}
			$_SESSION["session_id"] = $session_id;			
		
		
			$set_sql = '';
			if($rater_name != ""){
				$set_sql .= ",`rater`='".$rater_name."'";
			} 
			
			if($ad_name != ""){
				$set_sql .= ",`ad_name`='".$ad_name."'";
			} 

			if($ad_name_b != ""){
				$set_sql .= ",`ad_name_b`='".$ad_name_b."'";
			} 
			
			if($ad_num != ""){
				$set_sql .= ",`ad_num`=".$ad_num;
			} 
			
			if($rater_num != ""){
				$set_sql .= ",`rater_num`=".$rater_num;
			} 

			if($group_name != ""){
				$set_sql .= ",`group_name`='".$group_name."'";
			} 
			
			if($group_code != ""){
				$set_sql .= ",`group_code`='".$group_code."',`group_pos`=".$group_pos;
			}

			if($comment != ""){
				$set_sql .= ",`note`='".$comment."'";
			}
			
			if($email != ""){
				$set_sql .= ",`email`='".$email."'";
			}
			
			$sql = "update #__adprin_surveys_session set `duration`='".$timer."'".$set_sql.' where id='.$session_id;
			//echo $sql;
			$db->setQuery($sql);
			$db->query();	
			

		}
		//JFactory::getApplication()->enqueueMessage($sql, 'error');
		//if($task == "submitUserInfo")  return true;

		$this->saveFields($session_id, $survey_id);
		
	}
	
	function saveFields($session_id, $survey_id){
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionEssay.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionMultiplePerRow.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionOneAnswer.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionOneAnswerMenu.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionMultipleAnswer.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionOnePerRow.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionEndedOneLine.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionEndedMoreLines.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionConstant.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionDateTime.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionRating.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionMultiplePerRowMenus.php");
		
		$all_dates = JRequest::get('post', JREQUEST_ALLOWHTML);
		//print($all_dates);
		
		$questions = array();
		$classes = array();
		
		if(isset($all_dates["question"])){
			$questions = $all_dates["question"];
		}
		if(isset($all_dates["classes"])){
			$classes = $all_dates["classes"]; 
		}	
		
		$params = $this->getParams();
		if(isset($questions) && count($questions) > 0){
			
			if(isset($_SESSION["questions"])){
				$_SESSION["questions"] = $_SESSION["questions"] + $questions;
			}
			else{
				$_SESSION["questions"] = $questions;
			}
			
			foreach($questions as $key=>$value){
				$object = new $classes[$key];
				$object->save($key, $params->general_value, $session_id);
			}
		}
	}
	
	function getAllQuestions($survey_id){
		$data = new JDate();
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();
		$query->select('*');
		$query->from('#__adprin_surveys_questions');
		$query->where("survey_id=".$survey_id." and published=1 and published_up <= '".$data."' and ((published_down >= '".$data."') or published_down='0000-00-00 00:00:00')");
		$query->order("ordering asc");
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadAssocList();		
		return $result;
	}
	
	function editResult($from_menu = ""){		
		$document =& JFactory::getDocument();
		$document->addStyleSheet("components/com_surveys/css/survey.css");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionEssay.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionMultiplePerRow.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionOneAnswer.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionOneAnswerMenu.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionMultipleAnswer.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionOnePerRow.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionEndedOneLine.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionEndedMoreLines.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionConstant.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionDateTime.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionRating.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionMultiplePerRowMenus.php");
		require_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."questions.php");		
			
		$params = $this->getParams();
		$class_object = new Question("", "", "", "", "", "", "", "");
		$survey_id = JRequest::getVar("id", "0");		
		if($survey_id == "0" && $from_menu != ""){
			$item_id = JREquest::getVar("Itemid", "0");
			$sql = "select params from #__menu where id=".intval($item_id);
			$db =& JFactory::getDBO();
			$db->setQuery($sql);
			$db->query();
			$result = $db->loadResult();
			if($result != NULL && trim($result) != ""){
				$params_menu = json_decode($result);
				$survey_id = $params_menu->sid_menu;
			}
		}	
		$all_responses_count = $this->getAllResponses($survey_id);		
		$all_questions = $this->getAllQuestions($survey_id);
		$i = 1;
		
		$result  = '<form name="view_result" action="">';
		$result .= '<div class="result_container">';
		$result .= 		'<div class="'.$params->survey_name.'">'.$this->getSurveyName($survey_id).'</div>';
		$result .= 		'<div class="result_heading"><span class="'.$params->result_heading.'">'.JText::_("COM_SURVEYS_RESULTS_SUMMARY").'</span></div>';
		 
/* 		if(isset($all_questions) && is_array($all_questions) && count($all_questions)>0){
			foreach($all_questions as $key=>$value){				
				$class = "Question".$class_object->getClass($value["question_type"]);				
				$object = new $class();
				if($value["show_on_results"] == 1){
					$result .= $object->editResult($value["id"], $survey_id, $params, $i, $value["title"], $all_responses_count);
					$result .= "<br /><br />";
					$i++;
				}
			}
		} */		

		$session_id = "0";
		if(isset($_SESSION["session_id"])){
			$session_id = $_SESSION["session_id"];
		}
			
		
		$result .= '<input type="hidden" name="option" value="com_surveys"/>';
		$result .= '<input type="hidden" name="controller" value="editsurvey"/>';
		$result .= '<input type="hidden" name="task" value="edit_details"/>';
		$result .= '<input type="hidden" name="q_id" value=""/>';
		$result .= '<input type="hidden" name="a_id" value=""/>';
		$result .= '</form>';	
		$result .= '</div>';		
		echo $result;
	}
	
	function getAllResponses($survey_id){
		$db =& JFactory::getDBO();
		$sql = "select count(*) from #__adprin_surveys_session where completed=1 and last_page_id=0 and published=1 and survey_id=".$survey_id;
		$db->setQuery($sql);
		$db->query();
		$result = $db->loadResult();
		return $result;
	}
	
	function getSurveyName($survey_id){
		$db =& JFactory::getDBO();
		$sql = "select title from #__adprin_surveys_surveys where id=".$survey_id;
		$db->setQuery($sql);
		$db->query();
		$result = $db->loadResult();
		return $result;
	}
	
	function getEmailSettings(){
		$db =& JFactory::getDBO();
		$sql = "select * from #__adprin_surveys_email_settings";
		$db->setQuery($sql);
		$db->query();
		$result = $db->loadAssocList();
		return $result;
	}
	
	function editDetails(){
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."view_details.php");
		$class = new ViewDetails();
		$return = $class->edit();
		echo $return;
	}
	
	function getEmailQuestionsContent($survey_id, $session_id){
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionEssay.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionMultiplePerRow.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionOneAnswer.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionOneAnswerMenu.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionMultipleAnswer.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionOnePerRow.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionEndedOneLine.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionEndedMoreLines.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionConstant.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionDateTime.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionRating.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionMultiplePerRowMenus.php");
		require_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."questions.php");
				
		$class_object = new Question("", "", "", "", "", "", "", "");
		$all_questions = $this->getAllQuestions($survey_id);
		$result = "";
		
		if(isset($all_questions) && is_array($all_questions) && count($all_questions)>0){
			foreach($all_questions as $key=>$value){				
				$class = "Question".$class_object->getClass($value["question_type"]);							
				$object = new $class();
				$result .= $object->getQuestionResultForEmail($value["id"], $session_id, $value["title"]);
				$result .= "\n\n";
			}
		}
		
		return $result;	
	}
	
	function sendEmail($survey_id){
		unset($_SESSION["questions"]);
		$survey_name = $this->getSurveyName($survey_id);
		$user =& JFactory::getUser();
		$user_id = $user->id;
		$mail_settings = $this->getEmailSettings();
		$survey_settings = $this->getSurveyDetails($survey_id);
		$session_id = "0";
		if(isset($_SESSION["session_id"])){
			$session_id = $_SESSION["session_id"];
		}
		
		if($survey_settings["0"]["email_send"] == "2"){
			return; //set NO for send email for current survey
		}
		elseif($survey_settings["0"]["email_send"] == "1"){
			// mail settings from survey
			$from = $mail_settings["0"]["from"];
			$recipient = explode(";", $survey_settings["0"]["email_send_to"]);			
			$fromname = "";
			$subjectd = $mail_settings["0"]["subject"];
			$body = str_replace("#SURVEYNAME#", $survey_name, $mail_settings["0"]["content"]);
			
			if($user_id != "0"){
				$body = str_replace("#USER#", $user->username, $body);
			}
			else{
				$body = str_replace(JText::_("COM_SURVEYS_USER").": #USER#", "", $body);
			}
			$result = $this->getEmailQuestionsContent($survey_id, $session_id);
			$body = str_replace("#RESULTS#", "\n\n".$result, $body);
			$mode = false; //text or true=html
			JUtility::sendMail($from, $fromname, $recipient, $subjectd, $body, $mode);
		}
		elseif($survey_settings["0"]["email_send"] == "0"){
			// mail settings from email
			if($mail_settings["0"]["email_notification"] == "1"){
				$from = $mail_settings["0"]["from"];
				$recipient = explode(";", $mail_settings["0"]["to"]);			
				$fromname = "";
				$subjectd = $mail_settings["0"]["subject"];
				$body = str_replace("#SURVEYNAME#", $survey_name, $mail_settings["0"]["content"]);
				
				if($user_id != "0"){
					$body = str_replace("#USER#", $user->username, $body);
				}
				else{
					$body = str_replace(JText::_("COM_SURVEYS_USER").": #USER#", "", $body);
				}
				$result = $this->getEmailQuestionsContent($survey_id, $session_id);
				$body = str_replace("#RESULTS#", "\n\n".$result, $body);
				$mode = false; //text or true=html
				JUtility::sendMail($from, $fromname, $recipient, $subjectd, $body, $mode);
			}
		}
	}
	
	function getSurveyId(){
		$item_id = JRequest::getVar("Itemid", "0");
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('params');
		$query->from('#__menu');
		$query->where("id=".$item_id);
		$db->setQuery($query);		
		$db->query();
		$params = $db->loadResult();	
		if(isset($params) && $params != NULL){
			$params = json_decode($params);
			$survey_id = "0";
			if(isset($params->sid_menu) && trim($params->sid_menu) != ""){
				$survey_id = $params->sid_menu;
			}
			$query->clear();		
			$query->select('alias');
			$query->from('#__adprin_surveys_surveys');
			$query->where("id=".$survey_id);
			$db->setQuery($query);		
			$db->query();
			$alias = $db->loadResult();
			if(isset($alias) && trim($alias) != ""){
				return $survey_id.":".$alias;
			}
			else{
				return "0";
			}
		}
	}
	

}

?>