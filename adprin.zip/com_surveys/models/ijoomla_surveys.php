<?php

/**
* @author  Chenglong Li
*/

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');
jimport('joomla.utilities.date');

class adprin_SurveysModeladprin_surveys extends JModel{
	
	function getParams(){
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->clear();
		$query->select('params');
		$query->from('#__extensions');	
		$query->where("element='com_surveys'");
		$db->setQuery($query);
		$db->query();
		$result_text = $db->loadResult();
		return json_decode($result_text);
	}
	
	function getSurveysList($params){
		$table = "";
		$row_num = "1";
		$class = "";
		$i = 1;
		$access = "";
		$item_id = JRequest::getVar("Itemid", "0");
		$all_surveys = $this->getAllSurveys();
		$table .= '<table width="100%" cellspacing="0" cellpadding="0">';
		//$table .= '<tr class="sublevel">';
		//$table .= '<th class="'.$params->column_heading.'" width="3%" align="center">#</th>';
		//$table .= '<th class="'.$params->column_heading.'" align="left" width="100%">'.JText::_("COM_SURVEYS_SURVEY_NAME").'</th>';
		//$table .= '</tr>';
		if(count($all_surveys)>0){
			foreach($all_surveys as $key=>$value){
				if($row_num == "1"){
					$class = $params->table_row1;
					$row_num = "2";
				}
				elseif($row_num == "2"){
					$class = $params->table_row2;
					$row_num = "1";
				}				

				$table .= '<tr class="'.$class.'">';
				$i++;
				//$table .= 		'<td align="center">'.$i++.'</td>';
				$link = JRoute::_('index.php?option=com_surveys&controller=editsurvey&Itemid='.intval($item_id).'&id='.$value["id"].':'.$value["alias"]."&mode=training");
				$table .= 		'<td><a href="'.$link.'">'.$value["title"]." (".JText::_("COM_SURVEYS_SELF_TRAINING").")".'</a></td>';
				$table .= '</tr>';
				if($row_num == "1"){
					$class = $params->table_row1;
					$row_num = "2";
				}
				elseif($row_num == "2"){
					$class = $params->table_row2;
					$row_num = "1";
				}	
				$table .= '<tr class="'.$class.'">';
				//$table .= 		'<td align="center">'.$i++.'</td>';
				$link = JRoute::_('index.php?option=com_surveys&controller=editsurvey&Itemid='.intval($item_id).'&id='.$value["id"].':'.$value["alias"]);
				$table .= 		'<td><a href="'.$link.'">'.$value["title"].'</a></td>';
				$table .= '</tr>';
			}
			$table .= '</table>';
			return $table;
		}
		else{
			return JText::_("COM_SURVEYS_NO_SURVEYS");
		}
	}
	
	function getAllSurveys(){
		$user =& JFactory::getUser();
		$user_id = $user->id;
		
		$access = $user->getAuthorisedViewLevels();
		$access = implode(",", $access);
		
		$and = " and access in (1,".$access.")";
		
		$data = new JDate();
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->clear();
		$query->select('id, title, alias, access');
		$query->from('#__adprin_surveys_surveys');	
		$query->where("((published_up <= '".$data."' and published_down >= '".$data."') or(published_down='0000-00-00 00:00:00')) and published=1 ".$and);
		$query->order("ordering asc");		
		$db->setQuery($query);
		$db->query();
		$result = $db->loadAssocList();		
		return $result;
	}
	
}

?>