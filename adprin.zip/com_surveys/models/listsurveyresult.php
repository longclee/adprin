<?php

/**
* @author  Chenglong Li
*/

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.modellist');
jimport('joomla.utilities.date');

class adprin_SurveysModelListsurveyresult extends JModel{
	
	function getSurveyResultList(){
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();		
		$query->select('id, title, alias');
		$query->from('#__adprin_surveys_surveys');
		$query->where("show_result=1 and published=1");
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadAssocList();		
		return $result;
	}
	
	function getParams(){
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->clear();
		$query->select('params');
		$query->from('#__extensions');	
		$query->where("element='com_surveys'");
		$db->setQuery($query);
		$db->query();
		$result_text = $db->loadResult();
		return json_decode($result_text);
	}
	
	function getSurveysList($params){
		$table = "";
		$row_num = "1";
		$class = "";
		$i = 1;
		$access = "";
		$item_id = JRequest::getVar("Itemid", "0");
		$all_surveys = $this->getSurveyResultList();
		$table .= '<table width="100%" cellspacing="0" cellpadding="0">';
		$table .= '<tr class="sublevel">';
		$table .= '<th class="'.$params->column_heading.'" width="3%" align="center">#</th>';
		$table .= '<th class="'.$params->column_heading.'" align="left" width="100%">'.JText::_("COM_SURVEYS_SURVEY_NAME").'</th>';
		$table .= '</tr>';
		if(count($all_surveys)>0){
			foreach($all_surveys as $key=>$value){
				if($row_num == "1"){
					$class = $params->table_row1;
					$row_num = "2";
				}
				elseif($row_num == "2"){
					$class = $params->table_row2;
					$row_num = "1";
				}				
				$table .= '<tr class="'.$class.'">';
				$table .= 		'<td align="center">'.$i++.'</td>';
				$link = JRoute::_('index.php?option=com_surveys&controller=listsurveyresult&task=viewresult&page=last&Itemid='.intval($item_id).'&id='.$value["id"]);
				$table .= 		'<td><a href="'.$link.'">'.$value["title"].'</a></td>';
				$table .= '</tr>';
			}
			$table .= '</table>';
			return $table;
		}
		else{
			return JText::_("COM_SURVEYS_NO_SURVEYS");
		}
	}
	
	function editResult(){		
		$document =& JFactory::getDocument();
		$document->addStyleSheet("components/com_surveys/css/survey.css");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionEssay.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionMultiplePerRow.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionOneAnswer.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionOneAnswerMenu.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionMultipleAnswer.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionOnePerRow.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionRating.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionEndedOneLine.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionEndedMoreLines.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionConstant.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionDateTime.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionRating.php");
		include_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."QuestionMultiplePerRowMenus.php");
		require_once(JPATH_ROOT.DS."components".DS."com_surveys".DS."helpers".DS."questions.php");		
			
		$params = $this->getParams();
		$class_object = new Question("", "", "", "", "", "", "", "");
		$survey_id = JRequest::getVar("id", "0");		
		$all_responses_count = $this->getAllResponses($survey_id);		
		$all_questions = $this->getAllQuestions($survey_id);
		$i = 1;
		
		$result  = '<form name="view_result" action="">';
		$result .= '<table cellspacing="0" cellpadding="0" border="0" width="100%">';
		$result .= 		'<tr>';
		$result .= 			'<td class="'.$params->survey_name.'">'.$this->getSurveyName($survey_id).'</td>';
		$result .= 		'</tr>';
		$result .= '</table>';
		$result .= "<br/><br/>";
		 
		if(isset($all_questions) && is_array($all_questions) && count($all_questions)>0){
			foreach($all_questions as $key=>$value){				
				$class = "Question".$class_object->getClass($value["question_type"]);				
				$object = new $class();
				$result .= $object->editResult($value["id"], $survey_id, $params, $i, $value["title"], $all_responses_count);
				$result .= "<br /><br />";
				$i++;
			}
		}				
		
		$result .= '<input type="hidden" name="option" value="com_surveys"/>';
		$result .= '<input type="hidden" name="controller" value="editsurvey"/>';
		$result .= '<input type="hidden" name="task" value="edit_details"/>';
		$result .= '<input type="hidden" name="q_id" value=""/>';
		$result .= '<input type="hidden" name="a_id" value=""/>';
		$result .= '</form>';		
		echo $result;
	}
	
	function getAllResponses($survey_id){
		$db =& JFactory::getDBO();
		$sql = "select count(*) from #__adprin_surveys_session where completed=1 and last_page_id=0 and published=1 and survey_id=".$survey_id;
		$db->setQuery($sql);
		$db->query();
		$result = $db->loadResult();
		return $result;
	}
	
	function getAllQuestions($survey_id){
		$data = new JDate();
		$db =& JFactory::getDBO();		
		$query = $db->getQuery(true);
		$query->clear();
		$query->select('*');
		$query->from('#__adprin_surveys_questions');
		$query->where("survey_id=".$survey_id." and published=1 and published_up <= '".$data."' and ((published_down >= '".$data."') or published_down='0000-00-00 00:00:00')");
		$query->order("ordering asc");
		$db->setQuery($query);		
		$db->query();
		$result = $db->loadAssocList();		
		return $result;
	}
	
	function getSurveyName($survey_id){
		$db =& JFactory::getDBO();
		$sql = "select title from #__adprin_surveys_surveys where id=".$survey_id;
		$db->setQuery($sql);
		$db->query();
		$result = $db->loadResult();
		return $result;
	}		
}

?>