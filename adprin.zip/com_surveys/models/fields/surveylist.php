<?php

/**
* @author  Chenglong Li
*/

defined('JPATH_BASE') or die;

jimport('joomla.html.html');
jimport('joomla.form.formfield');
jimport( 'joomla.utilities.date' );

class JFormFieldSurveylist extends JFormField{

	protected $type = 'surveylist';
	
	protected function getInput(){
		$params = $this->form->getValue('params');
		$sid_menu = "0";
		if(isset($params->sid_menu)){
			$sid_menu = $params->sid_menu;
		}
		$db =& JFactory::getDBO();
		$date = new JDate();		
		$sql = "select id, title from #__adprin_surveys_surveys WHERE published=1 and published_up <= '".$date."' and (published_down >= '".$date."' or published_down='0000-00-00 00:00:00') order by title asc";
		$db->setQuery($sql);
		$db->query();
		$result = $db->loadAssocList();				
		$return  = '<select id="jform_params_sid_menu" name="jform[params][sid_menu]">';
		$return .= 		'<option value="0">-- Select survey --</option>';
		foreach($result as $key=>$values){
			$selected = '';
			if($sid_menu == $values["id"]){
				$selected = ' selected="selected" ';
			}
			$return .= '<option value="'.$values["id"].'" '.$selected.'>'.$values["title"].'</option>';
		}
		$return .= '</select>';
		return $return;
	}
}