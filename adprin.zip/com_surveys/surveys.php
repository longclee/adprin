<?php

defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.controller');

error_reporting(0);
ini_set('display_errors','Off');

// Require the base controller
require_once( JPATH_COMPONENT.DS.'controller.php' );
// Require specific controller if requested
$pattern = '/^[A-Za-z]*$/';
$controller = "";
if(preg_match($pattern, JRequest::getVar('controller'))){
    $controller = JRequest::getVar('controller', "");
	if($controller == ""){
		$controller = JRequest::getVar('view', "");
	}
	$path = JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php';	
	if (file_exists($path)) {
		require_once $path;
	} else {
		$controller = '';
	}
}

// Create the controller
$classname	= 'adprin_SurveysController'.$controller;
$controller	= new $classname();
$controller->execute(JRequest::getVar('task', ""));
$controller->redirect();

?>
