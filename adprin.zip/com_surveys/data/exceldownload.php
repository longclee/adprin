<?php
/* Here there will be some code where you create $objPHPExcel */

// redirect output to client browser

$excel = $_GET["file"];

if(file_exists($excel)){
	header('Content-Type: application/vnd.ms-excel');
	header('Content-Disposition: attachment;filename="'.$excel.'"');
	header('Cache-Control: max-age=0');
}

?>
